

function table = IAImgConvolve(a, atext, t, ttext, targetcoord, assign)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global tempCount;
global Analysis;

template = st.search(ttext);
if(template == 0)
    disp_error('Runetime', sprintf('Template "%s" not found', ttext) );
end

if(strcmp(template.arrayType, 'tpl') == 0)
    disp_error('Runetime', 'Nonrecursive Convolution requires a nonrecursive template' );
end

value = st.search(atext);
if(value == 0)
    disp_error('Runetime', sprintf('Image "%s" not found', atext) );
end

if(value.ptr_range.noElements ~= template.ptr_range.noElements)
    disp_error('Runtime', sprintf('Dimensionality of "%s" and "%s" are incompatible', atext, ttext ));
end

table = matimage(value.infimum, value.supremum);

    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis')) 
        Isize = prod(value.supremum - value.infimum + 1);
        Tsize = prod(template.supremum - template.infimum + 1);
        Analysis.add(sprintf('%s = %s (+) %s', assign, atext, ttext), 'MemReads', Isize+Tsize, 'MemWrites', Isize, 'Mult', Isize*Tsize, 'Add', Isize*(Tsize-1) );
    end
    
    
%    tic;
    tinfimum = template.infimum;
    tmagnitude = template.supremum - tinfimum +1;
    N = prod(tmagnitude);
    tcoord = zeros(N, numel(tinfimum));
    for j = 1:N
        templatecoord = deindex(j, tmagnitude) +  tinfimum - 1;
        tcoord(j,:) = targetcoord - templatecoord;
    end
    infimum = value.infimum;
    magnitude = value.supremum - infimum +1;
    matrix = table.data();
    tmatrix = t.data();
    M = prod(magnitude);
    for i = 1:M
        coord = deindex(i, magnitude) +  infimum - 1;
        sum = 0;
        for j = 1:N
            sum = sum + a.get(coord - tcoord(j,:) ) .*tmatrix(j);
        end
        matrix(i) = sum;
    end
    table.set(matrix);
%    toc

%     
%     tic;
%     coord = first(value);
%     lastcoord = last(value);
%     while(isempty(find(coord ~= lastcoord, 1)) == 0)
%         sum = 0;
%         templatecoord = first(template);
%         templatelastcoord = last(template);
%         while(isempty(find(templatecoord ~= templatelastcoord, 1)) == 0)
%             sum = sum + a.get(coord - targetcoord + templatecoord) * t.get(templatecoord);
%             templatecoord = next(template,templatecoord);
%         end
%         sum = sum + a.get( coord - targetcoord + templatecoord) * t.get(templatecoord);
%         table.put(coord, sum);
%         
%         coord = next(value,coord);
%     end
%     
%     
%     sum = 0;
%     templatecoord = first(template);
%     templatelastcoord = last(template);
%     while(isempty(find(templatecoord ~= templatelastcoord, 1)) == 0)
%         sum = sum + a.get(coord - targetcoord + templatecoord) * t.get(templatecoord);
%         templatecoord = next(template,templatecoord);
%     end
%     sum = sum + a.get( coord - targetcoord + templatecoord) * t.get(templatecoord);
%     table.put(coord, sum);
%     toc
    st.replace(assign, st_new_PSnode(0, assign, value.type, value.arrayType, 0, value.ptr_range, 0, value.scan, value.connectivity) );
    tempCount = tempCount + 1;

    %%%%% VARIENT TEMPLATE MATERIAL.  COULD NOT MAKE WORK.  Good Luck!
%    mappedDomain = t.firstChild.firstChild.value;
%    imageDomain = t.firstChild.firstChild.sibling.firstChild.sibling.value;
    
%    nodeA = st.search(mappedDomain);
%    nodeB = st.search(imageDomain);
%    dimension = length(nodeA.infimum);
%    if(length(nodeB.infimum) ~= dimension)
%        display('Incomaptible domains');
%        pause;
%        return;
%    end
    
%    mappedPoint = t.firstChild.sibling.firstChild.firstChild.value;
%    imagePoint = t.firstChild.sibling.firstChild.firstChild.sibling.value;
    
%    functionCount = t.firstChild.sibling.noChildren;
%    currentFunction = t.firstChild.sibling.firstChild.sibling;
%    for i = 1:functionCount-1
        
        
%        result = searchForData( mappedPoint , currentFunction.firstChild, nodeA.infimum-nodeA.infimum);
%        
%        if(isempty(find(result, 1)) == 0)
%            for j = 1: length(result)
%
%                if(result(j) > 0)
%
%                end
%
%
%
%            end
%        else
%            temp.infimum = nodeA.infimum;
%            temp.supremum = nodeA.supremum;
%            temp.scan = value.scan;
%            
%            coord = first(temp);
%            lastcoord = last(temp);
%            while(isempty(find(coord ~= lastcoord, 1)) == 0)
%                %coord
%                %getValueFromExpression(a, currentFunction.firstChild, imagePoint, mappedPoint, 0, coord)
%                
%                table = vectorPut(table, coord, getValueFromExpression(a, currentFunction.firstChild, imagePoint, mappedPoint, 0, coord));
%                coord = next(temp,coord);
%            end
%            table = vectorPut(table, coord, getValueFromExpression(a, currentFunction.firstChild, imagePoint, mappedPoint, 0, coord));
%        end
%        
%        display_tree(currentFunction);
%        
%        currentFunction = currentFunction.sibling;
%    end
    
    %table = a;

%Add a temperary value to the symbol table for further computations.


%function table = convolutionHelper(table, a, t, template, coord, targetcoord)
%    sum = 0;
%    templatecoord = first(template);
%    templatelastcoord = last(template);
%    while(isempty(find(templatecoord ~= templatelastcoord, 1)) == 0)
%        sum = sum + vectorGet(a, coord - targetcoord + templatecoord) * vectorGet(t, templatecoord);
%        templatecoord = next(template,templatecoord);
%    end
%    sum = sum + vectorGet(a, coord - targetcoord + templatecoord) * vectorGet(t, templatecoord);
%    table = vectorPut(table, coord, sum);
    

%function result = searchForData( mappedPoint , currentFunction, result)

    %display('Hello there');
    %currentFunction.type
    %currentFunction.value
%    if(strcmp(currentFunction.type, 'vector'))
%        currentF = currentFunction.firstChild;
%       for i = 1:currentFunction.noChildren
%           %result
%           result = result + searchForData(mappedPoint, currentF, result);
%           %result
%           currentF.sibling;
%       end
        
%    elseif(strcmp(currentFunction.type, 'DIM'))
%
%        if(strcmp(currentFunction.firstChild.sibling.value, mappedPoint))
%            result(currentFunction.firstChild.value) = result(currentFunction.firstChild.value) +1;
%        end
%        
%    elseif((strcmp(currentFunction.type, '-') && currentFunction.noChildren == 1) || strcmp(currentFunction.type, 'cos') || strcmp(currentFunction.type, 'sin') )
%        result = result + searchForData(mappedPoint, currentFunction.firstChild, result);
%    elseif(strcmp(currentFunction.type, '+') || strcmp(currentFunction.type, '-') || strcmp(currentFunction.type, '*') || strcmp(currentFunction.type, '^') || strcmp(currentFunction.type, '/'))
%        result = result + searchForData(mappedPoint, currentFunction.firstChild, result);
%        result = result + searchForData(mappedPoint, currentFunction.firstChild.sibling, result);
%    else
%        if(strcmp(currentFunction.value, mappedPoint))
%            result = result + 1;
%        end
%    end
%    
%function value = getValueFromExpression(table, currentFunction, imagePoint, mappedPoint, imageCoord, mappedCoord)
%global st;
%
%     
%    %currentFunction
%    %currentFunction.value
%    %display_tree(currentFunction);
%    
%    if(strcmp(currentFunction.type, 'vector'))
%        currentF = currentFunction.firstChild;
%        vector = 0;
%       for i = 1:currentFunction.noChildren
%           vector(i) = getValueFromExpression(table, currentF, imagePoint, mappedPoint , imageCoord, mappedCoord);
%           %value  = value + searchForData(mappedPoint, currentF, result);
%           currentF.sibling;
%       end
%       %vector
%       value = vectorGet(table, vector);
%    elseif(strcmp(currentFunction.type, 'DIM'))
%        
%        if(strcmp(currentFunction.firstChild.sibling.value, imagePoint))
%            %currentFunction.firstChild.value
%            %imageCoord
%            if(imageCoord ~= 0)
%                value = imageCoord(currentFunction.firstChild.value);
%            else
%                value = mappedCoord(currentFunction.firstChild.value);
%            end
%            
%        elseif(strcmp(currentFunction.firstChild.sibling.value, mappedPoint))
%            value = mappedCoord(currentFunction.firstChild.value);
%        end
%        
%    elseif(strcmp(currentFunction.type, '-') && currentFunction.noChildren == 1)
%        value = - getValueFromExpression(table,currentFunction.firstChild, imagePoint, mappedPoint , imageCoord, mappedCoord);
%
%    elseif(strcmp(currentFunction.type, '+'))
%        %display_tree(currentFunction.firstChild);
%        %display_tree(currentFunction.firstChild.sibling);
%        
%        value = getValueFromExpression(table,currentFunction.firstChild, imagePoint, mappedPoint , imageCoord, mappedCoord) + getValueFromExpression(table,currentFunction.firstChild.sibling, imagePoint, mappedPoint , imageCoord, mappedCoord);
%    elseif(strcmp(currentFunction.type, '-'))
%        value = getValueFromExpression(table,currentFunction.firstChild, imagePoint, mappedPoint , imageCoord, mappedCoord) - getValueFromExpression(table,currentFunction.firstChild.sibling, imagePoint, mappedPoint , imageCoord, mappedCoord);
%    elseif(strcmp(currentFunction.type, '*'))
%        value = getValueFromExpression(table,currentFunction.firstChild, imagePoint, mappedPoint , imageCoord, mappedCoord) * getValueFromExpression(table,currentFunction.firstChild.sibling, imagePoint, mappedPoint , imageCoord, mappedCoord);
%    elseif(strcmp(currentFunction.type, '^'))
%        value = getValueFromExpression(table,currentFunction.firstChild, imagePoint, mappedPoint , imageCoord, mappedCoord) ^ getValueFromExpression(table,currentFunction.firstChild.sibling, imagePoint, mappedPoint , imageCoord, mappedCoord);
%    elseif(strcmp(currentFunction.type, '/'))
%        value = getValueFromExpression(table,currentFunction.firstChild, imagePoint, mappedPoint , imageCoord, mappedCoord) / getValueFromExpression(table,currentFunction.firstChild.sibling, imagePoint, mappedPoint , imageCoord, mappedCoord);
%    elseif(strcmp(currentFunction.type, 'cos'))
%        value = cos(getValueFromExpression(table,currentFunction.firstChild, imagePoint, mappedPoint , imageCoord, mappedCoord)*pi/180);
%    elseif(strcmp(currentFunction.type, 'sin'))
%        value = sin(getValueFromExpression(table,currentFunction.firstChild, imagePoint, mappedPoint , imageCoord, mappedCoord)*pi/180);
%    else
%        
%        if(strcmp(currentFunction.value, mappedPoint))
%            value = vectorGet(table, mappedCoord);
%        elseif(strcmp(currentFunction.value, imagePoint))
%            if(imageCoord ~= 0)
%                value = vectorGet(table, imageCoord);
%            else
%                %mappedCoord
%                value = vectorGet(table, mappedCoord);
%            end
%        else
%            node = ntqu_search(st, currentFunction.value);
%            if(node ~= 0)
%                node.value;
%            else
%                value = currentFunction.value;
%            end
%        end
%        %dimvalue = ntqu_search(dimtable, map.value);
%        %if(dimvalue ~= 0)
%        %    value = coord(dimvalue.level);
%        %else
%        %    stvalue = ntqu_search(st, map.value);
%        %    if(stvalue ~= 0)
%        %        value = stvalue.value;
%        %    else
%        %        value = map.value;
%        %    end
%        %end
%end
    