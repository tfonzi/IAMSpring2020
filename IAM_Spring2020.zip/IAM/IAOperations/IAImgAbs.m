

function table = IAImgAbs(a, atext, assign)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global tempCount;
global Analysis;

value1 = st.search(atext);

if(value1 ~= 0 && strcmp(value1.arrayType, 'image'))
    %disp_error('Runetime', sprintf('%s is not an image to compute negate', atext ));
    
    table = a.clone();
    table.set(abs(a.data()));
    %table = matimage(value1.infimum, value1.supremum);
    %coord = first(value1);
    %lastcoord = last(value1);
    %while(isempty(find(coord ~= lastcoord, 1)) == 0)
    %    table.put( coord, abs( a.get(coord)));
    %    coord = next(value1,coord);
    %end
    %table.put( coord, abs( a.get(coord) ) );
    
    if(ischar(assign) )
        if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis')) 
            Isize = prod(value1.supremum - value1.infimum + 1);
            Analysis.add(sprintf('%s = abs(%s)', assign, atext), 'MemReads', Isize, 'MemWrites', Isize, 'Min', Isize);
        end
        st.replace(assign, st_new_PSnode(0, assign, value1.type, value1.arrayType, 0, value1.ptr_range, 0, value1.scan, value1.connectivity) );
        tempCount = tempCount + 1;
    end
    
else
    table = abs(a);
    
    if(ischar(assign) )
        if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis')) 
            Analysis.add(sprintf('%s = abs( %s ) ', assign, atext), 'MemReads', 1, 'MemWrites', 1, 'Min', 1);
        end
        st.replace(assign, st_new_PSnode(0, assign, 'int', 'nil', table, 0, 0, 0, 0) );
        tempCount = tempCount + 1;
    end
end
