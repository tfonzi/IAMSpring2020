

function c = IAImgAverage(a, t, coord)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

[ M N ] = size(a);
[ K L ] = size(t);
c = a;
coord(1) = round(K/2) + coord(1);
coord(2) = round(L/2) + coord(2);
for i = 1:M
  for j = 1:N
      sum = 0;
      amount = 0;
      for o = 1:K
          for p = 1:L
           if ((i - coord(1)+o) > 0 & (j - coord(2)+p) > 0 & (i - coord(1)+o) <= M & (j - coord(2)+p) <= N)
              tempval = a(i - coord(1)+o,j - coord(2)+p)*t(o,p);
              sum = sum + tempval;
              amount = amount +1;
            end
          end
      end
      average = sum/amount;
      c(i,j) = average;
  end
end