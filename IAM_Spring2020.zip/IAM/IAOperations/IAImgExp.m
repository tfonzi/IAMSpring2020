

function table = IAImgExp(a, atext, assign)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global tempCount;
global Analysis;

value1 = st.search(atext);

if(value1 ~= 0 && strcmp(value1.arrayType, 'image'))
    %disp_error('Runetime', sprintf('%s is not an image to compute negate', atext ));
    
    table = matimage(value1.infimum, value1.supremum);    
    table.set(exp(a.data()));
    
    coord = first(value1);
    lastcoord = last(value1);
    if(  isempty(Analysis) == 0 && strcmp(Analysis.type, 'classicalFD') )%check if analysis type is classicalFD
            errorList = 0;%initialize error list
            count = 1;%loop counter
            deviation = 10;%used to generate error
            while(isempty(find(coord ~= lastcoord, 1)) == 0)     %loops throught every value of image                 
                errorA = randi([-deviation,deviation]);%generates random error value
                errorB = abs(exp(a.get(coord))*(exp(errorA) - 1));%performes error calculation for exp error
                if (isnan(errorB) || ~isfinite(errorB))%gives errorList 0 if calculated value is inf or Nan
                    errorList(count) = 0;
                else    
                    errorList(count) = errorB;%adds error value to errorList
                end                   
                count = count +1;
                table.put(coord, exp(a.get(coord)));%adds value to table
                coord = next(value1,coord);                
            end
            Analysis.add(sprintf('%s = exp(%s)', assign, atext), errorList);%add exp errorlist to global analysis object for classicalFD
    end
    
    
    %coord = first(value1);
    %lastcoord = last(value1);
    %while(isempty(find(coord ~= lastcoord, 1)) == 0)
    %    table.put( coord, exp( a.get(coord)));
    %    coord = next(value1,coord);
    %end
    %table.put( coord, exp( a.get(coord) ) );
    
    if(ischar(assign) )
        if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis')) 
            Isize = prod(value1.supremum - value1.infimum + 1);
            Analysis.add(sprintf('%s = exp(%s)', assign, atext), 'MemReads', Isize, 'MemWrites', Isize, 'Min', Isize);
        end
        st.replace(assign, st_new_PSnode(0, assign, value1.type, value1.arrayType, 0, value1.ptr_range, 0, value1.scan, value1.connectivity) );
        tempCount = tempCount + 1;
    end
    
else
    table = exp(a);
    
    if(ischar(assign) )
        if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis')) 
            Analysis.add(sprintf('%s = exp(%s) ', assign, atext), 'MemReads', 1, 'MemWrites', 1, 'Pwr', 1);
        end
        st.replace(assign, st_new_PSnode(0, assign, 'int', 'nil', table, 0, 0, 0, 0) );
        tempCount = tempCount + 1;
    end
end
