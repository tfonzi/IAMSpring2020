
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: IADoubleBarRestrict
%% Inputs: operation type, operand, operand name, input object, input name, output name
%% Output: output object
%% Description:
%% Performs an evaluate of evert point in the input and determins if the value
%% is within the parameters of the operation and the operand.  If it is, then
%% the value ramains the same, else it is changed to zero.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function table = IADoubleBarRestrict(op, opn, opntext, a,  atext, assign)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global tempCount;
global Analysis;
value1 = st.search(atext);
table = matimage(value1.infimum, value1.supremum);
value2 = st.search(opntext);
data = table.data();
if(value2 ~= 0)
    opn = value2.value;
end

if(value1.ptr_range.noElements > 4)
    disp_error('Runtime', 'Cannot compute images greater than dimensions of 4');
end

    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis')) 
        Asize = prod(value1.supremum - value1.infimum + 1);
        Analysis.add(sprintf('%s = %s ||_%s%s', assign, atext, op, opntext), 'MemReads', Asize, 'MemWrites', Asize, 'Max', Asize, 'Sub', Asize);
    end

    if (strcmp(op, '=='))
        temp = a.data();
        I = temp == opn;
        data(I) = temp(I);
        table.set(data);
    elseif(strcmp(op,'>='))
        temp = a.data();
        I = temp >= opn;
        data(I) = temp(I);
        table.set(data);
    elseif(strcmp(op,'<='))
        temp = a.data();
        I = temp <= opn;
        data(I) = temp(I);
        table.set(data);
    elseif(strcmp(op, '>'))
        temp = a.data();
        I = temp > opn;
        data(I) = temp(I);
        table.set(data);
    elseif(strcmp(op, '<'))
        temp = a.data();
        I = temp < opn;
        data(I) = temp(I);
        table.set(data);
    elseif(strcmp(op, '!='))
        temp = a.data();
        I = temp ~= opn;
        data(I) = temp(I);
        table.set(data);
    end
        
    st.replace(assign, st_new_PSnode(0, assign, value1.type, value1.arrayType, 0, value1.ptr_range, 0, value1.scan, value1.connectivity));
    tempCount = tempCount + 1;
