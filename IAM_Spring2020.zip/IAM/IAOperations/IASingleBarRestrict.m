
function table = IASingleBarRestrict(a,atext,~,btext, assign)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global tempCount;
global Analysis;

value1 = st.search(atext);
value2 = st.search(btext);

if(value1 == 0 || value2 == 0 || strcmp(value1.arrayType, 'nil') || strcmp(value2.arrayType, 'domain') == 0)
    disp_error('Runtime', 'Cannot compute extend images with numbers and/or must restrict with the domain of an image' );
end

if(value1.ptr_range.noElements ~= value2.ptr_range.noElements ||isempty(find(value1.infimum > value2.infimum, 1 )) == 0 || isempty(find(value1.supremum < value2.supremum, 1)) == 0)
        disp_error('Runtime', sprintf('Domains of "%s" and "%s" are incompatible', atext, btext ));
end

    
    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis')) 
        Asize = prod(value1.supremum - value1.infimum + 1);
        Bsize = prod(value2.supremum - value2.infimum + 1);
        Analysis.add(sprintf('%s = %s |_ %s', assign, atext, btext), 'MemReads', Asize, 'MemWrites', Bsize);
    end
    
    table = matimage(value2.infimum, value2.supremum);
    table.populate(value2.infimum, a.matrix(value2.infimum, value2.supremum) );
    %coord = first(value2);
    %lastcoord = last(value2);
    %while(isempty(find(coord ~= lastcoord, 1)) == 0)
    %    table.put(coord, a.get(coord));
    %    coord = next(value2,coord);
    %end
    %table.put(coord, a.get(coord));
    st.replace(assign, st_new_PSnode(0, assign, value2.type, value2.arrayType, 0, value2.ptr_range, 0, value2.scan, value2.connectivity) );
    tempCount = tempCount + 1;