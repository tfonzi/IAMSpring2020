
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: IAExtend
%% Inputs: input object A, input name A, input object B, input name B, output name
%% Output: output object
%% Description:
%% Build and object that is an extentension of A onto B 
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function table = IAExtend(a,atext,b,btext, assign)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global tempCount;
global Analysis;

value1 = st.search(atext);
value2 = st.search(btext);


if(value1 == 0 || value2 == 0 || strcmp(value1.arrayType, 'nil') || strcmp(value2.arrayType, 'nil'))
    disp_error('Runtime', 'Cannot extend numbers');
end
    
if(value1.ptr_range.noElements > 4)
    disp_error('Runtime', 'Cannot compute images greater than dimensions of 4');
end

    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis')) 
        Asize = prod(value1.supremum - value1.infimum + 1);
        Bsize = prod(value2.supremum - value2.infimum + 1);
        Analysis.add(sprintf('%s = %s |^ %s', assign, atext, btext), 'MemReads', Bsize+Asize, 'MemWrites', Asize+Bsize);
    end
    
    
    rq = ntqu_new;
    
    %%Compare dimension sizes of the images
    node1 =value1.ptr_range.firstElement;
    node2 =value2.ptr_range.firstElement;
    for i = 1:value1.ptr_range.noElements
        start1 = st.search(node1.start_range);
        end1 =st.search(node1.end_range);
        start2 = st.search(node2.start_range);
        end2 = st.search(node2.end_range);
       if(start1 == 0)
            startRange1 = node1.start_range;
        else
            startRange1 = start1.value;
        end
        if(start2 == 0)
            startRange2 = node2.start_range;
        else
            startRange2 = start2.value;
        end
        if(startRange1 < startRange2)
            startRange = startRange1;
        else
            startRange = startRange2;
        end
        if(end1 == 0)
            endRange1 = node1.end_range;
        else
            endRange1 = end1.value;
        end
        if(end2 == 0)
            endRange2 = node2.end_range;
        else
            endRange2 = end2.value;
        end
        if(endRange1 > endRange2)
            endRange = endRange1;
        else
            endRange = endRange2;
        end
        rq = ntqu_push(rq, range_new_node(startRange, endRange));%Push range 1 on stack for symbol table
        node1 = node1.next;
        node2 = node2.next;
    end
    
    st.replace(assign, st_new_PSnode(0, assign, value2.type, value2.arrayType, 0, rq, 0, value2.scan, value2.connectivity));
    
    symbol = st.search(assign);
    
    table = matimage(symbol.infimum, symbol.supremum);
    if(strcmp(value2.arrayType, 'domain') == 0)
        table.populate(value2.infimum, b.data());
    end
    
    table.populate(value1.infimum, a.data());
    
    %coord = first(value1);
    %lastcoord = last(value1);
    %while(isempty(find(coord ~= lastcoord, 1)) == 0)
    %    %if(isempty(find(coord < value1.infimum)) && isempty(find(coord > value1.supremum)))%vectorGet(value2.hashtable, coord) == 0
    %    table.put(coord, a.get(coord));
    %    %end
    %    coord = next(value1,coord);
    %end
    %%if(isempty(find(coord < value1.infimum)) && isempty(find(coord > value1.supremum)))%vectorGet(value2.hashtable, coord) == 0
    %table.put(coord, a.get(coord));
    %end
       


tempCount = tempCount + 1;
