
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: assign
%% Inputs: input object, input name, output name
%% Output: input object
%% Description:
%% Assigns a symbol the data inputed including all the traits
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function a = assign(a, atext, btext)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global tempCount;
global Analysis;

value1 = st.search(atext);

if(value1 ~= 0)
    value2 = st_new_PSnode(0, btext, value1.type, value1.arrayType, value1.value, value1.ptr_range, value1.ptr_coord, value1.scan, value1.connectivity);
    if(ischar(btext))
        
        if(isempty(Analysis) == 0)
            if( strcmp(Analysis.type, 'nonparametric') )
               % value2.JMED = value1.JMED;
               % outputJMED(value2.JMED,  btext);
            elseif( strcmp(Analysis.type, 'operand_size_bits') )

                Analysis.print();
                value2.Bits = value1.Bits;
                value2.Noise = value1.Noise;
            elseif(strcmp(Analysis.type, 'dynamic_analysis')) 
                if(strcmp(value1.arrayType, 'nil') )
                    Analysis.add(sprintf('%s = %s', btext, atext), 'MemWrites', 1, 'MemReads', 1);
                else
                    Asize = prod(value1.supremum - value1.infimum + 1);
                    Analysis.add(sprintf('%s = %s', btext, atext), 'MemWrites', Asize, 'MemReads', Asize);
                end
            end
        end
        
    end
else
    if(isempty(Analysis) == 0)
        if( strcmp(Analysis.type, 'operand_size_bits') )
            Analysis.print();

        elseif(strcmp(Analysis.type, 'dynamic_analysis')) 
            Analysis.add(sprintf('%s = %s', btext, atext), 'MemWrites', 1, 'MemReads', 1);

        end
    end
    value2 = st_new_PSnode(0, btext, 'int', 'nil', a, 0, 0, 0, 0);
end

st.replace(btext, value2);

% Extract all temporary values from symbol table
for i=0:tempCount-1
    st.remove(sprintf('tmp%d',i));
end
tempCount = 0;
