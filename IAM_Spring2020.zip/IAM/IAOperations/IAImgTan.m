

function table = IAImgTan(a, atext, assign)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global tempCount;
global Analysis;

value1 = st.search(atext);

if(value1 ~= 0 && strcmp(value1.arrayType, 'image'))
    
    table = matimage(value1.infimum, value1.supremum);
    table.set(tan(a.data()));
    
    coord = first(value1);
    lastcoord = last(value1);
    if(  isempty(Analysis) == 0 && strcmp(Analysis.type, 'classicalFD') )%check if analysis type is classicalFD
            errorList = 0;%initialize error list
            count = 1;%loop counter
            deviation = 10;%used to generate error
            while(isempty(find(coord ~= lastcoord, 1)) == 0)           %loops throught every value of image            
                errorA = randi([-deviation,deviation]);%generates random error value
                errorB = abs(tan(a.get(coord) + errorA) - tan(a.get(coord)));%performes error calculation for tan error 
                if (isnan(errorB) || ~isfinite(errorB))%gives errorList 0 if calculated value is inf or Nan
                    errorList(count) = 0;
                else    
                    errorList(count) = errorB;%adds error value to errorList
                end                   
                count = count +1;
                table.put(coord, tan(a.get(coord)));%adds value to table
                coord = next(value1,coord);                
            end
            Analysis.add(sprintf('%s = tan(%s)', assign, atext), errorList);%add tan errorlist to global analysis object for classicalFD
    end       
    
    %table = matimage(value1.infimum, value1.supremum);
    %coord = first(value1);
    %lastcoord = last(value1);
    %while(isempty(find(coord ~= lastcoord, 1)) == 0)
    %    table.put( coord, tan(a.get(coord)));
    %    coord = next(value1,coord);
    %end
    %table.put( coord, tan(a.get(coord)));
    
    if(ischar(assign) )
        if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis')) 
            Isize = prod(value1.supremum - value1.infimum + 1);
            Analysis.add(sprintf('%s = tan( %s )', assign, atext), 'MemReads', Isize, 'MemWrites', Isize, 'Tan', Isize);
        end
        st.replace(assign, st_new_PSnode(0, assign, value1.type, value1.arrayType, 0, value1.ptr_range, 0, value1.scan, value1.connectivity) );
        tempCount = tempCount + 1;
    end
    
else
    table = tan(a);
    
    if(ischar(assign) )
        if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis')) 
            Analysis.add(sprintf('%s = tan( %s )', assign, atext), 'MemReads', 1, 'MemWrites', 1, 'Tan', 1);
        end
        st.replace(assign, st_new_PSnode(0, assign, 'int', 'nil', table, 0, 0, 0, 0) );
        tempCount = tempCount + 1;
    end
end




