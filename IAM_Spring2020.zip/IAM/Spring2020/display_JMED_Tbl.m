function display_JMED_Tbl(img)
    
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

    [length,width]  = size(img);

    x_length = [1:1:length];
    x_width = [1:1:width];

    y_length = normpdf(x_length, length/2, length/16);
    y_width = normpdf(x_width, width/2, width/16);

    

    %figure();
    %plot(x,y);


    matrix = zeros(length,length);

    for(i=1:length)

        for(j=1:width)

            matrix(i,j) = y_length(i) * y_width(j);

        end
    end

    matrix = matrix * (256/2/max(max(matrix)));

    output = F19JMED(img,matrix);

    
    %Generating Table for JMED
    figure()
    [length,width] = size(output);
    cols = linspace(0,1, width);
    rows = linspace(1,length,length);
    plot(rows,rows);
    ylabel('Magnitude'); 
    xlabel('Error Fraction');
    set(gcf,'Position',[100 100 800 400])
    set(gca,'XAxisLocation','top','YAxisLocation','left','ydir','reverse');
    table = uitable('Data', output);
    table.ColumnName = cols;
    title = uicontrol('Style','text');
    table.Position = [75 35 660 345];
    title.Position = [330 1 150 30];
    title.String = 'JMED Table';
    title.FontSize = 16;
end



