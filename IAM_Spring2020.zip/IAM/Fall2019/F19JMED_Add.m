function JMEDc = F19JMED_Add(a,da,b,db,JOMD)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
   JMEDa = F19JMED(a,da);
   JMEDb = F19JMED(b,db);
   c = a+b;
   d = rdivide(da+db,c);
   JMEDc = zeros(numel(unique(c)),numel(unique(d)));
   errfrac_cols = size(JMEDa,1);
   for x = 1:numel(a)
       for err = 1:errfrac_cols
           Prob_ab = JOMD(a(x)+1,b(x)+1);
           Prob_ea = JMEDa(a(x),err);
           Prob_eb = JMEDb(b(x),err);
           err_frac_c = (da(x)+db(x))/(a(x)+b(x));
           row = find(c(x)==unique(c));
           col = find(err_frac_c==unique(d));
           JMEDc(row,col) = JMEDc(row,col)+(Prob_ab*Prob_ea*Prob_eb);
       end
   end
end

