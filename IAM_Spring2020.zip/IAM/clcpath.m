% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

rmpath(strcat(pwd, ';'));
if(isunix)
    rmpath(strcat(pwd, '/Tree;'));
    rmpath(strcat(pwd, '/class;'));
    rmpath(strcat(pwd, '/IAOperations;'));
    rmpath(strcat(pwd, '/Images;'));
    rmpath(strcat(pwd, '/IApCode;'));
    rmpath(strcat(pwd, '/Parser;'));
    rmpath(strcat(pwd, '/Hash Functions;'));
    rmpath(strcat(pwd, '/GUI;'));
    rmpath(strcat(pwd, '/Complexity;'));
    rmpath(strcat(pwd, '/ErrSrcCode;'));
    rmpath(strcat(pwd, '/TranscendentalFnc;'));
elseif(ispc)
    rmpath(strcat(pwd, '\Tree;'));
    rmpath(strcat(pwd, '\class;'));
    rmpath(strcat(pwd, '\IAOperations;'));
    rmpath(strcat(pwd, '\Images;'));
    rmpath(strcat(pwd, '\IApCode;'));
    rmpath(strcat(pwd, '\Parser;'));
    rmpath(strcat(pwd, '\Hash Functions;'));
    rmpath(strcat(pwd, '\GUI;'));
    rmpath(strcat(pwd, '\Complexity;'));
    rmpath(strcat(pwd, '\ErrSrcCode;'));
    rmpath(strcat(pwd, '\TranscendentalFnc;'));
else
    display('Cannot run on this operating system ');
    stop;
end