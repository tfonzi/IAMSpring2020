

function varargout = IAM_30(varargin)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% IAM_30 MATLAB code for IAM_30.fig
%      IAM_30, by itself, creates a new IAM_30 or raises the existing
%      singleton*.
%
%      H = IAM_30 returns the handle to a new IAM_30 or the handle to
%      the existing singleton*.
%
%      IAM_30('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in IAM_30.M with the given input arguments.
%
%      IAM_30('Property','Value',...) creates a new IAM_30 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before IAM_30_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to IAM_30_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help IAM_30

% Last Modified by GUIDE v2.5 20-Oct-2010 23:39:39

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @IAM_30_OpeningFcn, ...
                   'gui_OutputFcn',  @IAM_30_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before IAM_30 is made visible.
function IAM_30_OpeningFcn(hObject, eventdata, handles, varargin)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global display_List;
global display_Count;
global plotscale;
clc;
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to IAM_30 (see VARARGIN)

% Choose default command line output for IAM_30
addpath(strcat(pwd, ';'));
if(isunix)
    addpath(strcat(pwd, '/Tree;'));
    addpath(strcat(pwd, '/class;'));
    addpath(strcat(pwd, '/IAOperations;'));
    addpath(strcat(pwd, '/Images;'));
    addpath(strcat(pwd, '/IApCode;'));
    addpath(strcat(pwd, '/Parser;'));
    addpath(strcat(pwd, '/Hash Functions;'));
    addpath(strcat(pwd, '/GUI;'));
    addpath(strcat(pwd, '/Complexity;'));
elseif(ispc)
    addpath(strcat(pwd, '\Tree;'));
    addpath(strcat(pwd, '\class;'));
    addpath(strcat(pwd, '\IAOperations;'));
    addpath(strcat(pwd, '\Images;'));
    addpath(strcat(pwd, '\IApCode;'));
    addpath(strcat(pwd, '\Parser;'));
    addpath(strcat(pwd, '\Hash Functions;'));
    addpath(strcat(pwd, '\GUI;'));
    addpath(strcat(pwd, '\Complexity;'));
else
    display('Cannot run on this operating system ');
    stop;
end

set(handles.stack_vector_ops, 'String', {});
set(handles.code_canvas, 'Max', 50, 'String', '');
set(handles.code_canvas, 'Position', [1.0 , 31.461538461538463 , 146.4 , 17.0 ]);
set(handles.code_canvas, 'String', {});
set(handles.code_canvas, 'Value', 0);
display_List = {};
display_Count = 0;
plotscale = 100000;
handles.output = hObject;


% Update handles structure
guidata(hObject, handles);
% UIWAIT makes IAM_30 wait for user response (see UIRESUME)
% uiwait(handles.figure1);




% --- Outputs from this function are returned to the command line.
function varargout = IAM_30_OutputFcn(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure


varargout{1} = handles.output;


% --- Executes on selection change in stack_vector_ops.
function stack_vector_ops_Callback(hObject, eventdata, handles) %controls what happens when the list is selected in the bottom right of GUI
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
global Analysis;
global display_List;
global display_Count;
% hObject    handle to stack_vector_ops (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns stack_vector_ops contents as cell array
%        contents{get(hObject,'Value')} returns selected item from stack_vector_ops
index = get(handles.stack_vector_ops, 'Value');
if(strcmp(get(handles.mode, 'String'), 'Error Analysis Mode')) %checks if mode is error analysis mode
    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'classicalFD')) %checks of classical fd error analysis mode
        Analysis.set(index);    %sets the plot to be shown to be the one that is selected in stackops
        plot_error(handles); %plots the correct error graph
    end

else
    colormap(gray);
    if(index > 0 && index <= display_Count)
        imagesc( uint8(display_List{index, 2} ), 'Parent', handles.display_canvas);
    end
    set(handles.display_canvas, 'XTick', [], 'YTick', [], 'Xcolor', [0.831, 0.816, 0.784], 'Ycolor', [0.831, 0.816, 0.784]);
end

% --- Executes during object creation, after setting all properties.
function stack_vector_ops_CreateFcn(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to stack_vector_ops (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function code_canvas_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to code_canvas (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of code_canvas as text
%        str2double(get(hObject,'String')) returns contents of code_canvas as a double

% --- Executes during object creation, after setting all properties.
function code_canvas_CreateFcn(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to code_canvas (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in parse.
function parse_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global AST;
global Tree;
global code_array;
global program;
% hObject    handle to parse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    if(strcmp(get(handles.parse, 'String'), 'Edit' ))
        set(handles.parse, 'String', 'Parse');

        set(handles.pause, 'Enable', 'off');
        set(handles.run, 'Enable', 'off');
        set(handles.stop, 'Enable', 'off');
        set(handles.ast, 'Enable', 'off');
        set(handles.symtbl, 'Enable', 'off');

        set(handles.line_numbers, 'String', {});
        set(handles.line_numbers, 'Enable', 'off');

        set(handles.code_slider,'Value', 1);
        set(handles.code_slider, 'Visible', 'off');

        set(handles.code_canvas, 'Enable', 'on');
        set(handles.code_canvas,'BackgroundColor',[1,1,1]);
        set(handles.code_canvas, 'String', code_array);
        set(handles.code_canvas, 'Position', [1.0 , 31.461538461538463 , 146.4 , 17.0 ]);


    else

        clc;
        wait_message;
        code_array = get(handles.code_canvas, 'String');
        string = '';
        for i = 1:length(code_array)
            string = strcat(string, code_array{i}, '\n');
        end

        file = fopen('vonNeumann.txt','w');
        fprintf(file,sprintf(string));
        fclose(file);

        set(handles.parse, 'String', 'Edit');
        code_slider_Callback(hObject, eventdata, handles);

        set(handles.code_slider, 'Visible', 'on');

        set(handles.pause, 'Enable', 'off');
        set(handles.stop, 'Enable', 'off');

        set(handles.line_numbers, 'Enable', 'inactive');

        set(handles.code_canvas, 'Enable', 'inactive');
        set(handles.code_canvas, 'Position', [7.0 , 31.461538461538463 , 140.4 , 17.0 ]);
        try
            program = parser('vonNeumann.txt', 1);
            set(handles.code_canvas,'BackgroundColor',[0,1,1]);
            set(handles.run, 'Enable', 'on');
            set(handles.ast, 'Enable', 'on');
            set(handles.symtbl, 'Enable', 'on');

            Tree = AST;
            messagehandle = wait_message;
            messagedata  = guidata(messagehandle);
            delete(messagedata.figure1);
        catch exception
            set(handles.code_canvas,'BackgroundColor',[1,0.9,0]);
            set(handles.run, 'Enable', 'off');
            set(handles.ast, 'Enable', 'off');
            set(handles.symtbl, 'Enable', 'off');

            msgbox(exception.message,'Parsing Error', 'error');
            messagehandle = wait_message;
            messagedata  = guidata(messagehandle);
            delete(messagedata.figure1);
            rethrow(exception);
        end
    end


    %set(handles.parse, 'Enable', 'off');
    %set(handles.pause, 'Enable', 'on');
    %set(handles.stop, 'Enable', 'on');
    %set(handles.save, 'Enable', 'on');




% --- Executes on button press in run.
function run_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global display_List;
global display_Count;
global paused;
global stopped;
global Analysis; % ***** Look into it *****
global program;
%global complexityAnalysis;
%global dynamicAnalysis;

stopped = 0;
% The below if statements checks whether the usr clicked 'dynamic_analysis' or 'classicalFD'
if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis') )
    Analysis = errGraph(); % This is used later on as 'Analysis.count()' & 'Analysis.value()'
elseif(isempty(Analysis) == 0 && strcmp(Analysis.type, 'classicalFD') )
    Analysis = classicalFD_analysis();
else
    Analysis = [];
end

% hObject    handle to run (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.parse, 'Enable', 'off');
set(handles.run, 'Enable', 'off');
paused = 0;
set(handles.pause, 'String', 'Pause');
set(handles.pause, 'Enable', 'on');
set(handles.stop, 'Enable', 'on');
%set_global('completed', 0);
%set_global('ASTcount_1', 1);
%set_global('ASTcount_2', 1);
%temp1.value
%set_global('AST', temp1);
%set_global('st', temp2);
display_List = {};
display_Count = 0;

    try
        wait_message;
        generatedCode;
    catch exception

        set(handles.parse, 'Enable', 'on');
        set(handles.run, 'Enable', 'on');
        set(handles.pause, 'Enable', 'off');
        set(handles.stop, 'Enable', 'off');

        messagehandle = wait_message;
        messagedata  = guidata(messagehandle);
        delete(messagedata.figure1);
        msgbox(exception.message,'Runtime Error', 'error');
        rethrow(exception);
    end
messagehandle = wait_message;
messagedata  = guidata(messagehandle);
delete(messagedata.figure1);
msgbox(sprintf('Program "%s" Completed', program) ,'Successful Completion',  'help');


display_List{display_Count + 1, 1} = '**successful completion**';
if(strcmp( get(handles.mode, 'String') , 'Analysis' ) )
    set(handles.stack_vector_ops, 'String', display_List);
end

%if(display_Count > 1)
%    imagesc( uint8(display_List{display_Count, 2} ), 'Parent', handles.display_canvas);
%end

end_program(hObject, eventdata, handles)
%delete(handles.figure1);
% --- Executes on button press in pause.
function pause_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global paused;
% hObject    handle to pause (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
messagehandle = wait_message;
messagedata  = guidata(messagehandle);

if(strcmp(get(handles.pause, 'String'), 'Pause') )
    set(handles.pause, 'String', 'Resume');
    set(handles.stop, 'Enable', 'off');
    paused = 1;

    delete(messagedata.figure1);
else
    set(handles.pause, 'String', 'Pause');
    set(handles.stop, 'Enable', 'on');
    paused = 0;
    wait_message;

    uiresume(handles.figure1);

end



% --- Executes on button press in stop.
function stop_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global stopped;
stopped = 1;

% --- Executes on button press in save.
function save_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in ast.
function ast_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to ast (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
AST_display();

% --- Executes on button press in symtbl.
function symtbl_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to symtbl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ST_display();

% --- Executes on button press in error.
function error_Callback(hObject, eventdata, handles) %controls what happens when the first buttom in the top right is pressed
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to error (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%global dynamicAnalysis;

global Analysis;
if(strcmp(get(handles.error, 'String'), 'Error') )
    set(handles.mode, 'String', 'Error Analysis Mode');

    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'nonparametric') )

        set(handles.complexity, 'BackgroundColor',  [0.831, 0.816, 0.784], 'Enable', 'off');
        set(handles.error, 'BackgroundColor', [0.831, 0.816, 0.784], 'Enable', 'off');
        set(handles.performance, 'BackgroundColor', [0.831, 0.816, 0.784], 'Enable', 'off');
        set(handles.debugger, 'BackgroundColor',[1, 1, 0], 'Enable', 'on');
        %set(handles.stack_vector_ops, 'Enable', 'inactive', 'String', Analysis.images(), 'Value', Analysis.size());

    else
        set(handles.error, 'BackgroundColor', [0.831, 0.816, 0.784], 'Enable', 'off');
        set(handles.complexity, 'BackgroundColor', [0.831, 0.816, 0.784], 'Enable', 'on');
        set(handles.performance, 'BackgroundColor', [0.831, 0.816, 0.784], 'Enable', 'off');
        set(handles.debugger, 'BackgroundColor', [0.831, 0.816, 0.784], 'Enable', 'on');
    end

    set(handles.error, 'String', 'Gaussian');
    set(handles.complexity, 'String', 'Classical FD');
    set(handles.performance, 'String', 'Nonparametric StdDev');
    set(handles.debugger, 'String', 'Nonparametric');
    set(handles.back, 'Visible', 'on');
    %get(handles.performance)
    %get(handles.debugger)

elseif(strcmp(get(handles.error, 'String'), 'Gaussian') )

    if(isequal(get(handles.error, 'BackgroundColor'), [1, 1, 0])  )
        set(handles.error, 'BackgroundColor', [0.831, 0.816, 0.784]);
        set(handles.performance, 'Enable', 'on');
        set(handles.complexity, 'Enable', 'on');
        set(handles.debugger, 'Enable', 'on');
    else
        set(handles.error, 'BackgroundColor', [1, 1, 0]);
        set(handles.performance, 'Enable', 'off');
        set(handles.complexity, 'Enable', 'off');
        set(handles.debugger, 'Enable', 'off');
    end

elseif(strcmp(get(handles.error, 'String'), 'Work/Tbl') )

    if(isequal(get(handles.error, 'BackgroundColor'), [1, 1, 0])  )
        Analysis = [];
        set(handles.error, 'BackgroundColor', [0.831, 0.816, 0.784]);
        set(handles.performance, 'Enable', 'off');
        set(handles.debugger, 'Enable', 'off');
    else
        if(isequal(get(handles.complexity, 'BackgroundColor'), [1, 1, 0]) == 0)%isempty(Analysis) || ( isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis') == 0 ))
            if(strcmp(get(handles.parse, 'String'), 'Edit') )
                parse_Callback(hObject, eventdata, handles);
            end
            Analysis = dynamic_analysis();
        end

        set(handles.display_canvas, 'Position', [2.0, 0.5384615384615385, 144.6, 30.53846153846154]);
        set(handles.horizontal_slider, 'Visible', 'off');
        set(handles.vertical_slider, 'Visible', 'off');
        set( handles.increase, 'Visible', 'off');
        set( handles.decrease, 'Visible', 'off');
        set( handles.stack_vector_ops, 'Visible', 'off');
        set(handles.display_canvas, 'Visible', 'off');
        set(handles.analysis_table, 'Visible', 'on');
        table_dynamic(handles);

        %uitable(handles.analysis_table,'Data',dynamicAnalysis.table(),'ColumnName',dynamicAnalysis.operations(),'RowName',dynamicAnalysis.equations());%,'Position',[20 20 360 100]

        %complexityAnalysis = [];
        set(handles.error, 'BackgroundColor', [1, 1, 0]);
        set(handles.complexity, 'BackgroundColor', [0.831, 0.816, 0.784]);
        %set(handles.complexity, 'Enable', 'off');
        set(handles.performance, 'Enable', 'off');
        set(handles.debugger, 'Enable', 'off');

    end

elseif(strcmp(get(handles.error, 'String'), 'Err/Tbl') ) %checks if the button currently displays Err/Tbl
     if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'classicalFD'))     %checks if analysis type is classicalFD
        set(handles.display_canvas, 'Position', [2.0, 0.5384615384615385, 144.6, 30.53846153846154]); %sets position of graphics handle
        set(handles.horizontal_slider, 'Visible', 'off'); %turn off handle
        set(handles.vertical_slider, 'Visible', 'off');%turn off handle
        set( handles.increase, 'Visible', 'off');%turn off handle
        set( handles.decrease, 'Visible', 'off');%turn off handle
        set(handles.stack_vector_ops, 'Visible', 'on', 'Enable', 'inactive', 'String', Analysis.equations(), 'Value', 1); %make the operation list inactive but visible
        set(handles.display_canvas, 'Visible', 'off');%turn off handle
        set(handles.analysis_table, 'Visible', 'on');%turn off handle
        cnames = {'Min','Max','Mean', 'Median', 'Variance', 'Std Dev'};%names of table values
        set(handles.analysis_table, 'Data', Analysis.stats(),'ColumnName', cnames, 'Position', [2.0, 0.5384615384615385, 144.6, 30.53846153846154]); %sets table with stats list in global analysis object

        %table_dynamic(handles);

        %uitable(handles.analysis_table,'Data',dynamicAnalysis.table(),'ColumnName',dynamicAnalysis.operations(),'RowName',dynamicAnalysis.equations());%,'Position',[20 20 360 100]

        %complexityAnalysis = [];
        set(handles.error, 'BackgroundColor', [1, 1, 0]);%sets button color
        set(handles.complexity, 'BackgroundColor', [0.831, 0.816, 0.784]);%sets button color
        %set(handles.complexity, 'Enable', 'off');
        set(handles.performance, 'Enable', 'off');%turn off button
        set(handles.debugger, 'Enable', 'off');%turn off button

     end


end

% --- Executes on button press in complexity.
function complexity_Callback(hObject, eventdata, handles)%controls what happens when the second button in the top right is pressed
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global Analysis;
%global dynamicAnalysis;
% hObject    handle to complexity (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%set(handles.complexity, 'BackgroundColor', [0.831, 0.816, 0.784]);
if(strcmp(get(handles.complexity, 'String'), 'Complexity') )

    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis') )

        set(handles.complexity, 'BackgroundColor', [1, 1, 0]);
        set(handles.error, 'BackgroundColor', [0.831, 0.816, 0.784]);
        set(handles.performance, 'BackgroundColor', [0.831, 0.816, 0.784], 'Enable', 'off');
        set(handles.debugger, 'BackgroundColor', [0.831, 0.816, 0.784], 'Enable', 'off');

        set(handles.stack_vector_ops, 'Enable', 'inactive', 'String', Analysis.equations(), 'Value', Analysis.size()); % ***** Look into 'Analysis.eq()' *****
        set(handles.display_canvas, 'Position', [14.4, 4.846153846153847, 132.4, 26.230769230769237]);
        set( handles.increase, 'Visible', 'on');
        set( handles.decrease, 'Visible', 'on');
        set(handles.horizontal_slider, 'Visible', 'on');
        set(handles.vertical_slider, 'Visible', 'on');
        plot_dynamic(handles);  % ***** Could be a potential fnc we can use to graph *****

    else
        set(handles.error, 'BackgroundColor', [0.831, 0.816, 0.784], 'Enable', 'on');
        set(handles.complexity, 'BackgroundColor', [0.831, 0.816, 0.784], 'Enable', 'on');
        set(handles.performance, 'BackgroundColor', [0.831, 0.816, 0.784], 'Enable', 'off');
        set(handles.debugger, 'BackgroundColor', [0.831, 0.816, 0.784], 'Enable', 'off');
    end

    set(handles.mode, 'String', 'Complexity Analysis Mode');

    set(handles.error, 'String', 'Work/Tbl');
    set(handles.complexity, 'String', 'Work/Grf');
    set(handles.performance, 'String', 'Space/Tbl');
    set(handles.debugger, 'String', 'Space/Grf');
    set(handles.back, 'Visible', 'on');
    %get(handles.debugger)
elseif(strcmp(get(handles.complexity, 'String'), 'Classical FD') )%checks if the button currently displays Classical FD

    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'classicalFD')) %checks if analysis type is classicalFD
        set(handles.complexity, 'BackgroundColor', [1, 1, 0]);%sets button color
        set(handles.error, 'BackgroundColor', [0.831, 0.816, 0.784]);%sets button color
        set(handles.performance, 'BackgroundColor', [0.831, 0.816, 0.784], 'Enable', 'off');%sets button color and disable button
        set(handles.debugger, 'BackgroundColor', [0.831, 0.816, 0.784], 'Enable', 'off');    %sets button color and disable button
        %set(handles.display_canvas, 'Visible', 'on', 'Position', [14.4, 4.846153846153847, 132.4, 26.230769230769237]);
        %set(handles.stack_vector_ops, 'Enable', 'inactive', 'String', Analysis.equations(), 'Value', Analysis.size());
        %set(handles.display_canvas, 'Position', [14.4, 4.846153846153847, 132.4, 26.230769230769237]);%sets position of graphics handle
        %set( handles.increase, 'Visible', 'on');%turn on handle
        %set( handles.decrease, 'Visible', 'on');%turn on handle
        %set(handles.horizontal_slider, 'Visible', 'on');%turn on handle
        %set(handles.vertical_slider, 'Visible', 'on');%turn on handle


        %set(handles.display_canvas, 'Visible', 'on', 'Position', [14.4, 4.846153846153847, 132.4, 26.230769230769237]);

    else
        set(handles.complexity, 'BackgroundColor', [1, 1, 0]);%sets button color
        set(handles.error, 'Enable', 'on');%turn on button
        set(handles.performance, 'Enable', 'off');%turn off button
        set(handles.debugger, 'Enable', 'off');      %turn off button
    end

    set(handles.mode, 'String', 'Error Analysis Mode');%sets button string value
    set(handles.error, 'String', 'Err/Tbl');%sets button string value
    set(handles.error, 'Enable', 'on');%turn on button
    set(handles.complexity, 'String', 'Err/Grf');%sets button string value
    set(handles.performance, 'Enable', 'off');%turn off button
    set(handles.debugger, 'Enable', 'off');%turn off button
    set(handles.back, 'Visible', 'on');%turn on button
elseif(strcmp(get(handles.complexity, 'String'), 'Err/Grf') )%checks if the button currently displays Err/Grf
     if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'classicalFD')) %checks if analysis type is classicalFD
        set(handles.complexity, 'BackgroundColor', [1, 1, 0]);%sets button color
        %set(handles.error, 'Enable', 'off');
        set(handles.error, 'BackgroundColor', [0.831, 0.816, 0.784]);%sets button color
        set(handles.performance, 'Enable', 'on');%turn on handle
        set(handles.debugger, 'Enable', 'on');%turn on handle
        set(handles.performance, 'String', 'Next', 'Position', [24.8 7.53846 15.4 1.61538]); %sets position of button handle
        set(handles.debugger, 'String', 'Prev', 'Position', [24.8 4.38462 15.4 1.61538]); %sets position of button handle
        set(handles.stack_vector_ops, 'Visible', 'on', 'Enable', 'on', 'String', Analysis.equations(), 'Value', 1);      %turn on operations list and makes it clickable
        set(handles.display_canvas, 'Visible', 'on', 'Position', [14.4, 4.846153846153847, 132.4, 26.230769230769237]);  %sets position of graphics handle
        set(handles.analysis_table, 'Visible', 'off');%turn off handle
        set( handles.increase, 'Visible', 'on');%turn on handle
        set( handles.decrease, 'Visible', 'on');%turn on handle
        set(handles.vertical_slider, 'Visible', 'on');%turn on handle
        set(handles.horizontal_slider, 'Visible', 'on');%turn on handle
        plot_error(handles);%plots data

     end

elseif(strcmp(get(handles.complexity, 'String'), 'Work/Grf') )
    if(isequal(get(handles.complexity, 'BackgroundColor'), [1, 1, 0])  )
        Analysis = [];
        set(handles.complexity, 'BackgroundColor', [0.831, 0.816, 0.784]);
        %set(handles.error, 'Enable', 'on');
        set(handles.performance, 'Enable', 'off');
        set(handles.debugger, 'Enable', 'off');
    else
        %if(isempty(complexityAnalysis))
        %    if(strcmp(get(handles.parse, 'String'), 'Edit') )
        %        parse_Callback(hObject, eventdata, handles);
        %    end
        %end
        %complexityAnalysis = 'dynamic_analysis';
        %if(isempty(dynamicAnalysis))
        %    dynamicAnalysis = dynamic_analysis();
        %end
        if(isequal(get(handles.error, 'BackgroundColor'), [1, 1, 0]) == 0)  %isempty(Analysis) || ( isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis') == 0 ) )
            if(strcmp(get(handles.parse, 'String'), 'Edit') )
                parse_Callback(hObject, eventdata, handles);
            end
            Analysis = dynamic_analysis();
        end


        set(handles.complexity, 'BackgroundColor', [1, 1, 0]);
        %set(handles.error, 'Enable', 'off');
        set(handles.error, 'BackgroundColor', [0.831, 0.816, 0.784]);
        set(handles.performance, 'Enable', 'off');
        set(handles.debugger, 'Enable', 'off');
        set(handles.stack_vector_ops, 'Visible', 'on', 'Enable', 'inactive', 'String', Analysis.equations(), 'Value', Analysis.size());
        set(handles.display_canvas, 'Visible', 'on', 'Position', [14.4, 4.846153846153847, 132.4, 26.230769230769237]);
        set(handles.analysis_table, 'Visible', 'off');
        set( handles.increase, 'Visible', 'on');
        set( handles.decrease, 'Visible', 'on');
        set(handles.vertical_slider, 'Visible', 'on');
        set(handles.horizontal_slider, 'Visible', 'on');

        plot_dynamic(handles);
    end

end
% --- Executes on button press in performance.
function performance_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global Analysis;
% hObject    handle to performance (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(strcmp(get(handles.error, 'String'), 'Performance') )

elseif(strcmp(get(handles.performance, 'String'), 'Worst case') )

    if(isequal(get(handles.performance, 'BackgroundColor'), [1, 1, 0])  )
        set(handles.performance, 'BackgroundColor', [0.831, 0.816, 0.784]);
        set(handles.error, 'Enable', 'on');
        set(handles.complexity, 'Enable', 'on');
        set(handles.debugger, 'Enable', 'on');
    else
        set(handles.performance, 'BackgroundColor', [1, 1, 0]);
        set(handles.error, 'Enable', 'off');
        set(handles.complexity, 'Enable', 'off');
        set(handles.debugger, 'Enable', 'off');
    end

elseif(strcmp(get(handles.performance, 'String'), 'Space/Tbl') )

    if(isequal(get(handles.performance, 'BackgroundColor'), [1, 1, 0])  )
        Analysis = [];
        set(handles.performance, 'BackgroundColor', [0.831, 0.816, 0.784]);
        set(handles.error, 'Enable', 'on');
        set(handles.complexity, 'Enable', 'on');
        %set(handles.debugger, 'Enable', 'on');
    else
        set(handles.performance, 'BackgroundColor', [1, 1, 0]);
        set(handles.error, 'Enable', 'off');
        set(handles.complexity, 'Enable', 'off');
        %set(handles.debugger, 'Enable', 'off');
        set(handles.debugger, 'BackgroundColor', [0.831, 0.816, 0.784]);
    end
elseif(strcmp(get(handles.performance, 'String'), 'Next') ) %checks if the button currently displays Next
     if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'classicalFD'))   %checks if analysis type is classicalFD
        set(handles.complexity, 'BackgroundColor', [1, 1, 0]);%sets button color
        %set(handles.error, 'Enable', 'off');
        set(handles.error, 'BackgroundColor', [0.831, 0.816, 0.784]);%sets button color
        set(handles.performance, 'Enable', 'on');%turn on handle
        set(handles.debugger, 'Enable', 'on');%turn on handle
        set(handles.performance, 'String', 'Next');%sets button string value
        set(handles.debugger, 'String', 'Prev'); %sets button string value
        set(handles.stack_vector_ops, 'Visible', 'on', 'Enable', 'on', 'String', Analysis.equations(), 'Value', Analysis.size());%turn on operation list and make it clickable
        set(handles.display_canvas, 'Visible', 'on', 'Position', [14.4, 4.846153846153847, 132.4, 26.230769230769237]);%sets position of graphics handle
        set(handles.analysis_table, 'Visible', 'off');%turn off handle
        set( handles.increase, 'Visible', 'on');%turn on handle
        set( handles.decrease, 'Visible', 'on');%turn on handle
        set(handles.vertical_slider, 'Visible', 'on');%turn on handle
        set(handles.horizontal_slider, 'Visible', 'on');%turn on handle
        Value = Analysis.inc();%increment the pointer to the values to be plotted
        plot_error(handles);%plot data
        set(handles.stack_vector_ops, 'Value', Value); %highlight the operation in the operation list that is being plotted
     end
end

% --- Executes on button press in debugger.
function debugger_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global Analysis;
% hObject    handle to debugger (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(strcmp(get(handles.error, 'String'), 'Debugger') )

elseif(strcmp(get(handles.debugger, 'String'), 'Nonparametric') )

    if(isequal(get(handles.debugger, 'BackgroundColor'), [1, 1, 0])  )
        Analysis = [];
        set(handles.error, 'Enable', 'off');
        set(handles.complexity, 'Enable', 'off');
        set(handles.performance, 'Enable', 'off');
        set(handles.debugger, 'BackgroundColor', [0.831, 0.816, 0.784]);
    else
        if(strcmp(get(handles.parse, 'String'), 'Edit') )
            parse_Callback(hObject, eventdata, handles);
        end
        Analysis = nonparametric_analysis();

        set(handles.error, 'Enable', 'off');
        set(handles.complexity, 'Enable', 'off');
        set(handles.performance, 'Enable', 'off');
        set(handles.debugger, 'BackgroundColor', [1, 1, 0]);
    end
elseif(strcmp(get(handles.debugger, 'String'), 'Space/Grf') )

    if(isequal(get(handles.debugger, 'BackgroundColor'), [1, 1, 0])  )
        Analysis = [];
        set(handles.debugger, 'BackgroundColor', [0.831, 0.816, 0.784]);
        set(handles.error, 'Enable', 'on');
        set(handles.complexity, 'Enable', 'on');
        %set(handles.performance, 'Enable', 'on');
    else

        set(handles.debugger, 'BackgroundColor', [1, 1, 0]);
        set(handles.error, 'Enable', 'off');
        set(handles.complexity, 'Enable', 'off');
        %set(handles.performance, 'Enable', 'off');
        set(handles.performance, 'BackgroundColor', [0.831, 0.816, 0.784]);
    end
elseif(strcmp(get(handles.debugger, 'String'), 'Prev') )%checks if the button currently displays Prev
     if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'classicalFD'))     %checks if analysis type is classicalFD
        set(handles.complexity, 'BackgroundColor', [1, 1, 0]);%sets button color
        %set(handles.error, 'Enable', 'off');
        set(handles.error, 'BackgroundColor', [0.831, 0.816, 0.784]);%sets button color
        set(handles.performance, 'Enable', 'on');%turn on handle
        set(handles.debugger, 'Enable', 'on');%turn on handle
        set(handles.performance, 'String', 'Next');%sets button string value
        set(handles.debugger, 'String', 'Prev');%sets button string value
        set(handles.stack_vector_ops, 'Visible', 'on', 'Enable', 'on', 'String', Analysis.equations(), 'Value', Analysis.size());%turn on operation list and make it clickable
        set(handles.display_canvas, 'Visible', 'on', 'Position', [14.4, 4.846153846153847, 132.4, 26.230769230769237]);%sets position of graphics handle
        set(handles.analysis_table, 'Visible', 'off');%turn off handle
        set( handles.increase, 'Visible', 'on');%turn on handle
        set( handles.decrease, 'Visible', 'on');%turn on handle
        set(handles.vertical_slider, 'Visible', 'on');%turn on handle
        set(handles.horizontal_slider, 'Visible', 'on');%turn on handle
        Value = Analysis.dec();%decrement the pointer to the values to be plotted
        plot_error(handles);%plot data
        set(handles.stack_vector_ops, 'Value', Value);%highlight the operation in the operation list that is being plotted
     end
end

% --------------------------------------------------------------------
function File_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to File (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Edit_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to Edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function View_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to View (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Window_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to Window (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Help_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to Help (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function New_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to New (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global display_List;
global display_Count;
global code_array;

options.Interpreter = 'tex';
options.Default = 'No';
qstring = 'Are you sure you want to erase everything?';
choice = questdlg(qstring,'New','Yes','No',options);
if(strcmp(choice, 'Yes'))

    set(handles.parse, 'Enable', 'on');
    set(handles.run, 'Enable', 'off');
    set(handles.pause, 'Enable', 'off');
    set(handles.stop, 'Enable', 'off');
    set(handles.ast, 'Enable', 'off');
    set(handles.symtbl, 'Enable', 'off');

    set(handles.parse, 'String', 'Parse');
    set(handles.pause, 'String', 'Pause');
    code_array = {};
    display_List = {};
    display_Count = 0;
    set(handles.code_canvas, 'String', {});
    set(handles.code_canvas, 'Enable', 'on');
    set(handles.code_canvas,'BackgroundColor',[1,1,1]);
    set(handles.code_canvas, 'Position', [2.0, 0.5384615384615385, 144.6, 30.53846153846154]);
    set(handles.code_slider, 'Visible', 'off');
    set(handles.code_slider,'Value', 1);
end
% --------------------------------------------------------------------
function Open_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global code_array;
% hObject    handle to Open (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
   name = uigetfile({'*.txt','All Text Files';'*.*','All Files' },'Open IApCode','IApCode.txt');

    if ~isequal(name, 0)
        fid=fopen(name, 'r');
        M = textscan(fid, '%s', 'whitespace', '');
        N = M{1};
        code_array = rsplit('\n',N{1});

        %set(handles.parse, 'String', 'Parse');
        %set(handles.code_canvas, 'Enable', 'on');
        %set(handles.run, 'Enable', 'off');
        %set(handles.ast, 'Enable', 'off');
        %set(handles.symtbl, 'Enable', 'off');
        %set(handles.code_slider, 'Visible', 'off');

        set(handles.code_canvas, 'String', code_array);

        if(strcmp(get(handles.parse, 'String'), 'Edit') )
            set(handles.parse, 'String', 'Parse');

            set(handles.pause, 'Enable', 'off');
            set(handles.run, 'Enable', 'off');
            set(handles.stop, 'Enable', 'off');
            set(handles.ast, 'Enable', 'off');
            set(handles.symtbl, 'Enable', 'off');

            set(handles.line_numbers, 'String', {});
            set(handles.line_numbers, 'Enable', 'off');

            set(handles.code_slider,'Value', 1);
            set(handles.code_slider, 'Visible', 'off');

            set(handles.code_canvas, 'Enable', 'on');
            set(handles.code_canvas,'BackgroundColor',[1,1,1]);
            set(handles.code_canvas, 'Position', [1.0 , 31.461538461538463 , 146.4 , 17.0 ]);
        end

        %set(handles.line_numbers, 'String', {'1','2','3','4','5','6','7','8','10','11','12' });
        %set(handles.code_canvas,'BackgroundColor',[1,1,1]);
        %parse_Callback(hObject, eventdata, handles);
    end

% --------------------------------------------------------------------
function Save_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to Save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
     name = uiputfile({'*.txt','All Text Files';'*.*','All Files' },'Save IApCode','IApCode.txt');

     if ~isequal(name, 0)
        file = fopen(name,'w');

        data = get(handles.code_canvas, 'String');
        string = '';
        for i = 1:length(data)
            string = strcat(string, data{i}, '\n');
        end
        fprintf(file,sprintf(string));
        fclose(file);
     end

% --------------------------------------------------------------------
function Exit_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to Exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
delete(handles.figure1);

% --- Executes on button press in back.
function back_Callback(hObject, eventdata, handles) %controls what happens when back button is pressed. Many handles/buttons are reset to original
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to back (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Analysis;
global display_Count;
global display_List;


set(handles.mode, 'String', 'Analysis');
set(handles.error, 'String', 'Error', 'Enable', 'on', 'BackgroundColor', [0.831, 0.816, 0.784]);
set(handles.complexity, 'String', 'Complexity', 'Enable', 'on', 'BackgroundColor', [0.831, 0.816, 0.784]);
set(handles.performance, 'String', 'Performance', 'Enable', 'off', 'BackgroundColor', [0.831, 0.816, 0.784], 'Position', [6.8 7.53846 33.4 2.61538]);
set(handles.debugger, 'String', 'Debugger', 'Enable', 'off', 'BackgroundColor', [0.831, 0.816, 0.784], 'Position', [6.8 4.38462 33.4 2.61538]);
set(handles.back, 'Visible', 'off');
if(isempty(Analysis) == 0)
    Analysis.type
    if(strcmp(Analysis.type, 'dynamic_analysis'))
        set(handles.complexity, 'BackgroundColor', [1, 1, 0]);

    elseif(strcmp(Analysis.type, 'nonparametric'))
        set(handles.error, 'BackgroundColor', [1, 1, 0]);
    end
end


set(handles.stack_vector_ops, 'Visible', 'on', 'Enable', 'on', 'String', display_List, 'Value', display_Count);
set(handles.analysis_table, 'Visible', 'off', 'Position', [0.8 0.384615 194 30.8462]);
set(handles.display_canvas, 'Position', [2.0, 0.5384615384615385, 144.6, 30.53846153846154]);
set(handles.horizontal_slider, 'Visible', 'off');
set(handles.vertical_slider, 'Visible', 'off');
set( handles.increase, 'Visible', 'off');
set( handles.decrease, 'Visible', 'off');

index = get(handles.stack_vector_ops, 'Value');
colormap(gray);
if(index  > 0 && index <= display_Count)
    imagesc( uint8(display_List{index, 2} ), 'Parent', handles.display_canvas);
else
    imagesc( uint8( 255), 'Parent', handles.display_canvas);
end
set(handles.display_canvas, 'XTick', [], 'YTick', [], 'Xcolor', [0.831, 0.816, 0.784], 'Ycolor', [0.831, 0.816, 0.784]);

% --------------------------------------------------------------------
function Simulate_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to Simulate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Optimize_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to Optimize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on slider movement.
function code_slider_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to code_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
global code_array;

    codeLength = length(code_array);

    ratioValue = 1 - get(handles.code_slider,'Value');

    displayStart = max(0, round((codeLength - 12) * ratioValue ) );
    displayEnd = min(codeLength, 12);
    if(displayEnd ~= 0)
        display_numbers{displayEnd} = 0;
        display_code{displayEnd} = 0;
        for i = 1:displayEnd
            display_numbers{i} = sprintf('%d', displayStart+i);
            display_code{i} = code_array{displayStart+i};
        end

        set(handles.line_numbers, 'String', display_numbers);
        set(handles.code_canvas, 'String', display_code);
    end



% --- Executes during object creation, after setting all properties.
function code_slider_CreateFcn(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to code_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function line_numbers_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to line_numbers (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of line_numbers as text
%        str2double(get(hObject,'String')) returns contents of line_numbers as a double


% --- Executes during object creation, after setting all properties.
function line_numbers_CreateFcn(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to line_numbers (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function end_program(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*


    set(handles.parse, 'Enable', 'on');
    set(handles.run, 'Enable', 'on');
    set(handles.pause, 'Enable', 'off');
    set(handles.stop, 'Enable', 'off');
    set(handles.pause, 'String', 'Pause');



% --- Executes on slider movement.
function vertical_slider_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global Analysis;
% hObject    handle to vertical_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis') )
        plot_dynamic(handles);
    end
    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'classicalFD') )
        plot_error(handles);
    end
    %value = max(plotscale, ( get(handles.vertical_slider, 'Value') ) * (dynamicAnalysis.max() - plotscale) + plotscale );
    %set( handles.display_canvas , 'YLim',  [value-plotscale value ]);
% --- Executes during object creation, after setting all properties.
function vertical_slider_CreateFcn(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to vertical_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function horizontal_slider_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global Analysis;
% hObject    handle to horizontal_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis') )
        plot_dynamic(handles);
    end
    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'classicalFD') )
        plot_error(handles);
    end
    %if(strcmp(complexityAnalysis, 'dynamic_analysis') )
    %    value = max(10, get(handles.horizontal_slider, 'Value') * (dynamicAnalysis.size()- 10)+ 10 );
    %    set( handles.display_canvas , 'XLim',  [value-10 value ]);
    %end
% --- Executes during object creation, after setting all properties.
function horizontal_slider_CreateFcn(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% hObject    handle to horizontal_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in increase.
function increase_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global plotscale;
global Analysis;
% hObject    handle to increase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    plotscale = plotscale*10;
    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis') )
        plot_dynamic(handles);
    end
    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'classicalFD') )
        plot_error(handles);
    end
    %value = max(plotscale, ( get(handles.vertical_slider, 'Value') ) * (dynamicAnalysis.max() - plotscale) + plotscale );
    %set( handles.display_canvas , 'YLim',  [value-plotscale value ]);
    %ylabel(handles.display_canvas, sprintf('10^%d', log10(plotscale)-2 ));

% --- Executes on button press in decrease.
function decrease_Callback(hObject, eventdata, handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global plotscale;
global Analysis;
% hObject    handle to decrease (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    plotscale = max(10, plotscale/10);
    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis') )
        plot_dynamic(handles);
    end
    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'classicalFD') )
        plot_error(handles);
    end
    %value = max(plotscale, ( get(handles.vertical_slider, 'Value') ) * (dynamicAnalysis.max() - plotscale) + plotscale );
    %set( handles.display_canvas , 'YLim',  [value-plotscale value ]);
    %ylabel(handles.display_canvas, sprintf('10^%d', log10(plotscale)-2 ));



function plot_dynamic(handles) % Okay, what does handle represent? 
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global plotscale;
global Analysis;

    p = plot( handles.display_canvas, Analysis.count(), Analysis.values(), '--' );
    xlabel(handles.display_canvas,'operation steps');
    ylabel(handles.display_canvas,  sprintf('x10^%d', log10(plotscale)-1 ));
    legend(handles.display_canvas, Analysis.operations() );
    set(p,'LineWidth',3);


    value = max(10, get(handles.horizontal_slider, 'Value') * (Analysis.size() - 8) + 10 );
    set( handles.display_canvas , 'XLim',  [value-10 value ]);


    value = max(plotscale, ( get(handles.vertical_slider, 'Value') ) * (Analysis.max() - plotscale) + plotscale );
    set( handles.display_canvas , 'YLim',  [value-plotscale value ]);

function table_dynamic(handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS. ALL ERRORS ARE THE RESPONSIBILITY OF
% THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global Analysis;
    set(handles.analysis_table, 'Data',Analysis.table(),'ColumnName',Analysis.operations(),'RowName',Analysis.equations());

function plot_error(handles)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS. ALL ERRORS ARE THE RESPONSIBILITY OF
% THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%global plotscale;
global Analysis;
        values = Analysis.values();
        errcount = Analysis.error_count();
        [counts,bins] = hist(values(errcount,1:size(values,2)),100); % get counts and bin locations for the data in the row of values specified by errcount
         h = barh(handles.display_canvas, bins,counts, 'hist'); %gets graphics handle for plot
         set(get(h,'Parent'),'xdir','r')  %makes the plot horizontal
         xlabel(sprintf('%d', errcount))  %sets the plot label


    %value = max(10, get(handles.horizontal_slider, 'Value') * (Analysis.size() - 8) + 10 );
    value1 = get(handles.horizontal_slider, 'Value');
    set( handles.display_canvas , 'XLim',  [0 (value1*100) + 1] );

    value2 = get(handles.vertical_slider, 'Value');
    set( handles.display_canvas , 'YLim',  [0 300^(value2 - 1)]);
