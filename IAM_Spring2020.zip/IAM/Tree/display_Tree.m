

function [] = display_Tree(tree)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
    
	nodeHolder = ntst_new;

	if (strcmp(tree.value,'nil') == 0)
		output = ' ' ;
        if(tree.noChildren ~= 0)
            stackNode = new_stack_nodeTree(tree);
            nodeHolder = ntst_push(nodeHolder, stackNode);
        else
            sprintf( ' < %s > ' ,tree.type)
            return;
        end
        %output = strcat(output, sprintf( ' < '));
        output = strcat(output, ' < \n');
        ntabs = 0;
		while(~(ntst_empty(nodeHolder)))
			node = ntst_pop(nodeHolder);
            if(node.noVisited == 0)
                %node.ntNode.type
                %node.ntNode.value
                
                if(strcmp(node.ntNode.type, 'identifier') == 1)
%                     node.ntNode
%                     pause;
                    output = strcat(output,sprintf(' %s  ', node.ntNode.value)); 
                    
                    
                elseif(strcmp(node.ntNode.type, 'numlit') == 1 | strcmp(node.ntNode.type, 'boollit' == 1))
                    output = strcat(output,sprintf(' %d  ', node.ntNode.value));
                elseif(strcmp(node.ntNode.type, 'strlit') == 1)
                    output = strcat(output,sprintf(' %s  ', node.ntNode.value));
                elseif(strcmp(node.ntNode.type, 'WEAK_OP') == 1 | strcmp(node.ntNode.type, 'STRONG_OP') == 1)
                    output = strcat(output,sprintf(' %s  ', node.ntNode.value));
                else
                    output = strcat(output,sprintf(' %s  ', node.ntNode.type));
                end
            end

            if(node.ntNode.noChildren ~= 0)
    
                if (node.noVisited == node.ntNode.noChildren) 
                  output = strcat(output,' > \n ');
                  ntabs = ntabs - 1;
                  for i=1:ntabs
                        output = strcat(output,'\t');
                  end
                else
                    node.noVisited = node.noVisited + 1 ;
                    if(node.noVisited == 1)
                     ntabs = ntabs + 1;        
                     output=strcat(output,'< \n');
                      for i=1:ntabs
                        output = strcat(output,'\t');
                      end
                    end
                    nodeHolder = ntst_push(nodeHolder, node);
                    childNode = node.ntNode.firstChild;
                    counter = 1;
                    while(counter < node.noVisited)
                        childNode = childNode.sibling;
                        counter = counter + 1;
                    end
                    child_stack_node = new_stack_nodeTree(childNode);
                    nodeHolder = ntst_push(nodeHolder, child_stack_node);
                 end
            end
            %pause;
        end
          %output = strcat(output,sprintf(' > ' ))
          sprintf(output)
      else
          display('empty_tree');
    end