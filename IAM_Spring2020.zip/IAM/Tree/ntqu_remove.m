

function node = ntqu_pop(ntqu)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

if nargin<1
  error('three input arguments required.');
end
if nargout<1
  error('one output argument required.');
end



if(ntqu.noElements == 0)
	error('Queue is empty');
	ntqu.firstElement = 0;
	ntqu.lastElement = 0;
end
ntqu.noElements =  ntqu.noElements - 1;
node = ntqu.firstElement;
ntqu.firstElement = node.next;
if(ntqu.noElements == 1)
	ntqu.lastElement  = ntqu.firstElement;
end

