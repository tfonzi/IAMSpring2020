

function AST = buildTree(node, noChildren)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*


global stack;
global AST;
global nt_nil;

AST = nt_put(AST,nt_nil, node);
%noChildren
for i=1:noChildren
	childNode = ntst_pop(stack);
    childNode.ntNode.type;
	AST = nt_put(AST,AST, childNode.ntNode);
end

%sprintf(' value in AST... %s' , AST.type)
stackNode = new_stack_node(AST);
stack = ntst_push(stack, stackNode);
