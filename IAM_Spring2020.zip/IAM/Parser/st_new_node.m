

function node = st_new_node(level, name, type, arrayType, value, ptr_range, ptr_coord)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

  global nt_nil

  node=ptr;
  node.level = level;
  node.name=name;
  node.type = type;
  node.arrayType = arrayType;
  node.value = value;
  node.ptr_range = ptr_range;
  node.ptr_coord = ptr_coord;
  node.next = 0;
  node.scan = 0;
  node.connectivity = 0;