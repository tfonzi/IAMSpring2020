

function listObject = operand_size_bits_analysis() 
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

prettyPrint = {};
prettyPrintCounter = 1;


  listObject = struct('type', 'operand_size_bits',...
                      'expression', @printNode,...
                      'assign', @prettyAssign,...
                      'print',@printPretty); 
 
                  
    function value = printNode(AST)
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

        if(AST.noChildren < 2)
            if(strcmp(AST.type, '()'))
                value = sprintf('(%s)', printNode(AST.firstChild));
            elseif(strcmp(AST.type, '-'))
                value = printNode(AST.firstChild);
                prettyPrint{end+1} = sprintf('-%s', value);
            elseif(strcmp(AST.type, 'numlit'))
                value = sprintf('%d', AST.value);
                prettyPrint{end+1} = sprintf('$%d', AST.value);
            else
                value = AST.value;
                prettyPrint{end+1} = sprintf('$%s', AST.value);
            end

        elseif(AST.noChildren == 2)
            value1 = printNode(AST.firstChild);
            value2 = printNode(AST.firstChild.sibling);
            value = sprintf('%s %s %s', value1, AST.type, value2);
            prettyPrint{end+1} = value;

        elseif(AST.noChildren == 3)
            value1 = printNode(AST.firstChild);
            value2 = printNode(AST.firstChild.sibling);
            value3 = printNode(AST.firstChild.sibling.sibling);
            value = sprintf('%s(%s %s %s)', AST.type, value1, value2, value3);
            prettyPrint{end+1} = value;
        else
            disp_error('Error', 'AST cannot have more than 3 children');
        end
    end

    function prettyAssign(assign)
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        prettyPrint{end+1} = sprintf('%s = %s', assign, prettyPrint{end} );
    end


    function printPretty()
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        value = prettyPrint{prettyPrintCounter};
        while(strcmp(value(1), '$' ))
            display(sprintf('%d : %s', prettyPrintCounter, value(2:length(value) ) ));
            prettyPrintCounter = prettyPrintCounter + 1;
            value = prettyPrint{prettyPrintCounter};
        end
        display(sprintf('%d : %s', prettyPrintCounter, value));
        prettyPrintCounter = prettyPrintCounter + 1;
    end

                 

end