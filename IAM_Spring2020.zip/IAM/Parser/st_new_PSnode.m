
function node = st_new_PSnode(level, name, type, arrayType, value, ptr_range, ptr_coord, ptr_scan, ptr_connectivity)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

  global nt_nil
  global st;
  
  node=ptr;
  node.level = level;
  node.name= name;
  node.type = type;
  node.arrayType = arrayType;
  node.value = value;
  node.ptr_range = ptr_range;
  node.ptr_coord = ptr_coord;
  node.next = 0;
  node.scan = ptr_scan;
  node.connectivity = ptr_connectivity;
  node.maptree = 0;
  node.JMED = 0;
  node.Bits = 10;
  node.Noise = 2;
  
  if(ptr_range ~= 0)
      temp =ptr_range.firstElement;
      for i = 1:ptr_range.noElements
          %start1 = ntqu_search(st, temp.start_range);
          start1 = st.search(temp.start_range);
          if(start1 ~= 0)
              infimum(i) = start1.value;
          else
              infimum(i) = temp.start_range;
          end
          %end1 = ntqu_search(st, temp.end_range);
          end1 = st.search(temp.end_range);
          if(end1 ~= 0)
              supremum(i) = end1.value;
          else
              supremum(i) = temp.end_range;
          end
          temp = temp.next;
      end
      node.infimum = infimum;
      node.supremum = supremum;
  else
      node.infimum = 0;
      node.supremum = 0;
  end
  
  %node.JMED = randint(100,256,[0,255]);
  %dlmwrite(sprintf('%s.jme', name),  node.JMED);

