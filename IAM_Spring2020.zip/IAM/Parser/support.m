

function values = support(template, coord)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;

%node = ntqu_search(st, template);

if(strcmp(template.arrayType, 'tpl') || strcmp(template.arrayType, 'rtpl'))
    
    %dimension = template.ptr_range.firstElement
    
    %dimensionHelper(dimension, value.ptr_range.noElements)
    
    %for i = dimension.start_range:dimension.end_range
        
    
    if(template.ptr_range.noElements == 2)

        targetpixal = [template.ptr_coord.firstElement.coord, template.ptr_coord.firstElement.next.coord ];
        
        temp = 1;
        for i = template.ptr_range.firstElement.start_range:template.ptr_range.firstElement.end_range
            for j = template.ptr_range.firstElement.next.start_range:template.ptr_range.firstElement.next.end_range
                tempcoord = [i j] - targetpixal
                values(temp) = tempcoord
                temp = temp + 1;
            end
        end
    end
    values
else(strcmp(template.arrayType, 'vartpl'))
    
end

%function dimensionHelper(dimension, count)
%
%if(count ~= 0)
%    for i = dimension.start_range:dimension.end_range
%            dimensionHelper(dimension.next, count-1)
%    end
%else
    
%end

%function connectivity = support(value, coord, template, targetcoord)

%shift = targetcoord - template.infimum;
%
%if(value.ptr_range.noElements = 2)
    
%    for i = template.ptr_range.firstElement.start_range:template.ptr_range.firstElement.end_range
%%        for i = template.ptr_range.firstElement.next.start_range:template.ptr_range.firstElement.next.end_range
 %           
 %       end
%    end
%end

%targetcoord = [0,0]
%coord = [4,4]

%connectivity(1) = [4,4]
%connectivity(2) = [5,4]
%connectivity(3) = [6,4]
%connectivity(4) = [4,5]
%connectivity(5) = [5,5]
%connectivity(6) = [6,5]
%connectivity(7) = [4,6]
%connectivity(8) = [5,6]
%connectivity(9) = [6,6]
