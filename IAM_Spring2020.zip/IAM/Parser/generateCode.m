
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: generateCode
%% Inputs: fileName: Name of the .obj file to be generated
%%         AST : The abstract syntax tree constructed from the parser
%% Output: None
%% Description:
%% This function generates the MATLAB code from the abstract syntax tree generated from the Image Algebra code.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [] = generateCode()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global output;
global AST;
    output = (' ' );
    output = strcat( output, '%%%% Program:');
    output = strcat( output, sprintf('  %s', AST.value));
    output = strcat( output, '\n%%%% Date Generated:');
    output = strcat( output, sprintf('  %s', date));
    output = strcat( output, '\n%%%% Developed by: Eric Hayden\n');
    addSymbolTable;
    output = strcat( output, '\n%%%% Start of MATLAB Image Algebra Code\n');
    output = strcat( output ,'global tempCount;\nglobal stack;\nstack = ntst_new;\ntempCount = 0;\n');
    if(strcmp(AST.type, 'program'))
        node = AST.firstChild;
        for i=1:AST.noChildren
            if(strcmp(node.type ,'All_Var_Dec'))
                printAllVarDec(node,AST.type);
            else
                if(strcmp(node.type ,'Command_Sequence'))
                    output= strcat(output, '\n');
                    printCommandSequence(node);
                end
            end
            node = node.sibling;
        end
    elseif(strcmp(AST.type, 'function'))
        if(strcmp(AST.firstChild.type ,'All_Params') == 0)
            output = strcat(output, sprintf('function %s()',fileName));
            output = strcat( output , '\n');
        end
        node = AST.firstChild;
        for i=1:AST.noChildren
            if(strcmp(node.type ,'All_Params'))
                output = strcat(output, sprintf('function %s(',fileName));
                printAllVarDec(node,AST.type);
                output = output(1 : length(output)-1);
                output = strcat( output , ')\n');
            elseif(strcmp(node.type ,'All_Var_Dec'))
                printAllVarDec(node,'program');
            elseif(strcmp(node.type ,'Command_Sequence'))
                output= strcat(output, '\n');
                printCommandSequence(node);
            end
            node = node.sibling;
        end
    end
    output = strcat( output, '%%%% End of MATLAB Image Algebra Code\n');
    file = fopen('generatedCode.m','w');
    fprintf(file,sprintf(output));
    fclose(file);

    sprintf(output)
    return;
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printCommandSequence
%% Inputs: AST : The abstract syntax tree constructed from the parser
%% Output: None
%% Description:
%% This function generates the MATLAB for the command sequences.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 function [] = printCommandSequence(AST)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*     
     
 node = AST.firstChild;
    for i=1:AST.noChildren
         printCommand(node);
         node = node.sibling;
    end
 return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printCommand
%% Inputs: node : The node whose MATLAB is to be generated
%% Output: None
%% Description:
%% This function generates the MATLAB for the given command.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 function [] = printCommand(node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*     
     
 global output; 
 global st;
 global tempCount;
  hyphen = 39;
 %global debug;
%  node.type
%  pause;
 if(strcmp(node.type , 'procedure'))
     evaluateProcedure(node);     
 elseif(strcmp(node.type , 'assign'))
     LHS = node.firstChild;
     RHS = node.firstChild.sibling;

     tempCount = 0;
     value = evaluateExpression(RHS.firstChild);
     
     if(LHS.noChildren ~= 0)
        output = strcat(output, ' [');     
         varNode = LHS.firstChild;    
        for i=1:LHS.noChildren
            output = strcat(output, sprintf(' %s', varNode.value));
            varNode = varNode.sibling;
        end
        output = strcat( output, ' ] =');
     else
         %output = strcat(output, sprintf( '%s =', LHS.value));
     end
    %if(value.name ~= value.value)
    %    name = '0';
    %else
    %    name = value.name;
    %end
     output = strcat(output, sprintf( '%s = assign(%s, %c%s%c, %c%s%c)', LHS.value, value.name, hyphen, value.name, hyphen, hyphen, LHS.value, hyphen));
     output = strcat( output , '; \n\n');
 elseif(strcmp(node.type , 'assignArray'))
     stvalue = st.search(node.firstChild.value);
     if(stvalue ~= 0)
         arrayNode = node.firstChild.sibling;
         for i = 1:node.noChildren-2
             arrayNode = arrayNode.sibling;
         end
         tempCount = 0;
         symbol = evaluateExpression(arrayNode.firstChild);
         
         % %s = vectorPut(%s, [%d, %d, %d ] , assign(%d, %d', '%s') );
         
         %output = strcat(output, sprintf('%s = vectorPut(%s, [', node.firstChild.value, node.firstChild.value));
         output = strcat(output, sprintf('%s.put( [', node.firstChild.value));
         arrayNode = node.firstChild.sibling;
         
         range = stvalue.ptr_range.firstElement;
         stvalue = st.search(range.start_range);
         if(stvalue == 0)
             output = strcat(output, sprintf('%d', arrayNode.value));
         else
             output = strcat(output, sprintf('%s', arrayNode.value));
         end
         arrayNode = arrayNode.sibling;
         
         for i = 1:node.noChildren-3
             range = range.next;
             stvalue = st.search(range.start_range);
             if(stvalue == 0)
                 output = strcat(output, sprintf(', %d', arrayNode.value));
             else
                 output = strcat(output, sprintf(', %s', arrayNode.value));
             end
             arrayNode = arrayNode.sibling;
         end
         
         output = strcat(output, sprintf('] , assign(%s, %c%s%c, 0) );', symbol.name, hyphen, symbol.name, hyphen));

         
         
         %output = strcat(output, sprintf('%s(', node.firstChild.value));
         
         %arrayNode = node.firstChild.sibling;
         
         %range = stvalue.ptr_range.firstElement;
         %stvalue = ntqu_search(st, range.start_range);
         %if(stvalue == 0)
         %    output = strcat(output, sprintf('%s - %d + 1', arrayNode.value, range.start_range));
         %else
         %    output = strcat(output, sprintf('%s - %s + 1', arrayNode.value, stvalue.name));
         %end
         %arrayNode = arrayNode.sibling;
         
         %for i = 1:node.noChildren-3
         %    range = range.next;
         %    stvalue = ntqu_search(st, range.start_range);
        %     if(stvalue == 0)
        %         output = strcat(output, sprintf(',%s - %d + 1', arrayNode.value, range.start_range));
         %    else
         %        output = strcat(output, sprintf(',%s - %s + 1', arrayNode.value, stvalue.name));
         %    end
         %    arrayNode = arrayNode.sibling;
         %end
         
         
         %output = strcat(output, sprintf(') = assign(%s, %c%s%c, %c%s%c);', symbol.name, hyphen, symbol.name, hyphen, hyphen, node.firstChild.value, hyphen));
         
             %end
         output = strcat(output, '\n');
     end
 elseif(strcmp(node.type , 'if_statement'))
     
     expr = node.firstChild;
     output= strcat(output, 'if(');
     statement = node.firstChild.sibling;
     
     if(strcmp(expr.type, 'expression'))
         evaluateCondition(expr.firstChild);
     end
     output= strcat(output, ') \n');
     if(strcmp(statement.type, 'Command_Sequence'))
         printCommandSequence(statement);
     end
     if(node.noChildren == 3)
        elsepart = node.firstChild.sibling.sibling;
        elsenode = elsepart.firstChild;
        for i=1:elsepart.noChildren
            
            if(strcmp(elsenode.type , 'else_if'))
                expr = elsenode.firstChild;
                statement = elsenode.firstChild.sibling;
                output= strcat(output, 'elseif(');
                if(strcmp(expr.type, 'expression'))
                    evaluateCondition(expr.firstChild);
                end
                output= strcat(output, ') \n');
            else
                statement = elsenode.firstChild;
                output= strcat(output, 'else\n');
            end
            if(strcmp(statement.type, 'Command_Sequence'))
                printCommandSequence(statement);
            end
            elsenode = elsenode.sibling;
        end
     end
     output =  strcat(output, 'end');
     output= strcat(output, '\n');
 elseif(strcmp(node.type , 'dowhile_statement'))
     expr =  node.firstChild.sibling;
     statement = node.firstChild;
     output= strcat(output, '\n'); 
     if(strcmp(statement.type, 'Command_Sequence'))
         printCommandSequence(statement);
     end
     output= strcat(output, 'while (');     
     if(strcmp(expr.type, 'expression') ==1)
         evaluateCondition(expr.firstChild);
     end
     output= strcat(output, ') \n');
     if(strcmp(statement.type, 'Command_Sequence'))
         printCommandSequence(statement);
     end
     output =  strcat(output, 'end');
     output= strcat(output, '\n\n');     
 elseif(strcmp(node.type , 'while_statement'))
     statement =  node.firstChild.sibling;
     expr = node.firstChild;
     output= strcat(output, '\nwhile (');
     
     if(strcmp(expr.type, 'expression') ==1)
      
         evaluateCondition(expr.firstChild);
     end
     output= strcat(output, ') \n');
     if(strcmp(statement.type, 'Command_Sequence'))
         printCommandSequence(statement);
     end
     output =  strcat(output, 'end');
     output= strcat(output, '\n\n');
 elseif(strcmp(node.type , 'for_statement'))
     statement =  node.firstChild.sibling;
     forstart = node.firstChild.firstChild.sibling;
     forend = node.firstChild.firstChild.sibling.sibling;

     if(strcmp(forstart.type , 'numlit') && strcmp(forend.type , 'numlit'))
        range = sprintf(' %d:%d', forstart.value, forend.value);
     elseif(strcmp(forstart.type , 'identifier') && strcmp(forend.type , 'numlit'))
        range = sprintf(' %s:%d', forstart.value, forend.value);
     elseif(strcmp(forstart.type , 'numlit') && strcmp(forend.type , 'identifier'))
        range = sprintf(' %d:%s', forstart.value, forend.value);
     elseif(strcmp(forstart.type , 'identifier') && strcmp(forend.type , 'identifier'))
        range = sprintf(' %s:%s', forstart.value, forend.value);
     else
        range = sprintf(' %c:%c', forstart.value, forend.value);
     end
     value = sprintf(' %s' , node.firstChild.firstChild.value);
     output= strcat(output, '\nfor',value,' =', range );
     output= strcat(output, ' \n');
     if(strcmp(statement.type, 'Command_Sequence') ==1)
         printCommandSequence(statement);
     end
     output =  strcat(output, 'end');
     output= strcat(output, '\n\n');
 elseif(strcmp(node.type,'matlab_sequence'))
     output= strcat(output, node.firstChild.value);
     output= strcat(output, '\n');
     
 end
 %pause;
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: evaluateCondition
%% Inputs: exprNode : The expression node whose MATLAB code is to be generated
%% Output: None
%% Description:
%% This function generates the MATLAB for the given expression operation.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [] = evaluateCondition(node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    
    
global output;
global st;
 if(strcmp(node.type, 'identifier'))
    symbol= st.search(node.value);
    if(symbol == 0)
        display(sprintf('ERROR: %s is not declared',  node.value));
    end
    
    if(node.noChildren > 0)
        range = symbol.ptr_range.firstElement;
        output = strcat(output, sprintf('%s.get(', node.value));
        dimension = node.firstChild;
        if(strcmp(dimension.type, 'identifier'))
            output = strcat(output, sprintf('[ %s', dimension.value));
        else
            output = strcat(output, sprintf('[ %d', dimension.value));
        end
        range = range.next;
        dimension = dimension.sibling;
        for i = 1:node.noChildren-1
            if(strcmp(dimension.type, 'identifier'))
                output = strcat(output, sprintf(', %s', dimension.value));
            else
                output = strcat(output, sprintf(', %d', dimension.value));
            end
            range = range.next;
            dimension = dimension.sibling;
        end
        output = strcat(output,' ])');
    else
        output = strcat(output, sprintf('%s',node.value));
    end
 elseif(strcmp(node.type, 'numlit'))
    output = strcat(output, sprintf('%d',node.value));
 elseif(strcmp(node.type, '()') == 1)
    output = strcat(output, '(');
    evaluateCondition(node.firstChild);
    output = strcat(output, ')');
 else
    if(node.noChildren > 1)
        evaluateCondition(node.firstChild);
        output = strcat(output, sprintf('%s', node.type));
        evaluateCondition(node.firstChild.sibling);
    else
        output = strcat(output, sprintf('%s', node.type));
        evaluateCondition(node.firstChild);
    end
 end
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: evaluateExpression
%% Inputs: node : The expression node whose MATLAB code is to be generated
%% Output: None
%% Description:
%% This function generates the MATLAB for the given compound expression operation.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 function [symbol] = evaluateExpression(node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*     
     
 %global obj_file_handle;
 global output;
 global st;
 global tempCount;
 hyphen = 39;
 forwardslash = 92;
 
 if(strcmp(node.type, 'identifier'))
    symbol= st.search(node.value);
    if(symbol == 0)
        display(sprintf('ERROR: %s is not declared',  node.value));
    end
    
    if(node.noChildren > 0)
        range = symbol.ptr_range.firstElement;
        arraypoint = ' ';
        arraypoint = strcat(arraypoint, sprintf('%s.get(', node.value));
        dimension = node.firstChild;
        %startrange= st.search(range.start_range);
        %if(startrange == 0)
        %    startrange = sprintf('%d',range.start_range);
        %else
        %    startrange = startrange.name;
        %end
        
        if(strcmp(dimension.type, 'identifier'))
            arraypoint = strcat(arraypoint, sprintf('[ %s', dimension.value));
        else
            arraypoint = strcat(arraypoint, sprintf('[ %d', dimension.value));
        end
        range = range.next;
        dimension = dimension.sibling;
        for i = 1:node.noChildren-1
            %startrange= st.search(range.start_range);
            %if(startrange == 0)
            %    startrange = sprintf('%d',range.start_range);
            %else
            %    startrange = startrange.name;
            %end
            if(strcmp(dimension.type, 'identifier'))
                arraypoint = strcat(arraypoint, sprintf(', %s', dimension.value));
            else
                arraypoint = strcat(arraypoint, sprintf(', %d', dimension.value));
            end
            range = range.next;
            dimension = dimension.sibling;
        end
        arraypoint = strcat(arraypoint,' ])');
        symbol = st_new_node(0, arraypoint, 'int', 'nil', arraypoint, 0, 0);
    end
 elseif(strcmp(node.type, 'numlit'))
    symbol = st_new_node(0, sprintf('%d',node.value), 'int', 'nil', sprintf('%d',node.value), 0, 0);
 elseif(strcmp(node.type, '()') == 1)
    symbol = evaluateExpression(node.firstChild);
 else
     
    value1 = evaluateExpression(node.firstChild);
    if(node.noChildren > 1)
        value2 = evaluateExpression(node.firstChild.sibling);
    else
        value2 = 0;
    end
    
    %Generate a temp value
    temp = sprintf('tmp%d', tempCount);
    tempCount = tempCount + 1;
    if(value2 == 0 || strcmp(value1.arrayType, 'image') == 1 || strcmp(value2.arrayType, 'image') == 0)
        symbol = st_new_PSnode(0, temp, value1.type, value1.arrayType, value1.value, value1.ptr_range, value1.ptr_coord, value1.scan, value1.connectivity);
    else
        symbol = st_new_PSnode(0, temp, value2.type, value2.arrayType, value2.value, value2.ptr_range, value2.ptr_coord, value2.scan, value2.connectivity);
    end
    
    if((strcmp(node.type, '(+)') || strcmp(node.type,'!gcon') || strcmp(node.type, '[^]') || strcmp(node.type,'!mmax') || strcmp(node.type, '[v]') || strcmp(node.type,'!mmin') || strcmp(node.type, '(^)') || strcmp(node.type,'!amax') || strcmp(node.type, '(v)') || strcmp(node.type,'!amax') || strcmp(node.type, '(^)<') || strcmp(node.type, '(v)<') || strcmp(node.type, '[^]<') || strcmp(node.type, '[v]<') || strcmp(node.type, '(+)<')) )
        
        output = strcat(output, 'coord = [');
        if(strcmp(value2.arrayType, 'vartpl') == 0)
            nodeR = value2.ptr_coord.firstElement;
            for c=1:value2.ptr_coord.noElements
                output = strcat(output, sprintf(' %d',nodeR.coord));
                nodeR = nodeR.next;
            end
        else
            output = strcat(output, ' 0');
        end
        output = strcat(output, ' ];\n');
    end

    output = strcat(output, sprintf('%s =',symbol.name));
    if(strcmp(node.type, '+'))
        output = strcat(output, sprintf(' IAImgAdd(%s, %c%s%c, %s, %c%s%c, %c%s%c);',value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, '-') && node.noChildren == 1)
        output = strcat( output, sprintf(' IAImgNeg(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, '*'))
        output = strcat(output, sprintf(' IAImgMult(%s, %c%s%c, %s, %c%s%c, %c%s%c);',value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, '^'))
        output = strcat(output, sprintf(' IAImgPower(%s, %c%s%c, %s, %c%s%c, %c%s%c);',value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, '/'))
        output = strcat(output, sprintf(' IAImgDiv(%s, %c%s%c, %s, %c%s%c, %c%s%c);',value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, '@'))
        output = strcat(output, sprintf(' IAImgMap(%s, %c%s%c, %s, %c%s%c, %c%s%c);',value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, '!restrict') || strcmp(node.type, '|_'))
        output = strcat(output,  sprintf(' IASingleBarRestrict(%s, %c%s%c, %s, %c%s%c, %c%s%c);',value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, '!extend') || strcmp(node.type, '|^'))
        output = strcat(output,  sprintf(' IAExtend(%s, %c%s%c, %s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, value2.name,hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, '!union'))
        output = strcat(output,  sprintf(' IAUnion(%s, %c%s%c, %s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, value2.name,hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, '!intsct'))
        output = strcat(output,  sprintf(' IAIntsct(%s, %c%s%c, %s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, value2.name,hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, forwardslash))
        output = strcat(output,  sprintf(' IASubset(%s, %c%s%c, %s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, value2.name,hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif( strcmp(node.type, '(+)') || strcmp(node.type,'!gcon'))
        output = strcat(output,  sprintf(' IAImgConvolve(%s, %c%s%c, %s, %c%s%c, coord, %c%s%c);', value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, '[^]') || strcmp(node.type,'!amax'))
        output = strcat(output,  sprintf(' IAImgAddiMin(%s, %c%s%c, %s, %c%s%c, coord, %c%s%c);', value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, '[v]') || strcmp(node.type,'!amin'))
        output = strcat(output,  sprintf(' IAImgAddiMax(%s, %c%s%c, %s, %c%s%c, coord, %c%s%c);', value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, '(^)')|| strcmp(node.type,'!mmax'))
        output = strcat(output,  sprintf(' IAImgMultMin(%s, %c%s%c, %s, %c%s%c, coord, %c%s%c);', value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, '(v)')|| strcmp(node.type,'!mmin'))
        output = strcat(output,  sprintf(' IAImgMultMax(%s, %c%s%c, %s, %c%s%c, coord, %c%s%c);', value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif( strcmp(node.type, '(+)<') || strcmp(node.type,'!gcon'))
        output = strcat(output,  sprintf(' IAImgRecursiveTemplateConvolve(%s, %c%s%c, %s, %c%s%c, coord, %c%s%c);', value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, '[^]<') || strcmp(node.type,'!amax'))
        output = strcat(output,  sprintf(' IAImgRecursiveTemplateAddiMin(%s, %c%s%c, %s, %c%s%c, coord, %c%s%c);', value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, '[v]<') || strcmp(node.type,'!amin'))
        output = strcat(output,  sprintf(' IAImgRecursiveTemplateAddiMax(%s, %c%s%c, %s, %c%s%c, coord, %c%s%c);', value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, '(^)<')|| strcmp(node.type,'!mmax'))
        output = strcat(output,  sprintf(' IAImgRecursiveTemplateMultMin(%s, %c%s%c, %s, %c%s%c, coord, %c%s%c);', value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, '(v)<')|| strcmp(node.type,'!mmin'))
        output = strcat(output,  sprintf(' IAImgRecursiveTemplateMultMax(%s, %c%s%c, %s, %c%s%c, coord, %c%s%c);', value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'domain'))
        output = strcat( output, sprintf(' domain(%c%s%c, %c%s%c);', hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'!sum'))
        output = strcat( output, sprintf(' IAImgSum(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen)); 
    elseif(strcmp(node.type,'!prod'))
        output = strcat( output, sprintf(' IAImgProd(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'!max'))
        if(node.noChildren == 1)
            output = strcat( output, sprintf(' IAImgMax(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
        else
            output = strcat(output, sprintf(' IAImgMax(%s, %c%s%c, %s, %c%s%c, %c%s%c);',value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
        end
    elseif(strcmp(node.type,'!min'))
        if(node.noChildren == 1)
            output = strcat( output, sprintf(' IAImgMin(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
        else
            output = strcat(output, sprintf(' IAImgMax(%s, %c%s%c, %s, %c%s%c, %c%s%c);',value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
        end
    elseif(strcmp(node.type,'!mean'))
        output = strcat( output, sprintf(' IAImgMean(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'!stdev'))
        output = strcat( output, sprintf(' IAImgStdev(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type, '-'))
        output = strcat(output, sprintf(' IAImgSub(%s, %c%s%c, %s, %c%s%c, %c%s%c);',value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'chi') || strcmp(node.type,'!chi'))
    output = strcat(output, sprintf(' IAImgCHI(%c%s%c, %s, %c%s%c, %s, %c%s%c, %c%s%c);', hyphen, node.firstChild.sibling.sibling.value, hyphen, value2.name, hyphen, value2.name,hyphen, value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'restrict') || strcmp(node.type, '||_'))
    output = strcat(output, sprintf(' IADoubleBarRestrict(%c%s%c, %s, %c%s%c, %s, %c%s%c, %c%s%c);', hyphen, node.firstChild.sibling.sibling.value, hyphen, value2.name, hyphen, value2.name,hyphen, value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'!sin'))
        output = strcat( output, sprintf(' IAImgSin(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'!cos'))
        output = strcat( output, sprintf(' IAImgCos(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'!tan'))
        output = strcat( output, sprintf(' IAImgTan(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'!sinh'))
        output = strcat( output, sprintf(' IAImgSinH(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'!cosh'))
        output = strcat( output, sprintf(' IAImgCosH(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'!tanh'))
        output = strcat( output, sprintf(' IAImgTanH(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'!asin'))
        output = strcat( output, sprintf(' IAImgArcSin(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'!acos'))
        output = strcat( output, sprintf(' IAImgArcCos(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'!atan'))
        output = strcat( output, sprintf(' IAImgArcTan(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'!asinh'))
        output = strcat( output, sprintf(' IAImgArcSinH(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'!acosh'))
        output = strcat( output, sprintf(' IAImgArcCosH(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'!atanh'))
        output = strcat( output, sprintf(' IAImgArcTanH(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'!abs'))
        output = strcat( output, sprintf(' IAImgAbs(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'!exp'))
        output = strcat( output, sprintf(' IAImgExp(%s, %c%s%c, %c%s%c);', value1.name, hyphen, value1.name, hyphen, hyphen, symbol.name, hyphen));
    elseif(strcmp(node.type,'!log'))
        output = strcat( output, sprintf(' IAImgLog(%s, %c%s%c, %s, %c%s%c, %c%s%c);',value1.name, hyphen, value1.name, hyphen, value2.name, hyphen, value2.name, hyphen, hyphen, symbol.name, hyphen));
    else
        disp_error('Runtime', sprintf('Unknown Operation : %s', node.type) );
    end
    output = strcat(output, '\n');
    
 end
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: evaluateProcedure
%% Inputs: node : The procedure node whose MATLAB code is to be generated.
%% Output: None
%% Description:
%% This function generates MATLAB for a procedure
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 function [] = evaluateProcedure(node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*     
     
 global output;
 global st;
 hyphen = 39;
 
 procName = node.firstChild.value;
 
 if(strcmp(procName, 'size') == 1)
     output = strcat(output, ' size (');     
     if(strcmp(node.firstChild.sibling.firstChild.type, 'expression') == 1)
         evaluateCondition(node.firstChild.sibling.firstChild);
         output = strcat(output, ' )');
     else
         display(' Illegal argument for function ');
     end
 elseif(strcmp(procName, 'readimage') ==1)     
     argList = node.firstChild.sibling;     
         if(argList.noChildren == 2)
             if(strcmp(argList.firstChild.type, 'strlit') ==1)
                 fileName = argList.firstChild.value;
                 if(strcmp(argList.firstChild.sibling.type, 'identifier') ==1)
                     iden = argList.firstChild.sibling.value;
                     node = st.search(iden);
                     if(node == 0)
                         disp_error('Runtime', 'Variable not declared');
                     end
                     if(strcmp(node.arrayType, 'image') ~= 1)
                         disp_error('Runtime', 'Variable not an image');
                     end
                     output = strcat(output, sprintf ('%s = update(%c%s%c, %c%s%c);', iden, hyphen, iden, hyphen, hyphen, fileName, hyphen));
                     output = strcat(output, '\n');
                end
             else
                 disp_error('Runtime', 'Invalid value for filename in read Image');
             end
         end
 elseif((strcmp(procName, 'display') ==1) || (strcmp(procName, 'write') ==1))
     argList = node.firstChild.sibling;
     arg = argList.firstChild;
     if(argList.noChildren ~=0)
        if( strcmp(arg.type,'identifier') )
            symbol = st.search(arg.value);%arg.firstChild.value
            if(symbol ~=0 && strcmp(symbol.arrayType,'image'))
                if(argList.noChildren == 1)
                    string = sprintf('Image %s', arg.value);
                elseif(argList.noChildren == 2 )
                    arg2 = arg.sibling;
                    if(strcmp(arg2.type, 'strlit') == 0)
                       disp_error('Runtime', 'Title should be a string');
                    end
                    string = arg2.value;
                else
                    disp_error('Runtime', 'Invalid number of arguments');
                end
                if(strcmp(procName, 'display') ==1)
                    output = strcat( output, sprintf('  figure(%cName%c, %c%s%c);', hyphen, hyphen, hyphen ,string, hyphen));
                    output = strcat( output, '\n  colormap(gray);\n');
                    output = strcat( output, sprintf('  imagesc(uint8(hashmatrix(%s, %c%s%c)-1));', arg.value,  hyphen, arg.value, hyphen));
                    output = strcat( output, '\n\n');
                else
                    output = strcat( output, sprintf('  imwrite(hashmatrix(%s, %c%s%c) -1, %c%s%c);', arg.value, hyphen, arg.value, hyphen, hyphen, arg2.value, hyphen));
                    output = strcat( output, '\n\n');    
                end
            else
                output = strcat(output, sprintf('display(%s);', arg.value ) );
                output = strcat( output, '\n'); 
            end
        elseif( strcmp(arg.type,'strlit') )
            output = strcat(output, sprintf('display(%c%s%c);',hyphen, arg.value, hyphen));
            output = strcat( output, '\n'); 
        else
            disp_error('Runtime', 'Invalid: Expected String or declared variable');
            %arg = arg.sibling;
        end
     end
elseif(strcmp(procName, 'quit') ==1)
    output = strcat( output, 'quit;\n'); 
 end
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printAllVarDec
%% Inputs: AST : The AST whose variable declarations are to be evaluated.
%% Output: None
%% Description:
%% This function generates MATLAB for a variable declaratios
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
 
 function [] = printAllVarDec(AST, program)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*     
     
 node = AST.firstChild;
    for i=1:AST.noChildren
         printVarDec(node, program);
         node = node.sibling;
    end
 return;
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printVarDec
%% Inputs: node : The node which is a declaration
%% Output: None
%% Description:
%% This function calls functions to generate MATLAB code depending on the
%% declaration type (i.e. image, template or variable)
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
 function [] =printVarDec(node, program)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*     
     
 global output;
     
    node = node.firstChild;
    if(strcmp(node.type,'type'))
        %type = node.value;
        node = node.sibling;
%         node.type
%         pause;
        if(strcmp(node.type,'array_list'))
            %node = node.sibling;
            %printArrayList(node);
        elseif(strcmp(node.type,'img_list'))
            %node = node.sibling;
            printImgList(node, program);
        elseif(strcmp(node.type,'tpl_list'))
            %node = node.sibling;
            printImgList(node, program);
        elseif(strcmp(node.type,'matrix_dec'))
            %node = node.sibling;
            printImgMatrix(node);
        elseif(strcmp(node.type,'matlab_sequence'))
            output = strcat(output, node.firstChild.value);
            output = strcat(output, '\n'); 
            
        elseif(strcmp(node.type,'map_dec') || (strcmp(node.type,'variant_template_dec')))
            printMapTree(node);
        elseif(strcmp(node.type,'valset_list'))
            printValSet(node);
        else
            printVarDecList(node, program);
        end
    end
        
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printValSet
%% Inputs: node : The node which generates code for declaration of images
%%         type : The type of the image
%% Output: None
%% Description:
%% The function creates a MATLAB array from the provided valset
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function [] = printValSet(node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    
    
    global output;
    ValsetNode = node.firstChild;
    for i = 1: node.noChildren
        output = strcat( output, sprintf('%s = [', ValsetNode.firstChild.value));
        
        
        if(strcmp(ValsetNode.firstChild.sibling.type, 'identifier'))
            output = strcat( output, ' 0');
            for j = 1:ValsetNode.firstChild.sibling.sibling.value
                output = strcat( output, sprintf(', %d', j));
            end
            
        else
            values = ValsetNode.firstChild.sibling;
            output = strcat( output, sprintf(' %d', values.value));
            values = values.sibling;
            for j = 1:ValsetNode.noChildren-2
                output = strcat( output, sprintf(', %d', values.value));
                values = values.sibling;
            end
        end
        output = strcat( output, ' ];\n');
        
        
        ValsetNode = ValsetNode.sibling;
    end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printMapTree
%% Inputs: node : The node which generates code for declaration of images
%%         type : The type of the image
%% Output: None
%% Description:
%% This function creates a MATLAB tree defined by the code.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function [] = printMapTree(AST)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    
    
    global output;
    output = strcat( output, '\n');
    output = strcat( output, '%%%% Generating Map Tree for variable');
    output = strcat( output, sprintf(' %c%s%c', 39, AST.firstChild.value, 39));
    output = strcat( output, '\n');
    printMapTreeNode(AST.firstChild.sibling);
    output = strcat(output, sprintf('%s = AST;', AST.firstChild.value));
    output = strcat( output, '\n');
    output = strcat( output, '%%%% End of Map Tree generation for variable');
    output = strcat( output, sprintf(' %c%s%c', 39, AST.firstChild.value, 39));
    output = strcat( output, '\n');
    
function [] = printMapTreeNode(node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    
    
global output;
 
 if(node.noChildren > 0)
     currentNode = node.firstChild;
     for i = 1:node.noChildren
         printMapTreeNode(currentNode);
         currentNode = currentNode.sibling;
     end
     output = strcat(output, sprintf('AST = buildTree(nt_new_node(%c%s%c, 0), %d);', 39, node.type, 39, node.noChildren));
     output = strcat( output, '\n'); 
 elseif(strcmp(node.type, 'identifier'))
    output = strcat(output, sprintf('stack = ntst_push(stack, new_stack_node(nt_new_node(%cidentifier%c , %c%s%c)));', 39, 39, 39, node.value, 39));
    output = strcat( output, '\n'); 
 elseif(strcmp(node.type, 'numlit'))
    output = strcat(output, sprintf('stack = ntst_push(stack, new_stack_node(nt_new_node(%cnumlit%c , %d)));', 39, 39, node.value));
    output = strcat( output, '\n'); 
 end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printImgMatrix
%% Inputs: node : The node which generates code for declaration of images
%%         type : The type of the image
%% Output: None
%% Description:
%% This function creates a MATLAB matrix defined by the code.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function [] = printImgMatrix(AST)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
    
global output;
    Row = AST.firstChild.sibling.firstChild;
    
    output = strcat(output, sprintf('matrix = ['));
    while(strcmp(Row.type, 'identifier') == 1)
        Column = Row.firstChild;
        while(strcmp(Column.type, 'identifier') == 1)
            output = strcat(output, sprintf(' %s',Column.value));
            Column = Column.sibling;
        end
        output = strcat(output, ';');
        Row = Row.sibling;
    end
    output = output(1 : length(output)-1);
    output = strcat(output, ' ];\n');
    output = strcat(output, sprintf('%s = update(%c%s%c, matrix);', AST.firstChild.value, 39, AST.firstChild.value, 39));
    output = strcat(output, '\n');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printImgList
%% Inputs: node : The node which generates code for declaration of images
%%         type : The type of the image
%% Output: None
%% Description:
%% This function calls functions to generate MATLAB code for image declarations
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function [] = printImgList(AST, program)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    
    
global output;
global st;

node = AST.firstChild;
for i=1:AST.noChildren-1
            node = node.sibling;
end
if(strcmp(node.type, 'Range_List')~=1)
    return;
end
%nDims = node.noChildren;
%nodeDims = node;
node = AST.firstChild;
for i=1:(AST.noChildren -1)
    if(strcmp(program,'function') == 1)
        output = strcat(output, sprintf ('%s, ', node.value));       
    else
        symbol = st.search(node.value);
        infimum = symbol.infimum;
        output = strcat(output, sprintf ('infimum = [ %d', infimum(1)));
        for j = 2:length(infimum)
            output = strcat(output, sprintf (', %d', infimum(j)));
        end
        output = strcat(output, ' ];\n'); 
        supremum = symbol.supremum;
        output = strcat(output, sprintf ('supremum = [ %d', supremum(1)));
        for j = 2:length(supremum)
            output = strcat(output, sprintf (', %d', supremum(j)));
        end
        output = strcat(output, ' ];\n'); 
        output = strcat(output, sprintf ('%s = matimage(infimum, supremum);',node.value));
        
        %output = strcat(output, sprintf ('%s = hashimage();',node.value));
        output = strcat(output, '\n'); 
    end
    node = node.sibling;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printVarDecList
%% Inputs: AST : The node which is a variable declaration
%% Output: None
%% Description:
%% This function generates MATLAB code for a variable declaration
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  


function [] = printVarDecList(AST, program)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    
    
global output;
    node = AST.firstChild;
    for i=1:AST.noChildren
        if((strcmp(node.type,'var_init') == 1) && (strcmp(program,'function') == 1))
            idenNode = node.firstChild;
            identifier = idenNode.value;
            output = strcat(output, sprintf ('%s, ', identifier));       
        elseif((strcmp(node.type,'var_init') == 1))
%             display('here');
%             node.noChildren
            idenNode = node.firstChild;
            
            identifier = idenNode.value;
            output = strcat(output, sprintf ('%s ', identifier));       
            if(node.noChildren == 2)
                nodeInit = idenNode.sibling;
                 %nodeInit.type
                 %pause;
                if((strcmp(nodeInit.type,'numlit') == 1) || (strcmp(nodeInit.type,'boollit') == 1))
                    output = strcat(output , sprintf(' = %d;' , nodeInit.value));
                else
                    output = strcat(output , sprintf(' = %s;' , nodeInit.value));
                end 
            elseif(node.noChildren == 3)
                %node
                nodeInitreal = idenNode.sibling;
                nodeInitImaginary = nodeInitreal.sibling;
                output = strcat(output , sprintf(' = complex(%d,%d);' , nodeInitreal.value, nodeInitImaginary.value ));
                
            else
                output = strcat( output, ' = 0;');
            end
            output = strcat(output, ' \n ');
        end
        node = node.sibling;
    end
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: addSymbolTable
%% Inputs: AST : None
%% Output: None
%% Description:
%% This function generates the Symbol Table for which the program will use
%% to perform the Image Algebra operations%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function [] = addSymbolTable()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
    
global output;
global st;
hyphen = 39;
output = strcat( output, '\n%%%% Start of Symbol Table Generation\n');

output = strcat( output, 'global st;\nst = symbol_table();\n');
    for i=1:st.size()
        node = st.get(i);
        if(node.ptr_range ~= 0)%Generate Ranges
            output = strcat( output, 'rq = ntqu_new;\n');
            nodeR = node.ptr_range.firstElement;
            for j=1:node.ptr_range.noElements
                
               if(st.search(nodeR.start_range) == 0)
                   startrange = sprintf('%d', nodeR.start_range);   
               else
                   startrange = sprintf('%c%s%c', hyphen, nodeR.start_range, hyphen);   
               end
               if(st.search(nodeR.end_range) == 0)
                   endrange = sprintf('%d', nodeR.end_range);   
               else
                   endrange = sprintf('%c%s%c', hyphen, nodeR.end_range, hyphen);   
               end
                output = strcat(output, sprintf('rq = ntqu_push(rq, range_new_node(%s, %s));',startrange, endrange));%Push range 1 on stack for symbol table
                output = strcat( output, '\n');
                nodeR = nodeR.next;
            end
            rqtext = 'rq';
        else
            rqtext = '0';
        end
        if(node.ptr_coord ~= 0)%Generate Coordinates
            output = strcat( output, 'cq = ntqu_new;\n');
            nodeC = node.ptr_coord.firstElement;
            for k=1:node.ptr_coord.noElements
                
                coord = nodeC.coord;
                output = strcat(output, sprintf('cq = ntqu_push(cq, coord_new_node(%d));', coord));%Push range 1 on stack for symbol table
                output = strcat( output, '\n');
                nodeC = nodeC.next;
            end
            cqtext = 'cq';
        else
            cqtext = '0';
        end
        if(node.scan == 0)%Generate Scan
            scan = '0';
        else
            scan =  sprintf('%c%s%c', hyphen, node.scan, hyphen);
        end
        if(node.connectivity == 0)% Generate Neigbor
            connectivity = '0';
        else
            connectivity =  sprintf('%c%s%c', hyphen, node.connectivity, hyphen);
        end
        if(node.value == 0)%Generate Value
            value = '0';
        else
            value = sprintf('%d',node.value);
        end
        output = strcat(output, sprintf('node = st_new_PSnode(0, %c%s%c, %c%s%c, %c%s%c, %s, %s, %s, %s, %s);', hyphen,node.name, hyphen, hyphen, node.type, hyphen, hyphen,node.arrayType, hyphen, value, rqtext, cqtext, scan, connectivity));%TPL symbol
        output = strcat( output, '\nst.add(node);\n');
    end
    output = strcat( output, '%%%% End of Symbol Table Generation\n');
    %output = strcat( output, 'display_st(st);pause;\n');
  
    
