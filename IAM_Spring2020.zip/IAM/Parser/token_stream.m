
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: token_stream
%% Inputs: name of file
%% Output: a MATLAB struct
%% Side Effects:
%% Description: This function builds an object that can traverse through
%% a series of characters to form tokens
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function ts = token_stream(name) 
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

pos=1;
row = 1;
column = 0;
len = 0;
h = 0;
token = struct('spelling', 0, 'value', 0, 'kind', 0);
inititate(name);

  ts = struct('nextToken',@nextToken,...
              'currentToken',@currentToken,...
              'compare',@compare_token,...
              'compare_kind',@compare_kind,...
              'get',@get_token,...
              'get_kind',@get_kind,...
              'spelling',@get_spelling,...
              'value',@get_value,...
              'kind',@get_kind,...
              'pos',@get_pos,...
              'len',@get_len,...
              'row',@get_row,...
              'column',@get_column,...
              'input',@get_input); 
 
    function inititate(name)
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        file_handle=fopen(name);
        num_array=fread(file_handle);
        h = char(num_array);
        len= size(h);
    end

    function t = nextToken()
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        token.value = 0;
        while((pos<=len(1))&&((strcmp(h(pos),' ')==1)||(int8(h(pos))==9) ||(int8(h(pos))==10)||(int8(h(pos))==13) || (strcmp(h(pos),'#')==1)&&(strcmp(h(pos+1),'#')==1)))

            if((strcmp(h(pos),'#')==1)&&(strcmp(h(pos+1),'#')==1))
                while((int8(h(pos))~=10))%&&(int8(h(pos))~=13)  (int8(h(pos))~=9)&&
                    pos=pos+1;
                end
            end
            if( int8(h(pos))==10 )%(int8(h(pos))==9) || ||(int8(h(pos))==13)
                column = 0;
                row = row + 1;
            end
            pos=pos+1;
        end
        if(pos>len(1))
            disp_error('EOF', 'Unexpected End of File');
        %check for weak op + | - | | | == | != | (+) | [v] | [^] | (v) | (^) 
        %| !sum | !gcon | !amax | !amin | !mmax | !mmin | !max | !min | !chi
        %| !restr | !extend | !restrict | !union | !intersect | !cord | !couple
        elseif(strcmp(h(pos),'!')==1)
            token.spelling=h(pos);
            pos=pos+1;
            temp=pos;

            if((pos<=len(1))&&(strcmp(h(pos),'=')==1))
                token.kind='WEAK_OP';
                token.spelling=strcat(token.spelling,h(pos));
                pos=pos+1;
            elseif(isletter(h(pos)))
                while((pos<=len(1))&& (isletter(h(pos)) || (strcmp(h(pos),'_')==1) || (strcmp(h(pos),'$')==1)))
                    token.spelling=strcat(token.spelling,h(pos));
                    pos=pos+1;
                end
                if(check_strongop(token.spelling))
                    token.kind='STRONG_OP';
                elseif(strcmp(token.spelling, '!ML'))
                    token.kind='RESERVED';
                else   
                    token.kind='STRONG_OP';
                    pos=temp;
                end
            else
                token.kind='STRONG_OP';
            end
        elseif(strcmp(h(pos),'=')==1)
            token.spelling=h(pos);
            pos=pos+1;

            if((pos<=len(1))&&(strcmp(h(pos),'=')==1))
                token.kind='WEAK_OP';
                token.spelling=strcat(token.spelling,h(pos));
                pos=pos+1;
            else
                token.kind='EQUALS';
            end
        elseif(strcmp(h(pos),'(')==1)
            token.spelling=h(pos);
            pos=pos+1;
            if((pos<=len(1))&&(strcmp(h(pos+1),')')==1)&&((strcmp(h(pos),'+')==1)||(strcmp(h(pos),'^')==1)||(strcmp(h(pos),'v')==1)))
                token.kind='WEAK_OP';
                token.spelling=strcat(token.spelling,h(pos));
                token.spelling=strcat(token.spelling,h(pos+1));
                pos=pos+2;
                if(strcmp(h(pos),'<')==1)
                    token.spelling=strcat(token.spelling,h(pos));
                    pos=pos+1;
                end
            else
                token.kind='LPAREN';
            end
        elseif(strcmp(h(pos),'[')==1)
            token.spelling=h(pos);
            pos=pos+1;
            if((pos<=len(1))&&(strcmp(h(pos+1),']')==1)&&((strcmp(h(pos),'+')==1)||(strcmp(h(pos),'^')==1)||(strcmp(h(pos),'v')==1)))
                token.kind='WEAK_OP';
                token.spelling=strcat(token.spelling,h(pos));
                token.spelling=strcat(token.spelling,h(pos+1));
                pos=pos+2;
                if(strcmp(h(pos),'<')==1)
                    token.spelling=strcat(token.spelling,h(pos));
                    pos=pos+1;
                end
            else
                token.kind='LSQUARE';
            end
        elseif(strcmp(h(pos),'+')==1)
            token.kind='WEAK_OP';
            token.spelling=h(pos);
            pos=pos+1;
        elseif(strcmp(h(pos),'@')==1)
            token.kind='WEAK_OP';
            token.spelling=h(pos);
            pos=pos+1;
        elseif(strcmp(h(pos),'-')==1)
            token.kind='WEAK_OP';
            token.spelling=h(pos);
            pos=pos+1;
       elseif(strcmp(h(pos),'|')==1)
            token.kind='WEAK_OP';
            token.spelling=h(pos);
            pos=pos+1;
            if(strcmp(h(pos),'|')==1 && strcmp(h(pos+1),'_')==1)
                token.spelling=strcat(token.spelling,h(pos));
                token.spelling=strcat(token.spelling,h(pos+1));
                pos=pos+2;
            elseif(strcmp(h(pos),'^')==1 || strcmp(h(pos),'_')==1 )
                token.spelling=strcat(token.spelling,h(pos));
                pos=pos+1;
            end
        elseif(strcmp(h(pos),'*')==1)
            token.kind='STRONG_OP';
            token.spelling=h(pos);
            pos=pos+1;
        elseif(strcmp(h(pos),'/')==1)
            token.kind='STRONG_OP';
            token.spelling=h(pos);
            pos=pos+1;
        elseif(strcmp(h(pos),92)==1)
            token.kind='STRONG_OP';
            token.spelling=h(pos);
            pos=pos+1;
        elseif(strcmp(h(pos),'^')==1)
            token.kind='STRONG_OP';
            token.spelling=h(pos);
            pos=pos+1;
        elseif(strcmp(h(pos),'&')==1)
            token.kind='STRONG_OP';
            token.spelling=h(pos);
            pos=pos+1;
        elseif(strcmp(h(pos),'<')==1)
            token.spelling=h(pos);
            pos=pos+1;
            if((pos<=len(1))&&(strcmp(h(pos),'=')==1))
                token.kind='STRONG_OP';
                token.spelling=strcat(token.spelling,h(pos));
                pos=pos+1;
            else
                token.kind='STRONG_OP';
            end
        elseif(strcmp(h(pos),'>')==1)
            token.spelling=h(pos);
            pos=pos+1;
            if((pos<=len(1))&&(strcmp(h(pos),'=')==1))
                token.kind='STRONG_OP';
                token.spelling=strcat(token.spelling,h(pos));
                pos=pos+1;
            else
                token.kind='STRONG_OP';
            end
        elseif(strcmp(h(pos),')')==1)
            token.kind='RPAREN';
            token.spelling=h(pos);
            pos=pos+1;
        elseif(strcmp(h(pos),'{')==1)
            token.kind='LBRACE';
            token.spelling=h(pos);
            pos=pos+1;
        elseif(strcmp(h(pos),'}')==1)
            token.kind='RBRACE';
            token.spelling=h(pos);
            pos=pos+1;
        elseif(strcmp(h(pos),'[')==1)
            token.kind='LSQUARE';
            token.spelling=h(pos);
            pos=pos+1;
        elseif(strcmp(h(pos),']')==1)
            token.kind='RSQUARE';
            token.spelling=h(pos);
            pos=pos+1;
        elseif(strcmp(h(pos),',')==1)
            token.kind='COMMA';
            token.spelling=h(pos);
            pos=pos+1;
        elseif(strcmp(h(pos),';')==1)
            token.kind='SEMI';
            token.spelling=h(pos);
            pos=pos+1;
        elseif(strcmp(h(pos),'.')==1)
            token.kind='SEMI';
            token.spelling=h(pos);
            pos=pos+1;
        elseif(strcmp(h(pos),'%')==1)
            token.kind='PERCENT';
            token.spelling=sprintf('%s%s',h(pos),h(pos));
            pos=pos+1;
        elseif(strcmp(h(pos),':')==1)
            token.spelling=h(pos);
            pos=pos+1;
            if((pos<=len(1))&&(strcmp(h(pos),'=')==1))
                token.kind='ASSIGN';
                token.spelling=strcat(token.spelling,h(pos));
                pos=pos+1;
            else
                token.kind='COLON';
            end
        elseif((int8(h(pos))<=57)&&(int8(h(pos))>=48))
            token.spelling='';

            while((pos<=len(1))&& (((int8(h(pos))<=57)&&(int8(h(pos))>=48)) || (strcmp(h(pos),'.')==1)))
                token.spelling=strcat(token.spelling,h(pos));
            pos=pos+1;
            end
            token.value=str2double(token.spelling);
            token.value;
            token.kind='NUMLIT';
        elseif(strcmp(h(pos),'"'))
            token.spelling = '';
            pos = pos + 1;
            while((pos<=len(1))&& (strcmp(h(pos),'"') ~= 1))
                token.spelling = [token.spelling h(pos)];
                pos=pos+1;
            end
            pos = pos + 1;
            token.kind = 'STRLIT';
        elseif(int8(h(pos))==39)
            %token.spelling = h(pos);
            token.spelling = '';
            pos = pos + 1;
            while((pos<=len(1))&& (int8(h(pos))~=39))
                token.spelling = [token.spelling h(pos)];
                pos=pos+1;
            end
            %token.spelling = [token.spelling h(pos)];
            pos = pos + 1;
            token.kind = 'STRLIT';
        elseif(isletter(h(pos)))
            token.spelling='';

            while((pos<=len(1))&& (isletter(h(pos)) || ((int8(h(pos))<=57)&&(int8(h(pos))>=48)) || (strcmp(h(pos),'_')==1) || (strcmp(h(pos),'$')==1)))
                token.spelling=strcat(token.spelling,h(pos));
                pos=pos+1;
            end
            if(check_reserved(token.spelling))
                token.kind='RESERVED';
            else            
                token.kind='IDEN';
            end
        else
            token.kind='ERROR';
            token.spelling=h(pos);
            pos=pos+1;
            disp_error('Parser:Error', sprintf('Invalid Token ASC(%d) / string(%s)', token.spelling, token.spelling) );
        end
        column = column +1;
        t = token;
    end

    function t = currentToken()
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        t = token;
    end

    function ret = compare_token(expected)
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        ret = strcmp(token.spelling, expected);
    end

    function ret = compare_kind(expected)
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        ret = strcmp(token.kind, expected);
    end

    function t = get_token(expected)
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        t = nextToken();
        if(strcmp(token.spelling, expected) == 0)
            disp_error(token.spelling, sprintf('Expected: "%s"', expected') );
        end

    end

    function t = get_kind(expected)
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        t = nextToken();
        if(strcmp(token.kind, expected) == 0)
            disp_error(token.kind, sprintf('Expected: %s', expected') );
        end
    end

    function p =  get_pos() 
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        p = pos;
    end 

    function l =  get_len() 
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        l = len;
    end 

    function l =  get_input() 
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        l = h;
    end 

    function l =  get_row() 
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        l = row;
    end 

    function l =  get_column() 
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        l = column;
    end 

    function spelling = get_spelling()
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        spelling = token.spelling;
    end

    function value = get_value()
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        value = token.value;
    end


    function ret=check_reserved(check)
        
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

        if(strcmp(check,'program')  || strcmp(check,'map')       || strcmp(check,'function')      || strcmp(check,'on')       ...
        || strcmp(check,'int')      || strcmp(check,'complex')   || strcmp(check,'analysis')      || strcmp(check,'define')   ...
        || strcmp(check,'float')    || strcmp(check,'double')    || strcmp(check,'array')         || strcmp(check,'set')      ...
        || strcmp(check,'image')    || strcmp(check,'tpl')       || strcmp(check,'pointset')      || strcmp(check,'if')       ...
        || strcmp(check,'elseif')   || strcmp(check,'while')     || strcmp(check,'for')           || strcmp(check,'endfor')   ...
        || strcmp(check,'then')     || strcmp(check,'matlab')    || strcmp(check,'void')          || strcmp(check,'else')     ...
        || strcmp(check,'do') ...
        )
            ret=1;
        else
            ret=0;
        end
    end
    %end of check_reserved function
     function ret=check_strongop(check)
         
         % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

    %
    %% Functions implemented as-of 29 April 2004:
    %%    !sum, !max, !min, and all arithmetic ops (+,-,/,*)
    %
        if(strcmp(check,'!sum')   || strcmp(check,'!gray')      || strcmp(check,'!slice')   || strcmp(check,'!prod')    ...
        || strcmp(check,'!gcon')  || strcmp(check,'!amax')      || strcmp(check,'!amin')    || strcmp(check,'!mmax')    ...
        || strcmp(check,'!mmin')  || strcmp(check,'!max')       || strcmp(check,'!min')     || strcmp(check,'!chi')     ...
        || strcmp(check,'!extend')|| strcmp(check,'!restrict')  || strcmp(check,'!union')   || strcmp(check,'!intsct')  ...
        || strcmp(check,'!cord')  || strcmp(check,'!couple')    || strcmp(check,'!stat')    || strcmp(check,'!mean')    ...
        || strcmp(check,'!stdev') || strcmp(check,'!sin')        || strcmp(check,'!cos')      || strcmp(check,'!tan')      ...
        || strcmp(check,'!sinh')   || strcmp(check,'!cosh')       || strcmp(check,'!tanh')                                 ...
        || strcmp(check,'!arcsin') || strcmp(check,'!arccos')     || strcmp(check,'!arctan')                               ...
        || strcmp(check,'!arcsinh')|| strcmp(check,'!arccosh')    || strcmp(check,'!arctanh')  ...
        || strcmp(check,'!exp') || strcmp(check,'!log') || strcmp(check,'!abs')  ...
        )
            ret=1;
        else
            ret=0;
        end
     end

end

