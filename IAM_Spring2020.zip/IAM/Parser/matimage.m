

function listObject = matimage(infimum, supremum) 
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

    dim = length(infimum);
    magnitude = supremum - infimum + 1;
    matrix = zeros(magnitude);
    %indexer = buildIndexer();

   listObject = struct('matrix',@to_matrix_mat,...
                       'populate',@populate_mat,...
                       'clone',@mat_clone,...
                       'get',@get_vector,...
                       'put',@put_vector,...
                       'inc',@inc_vector, ...
                       'display', @display_mat, ...
                       'data', @get_data, ...
                       'set', @set_data); 

    function vector = buildIndexer() 
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
      vector = ones(1:dim);
      scaler = 1;
      for i = 2:dim
          scaler = scaler*magnitude(i-1);
          vector(i) = scaler;
      end
        
    end
                   
    function m = get_data()
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        m = matrix;
    end

    function m = set_data(m)
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        matrix = m;
    end

    function display_mat()
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        display(matrix);
    end

  function mat = mat_clone()
      % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
      
      mat = matimage(infimum, supremum) ;
      mat.populate(infimum, matrix);
  end

  function value = get_vector(vector)
      % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

      if( length(vector) ~= dim || ~isempty(find(vector < infimum, 1)) || ~isempty(find(vector > supremum, 1))  )
          value = 0;
          return;
      end
      

      v = vector - infimum;
      

      
      %index = sum(v .* indexer); %METHOD 3
      
      %METHOD 2
      index = v(1);
      scaler = 1;
      for i = 2:dim
          scaler = scaler*magnitude(i-1);
          index = index + scaler*v(i);
          
      end
      
      value = matrix(index+1);
      
      %METHOD 1
      %v = vector - infimum + 1;
      %command = sprintf('value = matrix( %d', v(1));
      %for i = 2:dim
      %    command = strcat(command, sprintf(' , %d', v(i) ) );
      %end
      %command = strcat(command, ' );');
      %eval(command);
  end

  function put_vector(vector, value)
      % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
       
      if(length(vector) ~= dim || ~isempty(find(vector < infimum, 1)) || ~isempty(find(vector > supremum, 1))  )
          return;
      end
      
      v = vector - infimum;
      
      %index = sum(v .* indexer);
      
      scaler = 1;
      index = v(1);
      for i = 2:dim
          scaler = scaler*magnitude(i-1);
          index = index + scaler*v(i);
          
      end
      
      matrix(index+1) = value;
      
      %command = sprintf('matrix( %d', v(1));
      %for i = 2:dim
      %    command = strcat(command, sprintf(' , %d', v(i) ) );
      %end
      %command = strcat(command, ' ) = value;');
      %eval(command);
      
  end

    function m = to_matrix_mat(i, s)
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
      dim1 = length(i);
      
      if(dim1 ~= dim)
          return;
      end
      

        mag = s - i + 1;
        m = zeros(mag);
        
        
        i1 = max(i, infimum);
        s1 = min(s, supremum);
        
        sp1 = i1 - infimum + 1;
        ep1 = sp1 + (s1 - i1);

        
        sp2 = i1-i + 1;
        ep2 = sp2 + (s1 - i1);
        
        

        
        command = sprintf('m( %d:%d', sp2(1), ep2(1) );
        for i = 2:dim
          command = strcat(command, sprintf(' , %d:%d', sp2(i), ep2(i) ) );
        end
        command = strcat(command, sprintf(' ) = matrix( %d:%d', sp1(1), ep1(1) ) );
        for i = 2:dim
          command = strcat(command, sprintf(' , %d:%d', sp1(i), ep1(i) ) );
        end
        command = strcat( command, ' );');
        eval(command);
        
        
    end

    function populate_mat(i, m)
        % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        
        dim1 = length(i);
        a = size(m);
        dim2 = length(a);
        if(dim1 ~= dim && dim2 ~= dim)
            return;
        end
        s =   i + a - 1;
        
        
        i1 = max(i, infimum);
        s1 = min(s, supremum);
        
        sp1 = i1 - infimum + 1;
        ep1 = sp1 + (s1 - i1);

        
        sp2 = i1-i + 1;
        ep2 = sp2 + (s1 - i1);
        
        
        command = sprintf('matrix( %d:%d', sp1(1), ep1(1) );
        for i = 2:dim
          command = strcat(command, sprintf(' , %d:%d', sp1(i), ep1(i) ) );
        end
        command = strcat(command, sprintf(' ) = m( %d:%d', sp2(1), ep2(1) ) );
        for i = 2:dim
          command = strcat(command, sprintf(' , %d:%d', sp2(i), ep2(i) ) );
        end
        command = strcat( command, ' );');
        eval(command);
        
    end

  function inc_vector(vector)
      % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
      
      dim1 = length(vector);

      if(dim1 ~= dim || ~isempty(find(vector < infimum, 1)) || ~isempty(find(vector > supremum, 1))  )
          return;
      end
      
      v = vector - infimum + 1;
      cmd1 = sprintf(' matrix( %d', v(1));
      for i = 2:dim
          cmd1 = strcat(cmd1, sprintf(' , %d', v(i) ) );
      end
      cmd1 = strcat(cmd1, ' )');
      
      command = strcat(cmd1, ' =', cmd1, ' + 1;' );
      eval(command);
  end
end