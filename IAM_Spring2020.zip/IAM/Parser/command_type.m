
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: command_type
%% Inputs: None
%% Output: Boolean 1 or 0
%% Description:
%% This function determines if the first token is a command type to be parsed.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function ret= command_type()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%<type> ::= int | float | double | bool | void
%global token;

%if( (strcmp(token.kind,'IDEN')==1)||...
%    (strcmp(token.kind,'LPAREN')==1)||...
%    ((strcmp(token.kind,'RESERVED')==1) &&...
%    ((strcmp(token.spelling,'do'))||...
%    (strcmp(token.spelling,'while')==1) ||...
%    (strcmp(token.spelling,'if')==1)||...
%    (strcmp(token.spelling,'for')==1)||...
%    (strcmp(token.spelling,'!ML')==1))) )
%    ret=1;
%else
%    ret=0;
%end

global ts;
if(ts.compare_kind('IDEN')||... 
    ts.compare('(')||... 
    ts.compare('do')||... 
    ts.compare('while')||... 
    ts.compare('if')||... 
    ts.compare('double')||... 
    ts.compare('for')||... 
    ts.compare('!ML') );
    ret=1;
else
    ret=0;
end

