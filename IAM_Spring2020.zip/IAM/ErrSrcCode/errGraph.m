%{ 
    Filename: errGraph.m
    Developer: Kazi R 
    Purpose: To compute the fractional error over 3 repetative arithmetic steps (+, *, +)
    Created On: 02/04/2019
    Last Modified: 02/05/2019
    
    IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS. 
    ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
 
%} 
 
 
%{
 
FUNCTION: errGraph Purpose: Refer above
    
USAGE:
         
INPUTS: None
 
OUTPUT: Fractional Error graph
 
VARIATIONS: N/A
 
%}
 
function [values, count] = errGraph(orgX, muX, stdX, orgY, muY, stdY) 
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

    % ~Hard-coded values for now. In the future, these will come from the image~ --> No more hard-coding 
    x = orgX; 
    deltaX = muX;
    
    y = orgY; 
    deltaY = muY;
    
    %used to determine if top or bottom graop
    top = 0;
    bottom = 0;
    
    %if both std deviations are negative, graph bottom plot
    if ((stdX < 0) && (stdY < 0))
        bottom = 1; %if bottom graph, set to 1
        stdX = -1*stdX;
        stdY = -1*stdY;
    elseif ((stdX > 0) && (stdY > 0)) %if both are positive, graph top plot
        top = 1; %otherwise set top to 1
    else %else if they are both 0, graph normal plot
        %neither of these, normal graph
        top = 0;
        bottom = 0;
    end
    
    z = 0;
    deltaZ = 0;
    
    deltaZ_array = [];
    stdDevZ = [];
    
    accumDeltaZ = 0; % "Err accumulates over time" 
    
   % 10 steps, but the steps is defined as the # of iteration until the image is fully decoded 
   for k = 1:100 % Changed from 10 to 100 to debug scoll bar 
        count(k) = k; % Increase the count 
        
        if (count(k) == 1)  % Step 1: Add
%            [deltaZ, z] = divErr(x, y, muX, muY); % *** FIRST STEP ***
           
           if (top == 1) %top plot
                [deltaZ, z] = divErr(x, y, muX + stdX, muY + stdY);  % *** SECOND STEP ***
           elseif (bottom == 1) %bottom plot
                [deltaZ, z] = divErr(x, y, muX - stdX, muY - stdX);  % *** SECOND STEP ***
           else %normal plot
                [deltaZ, z] = divErr(x, y, muX, muY);  % *** SECOND STEP ***
           end
           
           %code to recalculate StdDev of deltaZ
           deltaZ_array(k) = deltaZ;
           stdDevZ(k) = std(deltaZ_array);
           
           accumDeltaZ = deltaZ;
           % disp(z);   % *** FOR DEBUG PURPOSES ONLY ***
        else % If not Step 1 then perform the following steps 
            if ( (mod(count(k),2)) == 0 ) % Step 2 (or any even steps); We know it's even by doing mod by 2 == 0
                if (top == 1) %top plot
                    [deltaZ, z] = mult_err(z, x, accumDeltaZ + stdDevZ(k-1), deltaX + stdX);  % *** SECOND STEP ***
                elseif (bottom == 1) %bottom plot
                    [deltaZ, z] = mult_err(z, x, accumDeltaZ - stdDevZ(k-1), deltaX - stdX);  % *** SECOND STEP ***
                else %normal plot
                    [deltaZ, z] = mult_err(z, x, accumDeltaZ, deltaX);  % *** SECOND STEP ***
                end    
                %code to recalculate StdDev of deltaZ
                deltaZ_array(k) = deltaZ;
                stdDevZ(k) = std(deltaZ_array);
                
                accumDeltaZ = accumDeltaZ + deltaZ; 
%{
                *** FOR DEBUG PURPOSES ONLY ***
                disp("-----------------------------");
                disp(z);
                disp(deltaZ);
%}
            else % If not step 2 then step 3 (or any odd steps)
%                 [deltaZ, z] = addErr(z, y, accumDeltaZ, deltaY);  

                if (top == 1) %top plot
                    [deltaZ, z] = addErr(z, y, accumDeltaZ + stdDevZ(k-1), deltaY + stdY);  % *** SECOND STEP ***
                elseif (bottom == 1) %bottom plot
                    [deltaZ, z] = addErr(z, y, accumDeltaZ - stdDevZ(k-1), deltaY - stdY);  % *** SECOND STEP ***
                else %normal plot
                    [deltaZ, z] = addErr(z, y, accumDeltaZ, deltaY);  % *** SECOND STEP ***
                end 
                
                %code to recalculate StdDev of deltaZ
                deltaZ_array(k) = deltaZ;
                stdDevZ(k) = std(deltaZ_array);
%{
                *** FOR DEBUG PURPOSES ONLY ***    
                disp("-----------------------------");
                disp(z);
                disp(deltaZ);
%}
                accumDeltaZ = accumDeltaZ + deltaZ;
            end % End of inner If
        end % End of outter If
        
        values(k) = (accumDeltaZ/z); % Keep track of the fractional values as we iteriate  

   end % End of For
   
   % Plot the values 

%    figure;
%    clf;
%    p = stairs(count, values, 'c-.');
%    xlabel("Count");
%    ylabel("deltaZ/z"); 
%    legend("Fractional Err");
%    set(p, 'LineWidth', 2); 
%    
%    figure; 
%    clf;
%    p = loglog(count, values, 'green--');
%    xlabel("Count");
%    ylabel("deltaZ/z"); 
%    legend("Fractional Err");
%    set(p, 'LineWidth', 2); 
%    
%    % Perform assignment to ensure side effect occurs when someone calls my fnc; The side effect will assign the frac. values
%    graphErr = values;  

