%{ 
    Filename: divErr.m
    Developer: Felipe P
    Purpose: To compute the error in an computer division  
    Created On: 02/04/2019
    Last Modified: 03/16/2019
    
    IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS. 
    ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%} 


%{

    FUNCTION: divErr
    Purpose: Refer above 
    
    USAGE:
         
       INPUTS: 
            x: The value of x which should be an natural #. 
            y: The value of y which should be an natural #. 
            deltaX: The error in X 
            deltaY: The error in Y 
            percentGX: The percent error of X. For example, if the user inputs 25 then the program will use "(x) * (0.25)" as deltaX. 
            percentGY: The percent error of Y. Refer above for an example. 

       OUTPUT: The mean forward error x and y. 

      
    VARIATIONS: 
                The below function handles three situations: hard-coded values of deltaX/Y, user defining deltaX/Y, and user defining percentGX/GY. For the first case, use '0' for deltaX/Y. 
                If the user defines deltaX/Y then use a '1' for percentGX/GY. For the last situation, use needs to define all six parameters.   

%}

function [deltaZ, z] = divErr(x, y, deltaX, deltaY)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
           
           % Perform DIV_0 check before dividing
           if (y == 0) % if DIV_0 would occur, display error message and return
                disp("ERROR: DIV BY 0");
                return;
           else %otherwise continue with division
               z = abs(x / y);
           end
           
           % Will be used later but need them declared outside of if statements; Only applicable in first case (Ref below)
           tempVar_HardCoded = 0;
           tempVar_usrDef = 0;
           tempVar_usrDefAll = 0;
           
%            % First case: hard coded values 
%            fprintf("z is: " + z + "\n"); 
%            %Perform DIV_0 check before dividing
%            if (y == 0) %if DIV_0 would occur, display error message and return
%                 disp("ERROR: DIV BY 0");
%                 return;
%            else %otherwise continue with division
%                tempVar_HardCoded = (x + 2)/(y + 2); % deltaX & deltaY = 2 
%            end
%            
%            deltaZ = tempVar_HardCoded  - z; 
%            fprintf("Errs with hard-coded values: " + deltaZ + "\n");

           % Second case: User defines deltaX and deltaY 
           if (y == 0) % if DIV_0 would occur, display error message and return
                disp("ERROR: DIV BY 0");
                return;
           else %otherwise continue with division
              tempVar_usrDef = (x + deltaX)/(y + deltaY); 
           end
           deltaZ = abs(tempVar_usrDef - z);    % NOTE: We are taking the absolute value here  
          % fprintf("Errs with provided errors: " + deltaZ + "\n"); 
%            
%            %Third case: User defines all parameters  
%            if (y == 0) %if DIV_0 would occur, display error message and return
%                 disp("ERROR: DIV BY 0");
%                 return;
%            else %otherwise continue with division
%                tempVar_usrDefAll = (x + (deltaX*(percentGX/100)))/(y + (deltaY*(percentGY/100))); 
%            end
%            deltaZ = tempVar_usrDefAll - z; 
%            fprintf("Errs with provided percentage errors: " + deltaZ + "\n"); 
           
end
