%{
    Filename: addErr.m
    Developer: Kazi R
    Purpose: To compute the error in an computer addition
    Created On: 01/26/2019
    Last Modified: 03/16/2019

    IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%}


%{
    FUNCTION: deltaZ
    Purpose: Refer above

    USAGE:

       INPUTS:
            x: The value of x which should be an natural #.
            y: The value of y which should be an natural #.
            deltaX: The error in X
            deltaY: The error in X
            percentGX: The percent error of X. For example, if the user inputs 25 then the program will use "(x) * (0.25)" as deltaX.
            percentGY: The percent error of Y. Refer above for an example.

       OUTPUT: The mean forward error x and y.


    VARIATIONS:
                The below function handles three situations: hard-coded values of deltaX/Y, user defining deltaX/Y, and user defining percentGX/GY. For the first case, use '0' for deltaX/Y.
                If the user defines deltaX/Y then use a '1' for percentGX/GY. For the last situation, use needs to define all six parameters.

%}

% function [deltaZ, z] = addErr(x, y, deltaX, deltaY, percentGX, percentGY)
function [deltaZ, z] = addErr(x, y, deltaX, deltaY) % We took out the last two params bc it's not our current focus 
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

           % First case: hard coded values
%            z = x + y;
%            fprintf("z is: " + z + "\n");
%            tempVar_HardCoded = (x + 2) + (y + 2) - z; % deltaX & deltaY = 2
%            deltaZ = z + tempVar_HardCoded - z;
%            fprintf("Errs with hard-coded values: " + deltaZ + "\n");

           % Second case: User defines deltaX and deltaY; OUR CURRENT FOCUS 
           z = x + y;
           tempVar_usrDef = (x + deltaX) + (y + deltaY) - z;
           deltaZ = z + tempVar_usrDef - z;
%            fprintf("Errs with provided errors: " + deltaZ + "\n");
%
%           % Third case: User defines all parameters
%            z = x + y;
%            tempVar_usrDefAll = (x + (deltaX*(percentGX/100))) + (y + (deltaY*(percentGY/100))) - z;
%            deltaZ = z + tempVar_usrDefAll - z;
%            fprintf("Errs with provided percentage errors: " + deltaZ + "\n");

%{

The below function handles three situations: hard-coded values of deltaX/Y, user defining deltaX/Y, and user defining percentGX/GY. For the first case, use '0' for deltaX/Y. If the user defines
deltaX/Y then use a '1' for percentGX/GY. For the last situation, use needs to define all six parameters.

%}

end