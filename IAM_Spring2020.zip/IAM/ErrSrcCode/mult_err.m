% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% FUNCTION: mult_err
% INPUTS: x, y, delta_x, delta_y, percent_g_x, percent_g_y
% OUTPUTS: delta_z
% DESCRIPTION: This function calculates the mean forward multiplication
% error of z, where z = x*y

% function [delta_z,z] = mult_err(x,y,delta_x, delta_y, percent_g_x, percent_g_y)
function [delta_z,z] = mult_err(x, y, delta_x, delta_y)   % Our current params define our current focus (In ref to above fnc def)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
%calculate multiplication value
z = x * y;
% disp("Value with no errors: " + z)

%Hardcoded errors
% err_x = 0.25;
% err_y = 0.25;
% delta_z = err_x*y + err_y*x + err_x*err_y;
% disp("Error with hardcoded errors: " + delta_z)

%User provided errors
delta_z = delta_x * y + delta_y * x + delta_x * delta_y;
% disp("Error with user provided errors: " + delta_z)

%Errors with Hardcoded percentages
% err_x = 0.15*x;
% err_y = 0.15*y;
% delta_z = err_x*y + err_y*x + err_x*err_y;
% disp("Error with hardcoded percentage errors: " + delta_z)
% function gamma_z = mult_err(x,y,gamma_x, gamma_y, percent_g_x, percent_g_y)

end