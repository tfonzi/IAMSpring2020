%{ 
    Filename: Add.m
    Developer: Felipe P
    Purpose: To test how to plot the error algortihms and make sure they work as intended (growing over time) 
    Created On: 02/04/2019
    Last Modified:
    
    IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS. 
    ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%} 

%This is a test function to test that we can plot hardcoded error values
%into our IAM software graph. If this works we can then use this to display
%error graphs later on. This function will substitute dynamic_analysis.m
%temporarily

count = [0];
values = [0];
x = 3;
y = 4;
deltaX = 1.5;
deltaY = 1.2;
z = 0;
deltaZ = 0;

%This code functions by using count and value like dynamic_analysis. Then
%what we do is we cycle through three steps to test the error calculation
%algorithms and return to IAM_30 to plot

    for i = 1:10
        count(i) = i;
        if (i == 1) %Step 1: z = x + y
            [deltaZ, z] = addErr(x,y,deltaX,deltaY);
        else
            if ((mod(i,2)) == 0) %Step 2: z = z * x
                [deltaZ,z] = mult_err(z,x,deltaZ,deltaX);
            else %Step 3: z = z + y
                [deltaZ,z] = addErr(z,y,deltaZ,deltaY);
            end
        end 
       
        %store the fractional error into values to display
        values(i) = (deltaZ/z);
                       
    end
    
    %plot the values, and set width to 2
    p = plot(count,values);
    xlabel('Step count');
    ylabel('Fractional Error (DeltaZ/Z)');
    legend('Fractional Error');
    set(p,'LineWidth',2);