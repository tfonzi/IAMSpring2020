

function hash = hashtable(varargin)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%HASHTABLE Constructor for HashTable class
%   hash = hashtable - Default constructor, empty hash table
%   hash = hashtable(keys,data) - keys and data are N-by-1 lists

% Copyright (c) 2004 Matthew Krauski (mkrauski@uci.edu), CNLM, UC Irvine

if nargin == 1 && isa(keys,'HashTable')
    hash = varargin{1};
elseif nargin == 0
    h.keys = {};
    h.data = {};
elseif nargin == 2
    h.keys = varargin{1};
    h.data = varargin{2};
else
    error('HashTable:hashtable', 'Invalid arguments.');
end
hash = class(h,'HashTable');