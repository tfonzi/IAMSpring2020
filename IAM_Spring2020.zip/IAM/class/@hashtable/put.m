

function hash = put(hash,key,data)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%PUT Put data in the hash table
%   hash = put(hash,key,data)

% Copyright (c) 2004 Matthew Krauski (mkrauski@uci.edu), CNLM, UC Irvine

%index = find(strcmp(hash.keys,key));
index = find(cell2mat(hash.keys) == key);
if isempty(index)
    if isempty(hash.keys)
        hash.keys{1} = key;
        hash.data{1} = data;
    else
        hash.keys{end+1} = key;
        hash.data{end+1} = data;
    end
else
    hash.data{index} = data;
end
