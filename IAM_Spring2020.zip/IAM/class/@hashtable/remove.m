

function hash = remove(hash,key)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%REMOVE Remove element from the hash
%   hash = remove(hash,key)

% Copyright (c) 2004 Matthew Krauski (mkrauski@uci.edu), CNLM, UC Irvine

%index = find(strcmp(hash.keys,key));
index = find(cell2mat(hash.keys) == key);
if ~isempty(index)
    hash.keys = {hash.keys{1:index-1} hash.keys{index+1:end}};
    hash.data = {hash.data{1:index-1} hash.data{index+1:end}};
end
