

function data = vectorGet(hash,vector)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

if(isempty(hash))
    data = 0;
else
    VectorLength = length(vector);
    for i = 1:VectorLength
        hash = get(hash, vector(i));
        if(isempty(hash))
            data = 0;
            return;
        end
    end
    if(isnan(hash))
        data = 0;
    else
        data = hash;
    end
end

%if(isempty(hash))
%    data = 0;
%else
%    data = vectorGetHelper(hash,vector,1);
%end
%function data = vectorGetHelper(hash,vector,count)
%[M N] = size(vector);
%if(count >= N)
%    data = get(hash, vector(count));
%else
%    subhash = get(hash, vector(count));
%    if(isempty(get(subhash, vector(count+1))))
%        data = 0;
%    else
%        data = vectorGetHelper(subhash,vector,count+1);
%    end
%end