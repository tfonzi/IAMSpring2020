#include "mex.h"
# include <stdlib.h>
# include <string.h>


void inttostr(int num, char *buf)
{
  // IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
  // ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
  // OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
  // ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
  // SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
    
  int div = 1;
  int i;
  while(1)
  {
    if((num / div) == 0)
        break;
    div = div * 10;        
  }
  div = div /10;
  
   i = 0;
  while(div > 0)
  {
    buf[i++] = num / div + '0';
    num = num % div;
    div = div / 10;
  }
  buf[i] = '\0';
}

void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
    
  // IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
  // ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
  // OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
  // ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
  // SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*  
    
  double *x,*y, *z;
  char buf[30];
  char buf2[50] = "_ptr_";
   mxArray *rhs[1], *lhs[1];
  
  if(nrhs!=1) {
    mexErrMsgTxt("One  input required.");
  } else if(nlhs>1) {
    mexErrMsgTxt("Too many  output arguments");
  }
    //rhs[0] = mxCreateDoubleScalar(prhs[0]);
  
    printf(" Memory location %d %f\n", prhs[0], prhs[0]);
    //mexCallMATLAB(1, lhs, 1, rhs, "int2str");
    //mxArray *plhs
     inttostr((int)prhs[0], buf); 
     strcat(buf2, buf);
     printf(" String %s\n", buf2);
    plhs[0] = mxCreateString(buf2);
  /*x = mxGetPr(prhs[0]);
  y = mxGetPr(prhs[1]);
  z = mxGetPr(plhs[0]);
  
 
  xtimesy(x,y,z);*/
}
