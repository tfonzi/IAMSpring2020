#include "mex.h"
# include <stdlib.h>
# include <string.h>


long strtoint(char buf[], int len)
{
    
  // IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
  // ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
  // OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
  // ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
  // SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
          
  long sum = 0;
  int i;
  for(i=0;i<len;i++)
  {
    sum = sum *10 + buf[i];
  }
  return sum;
}

void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
    
  // IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
  // ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
  // OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
  // ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
  // SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*  
    
  double *x,*y, *z;
  char* buf;
  int len;
  int ret;
  long mem;
  int i;
  mxArray *retAdd;
  
  char buf2[50] = "_ptr_";
   mxArray *rhs[1], *lhs[1];
  printf(" In get object \n" );
  if(nrhs!=1) {
    mexErrMsgTxt("One  input required.");
  } else if(nlhs>1) {
    mexErrMsgTxt("Too many  output arguments");
  }
    //rhs[0] = mxCreateDoubleScalar(prhs[0]);
    len = (mxGetM(prhs[0]) * mxGetN(prhs[0]) * sizeof(mxChar)) + 1 ;
    buf = (char *)(malloc(len*sizeof(char)));
    ret = mxGetString(prhs[0], buf, 30);
    
    buf[strlen(buf)] = '\0';
    for(i=0;i<strlen(buf);i++)
    {
        buf[i] = buf[i] - '0';
    }
    //printf(" Memory location %s %d\n",buf, strlen(buf));
    //mexCallMATLAB(1, lhs, 1, rhs, "int2str");
    //mxArray *plhs
     mem = strtoint( buf, strlen(buf)); 
     printf(" Memory location %u \n",mem); 
     
     retAdd = (mxArray *)mem;
     printf("Is class  %d", mxIsClass(retAdd,"ptr"));
        plhs[0] = retAdd;  
}
