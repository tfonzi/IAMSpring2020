
function p = ptr
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ptr_g;
global ptr_g_v;
ptr_g_v = 15;
if nargin == 0
   
   if(iscell(ptr_g))
       %display('ptr_g cell');
   else
       ptr_g = cell(1,16);
       
       for i=2:15
           ptr_g{1,i} = i+1;
       end
       ptr_g{1,1} = 2;
       ptr_g{1,16} = 0;
   end
   
   p.n = ptr_g{1,1};
   ptr_g{1,1} = ptr_g{1,1} + 1 ; 
   
   ind = ptr_g{1,1};
   if(ptr_g{1,ind} == 0)
       tempPtr_g = cell(1, 2 * size(ptr_g,2));      
       for i = 2:(size(tempPtr_g,2) -1)
           tempPtr_g{1,i} = i+1;
       end
       tempPtr_g{1,size(tempPtr_g,2)} = 0;
       for i= 1:(size(ptr_g,2) -1)
           tempPtr_g{1,i} = ptr_g{1,i};
       end
       ptr_g = tempPtr_g;
   end
   %ptr_g
   p = class(p,'ptr');
else
    display('invalid arguments while creating pointer');
end