% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

clc; clear all;
a = Grayscale(imread('Venus.jpg'), 0);

[ M N ] = size(a);

h = hashimage();
g = matimage([1 1], [M N]);

h.populate(a, [1 1]);
g.populate(a, [1 1]);

h.matrix([0 0], [ 4 4])
g.matrix([0 0], [ 4 4])

if(0)
    for i = 1: M
        for j = 1:N
            %h.put([i j], i);
            %if(h.get([i j]) ~= i )
            %   display('ERROR!');
            %else
            %    %display('Success');
            %end
        end
    end

    h.matrix([1 1], [M N] )
    figure;
    colormap(gray);
    imagesc(h.matrix([1 1], [M N] )  )
    
else
    tic;
    for i = 1: M
        for j = 1:N
            h.put([i j], i);
        end
    end
    a = toc

    tic;
    for i = 1: M
        for j = 1:N
            g.put([i j], i);
        end
    end
    b = toc
    fprintf('PUT Speed up equals %d %%\n', round(100*(a/b)));

    for i = 1: M
        for j = 1:N
            h.get([i j]);
        end
    end
    a = toc

    tic;
    for i = 1: M
        for j = 1:N
            g.get([i j]);
        end
    end
    b = toc
    fprintf('GET Speed up equals %d %%\n', round(100*(a/b)));
end