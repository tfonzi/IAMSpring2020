

function [ X ] = index( input, magnitude )
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

    dim = numel(magnitude);

      vector = ones(1:dim);
      scaler = 1;
      for i = 2:dim
          scaler = scaler*magnitude(i-1);
          vector(i) = scaler;
      end
      X = sum(vector .* input);
      