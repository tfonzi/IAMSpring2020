

function matrix = hashmatrix(hash, nodetext, varargin)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global Analysis;
node = st.search(nodetext);
infimum = node.infimum;
supremum = node.supremum;

if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis') && size(varargin, 2) > 0 )
    if(varargin{1} == 1)
        Analysis.add(sprintf('display( %s )', nodetext), 'DisplayOps', prod(supremum - infimum + 1));
    else
        Analysis.add(sprintf('writeimage( %s, %s )', nodetext, varargin{2} ), 'DiskWrites', prod(supremum - infimum + 1));
    end
end

if(node.ptr_range.noElements == 1)
    matrix(supremum(1)- infimum(1) +1) = 0;
    for i = infimum(1):supremum(1)
        matrix(i-infimum(1)+1) = hash.get(i);
    end
elseif(node.ptr_range.noElements == 2)
    matrix(supremum(1)- infimum(1) +1, supremum(2)- infimum(2) +1) = 0;
    for i = infimum(1):supremum(1)
        for j = infimum(2):supremum(2)
            matrix(i-infimum(1)+1,j-infimum(2)+1) = hash.get([i,j]);
        end
    end
elseif(node.ptr_range.noElements == 3)
    matrix(supremum(1)- infimum(1) +1, supremum(2)- infimum(2) +1, supremum(3)- infimum(3) +1) = 0;
    for i = infimum(1):supremum(1)
        for j = infimum(2):supremum(2)
            for k = infimum(3):supremum(3)
                matrix(i-infimum(1)+1,j-infimum(2)+1,k-infimum(3)+1) = hash.get([i,j,k]);
            end
        end
    end
elseif(node.ptr_range.noElements == 4)
    matrix(supremum(1)- infimum(1) +1, supremum(2)- infimum(2) +1, supremum(3)- infimum(3) +1, supremum(4)- infimum(4) +1) = 0;
    for i = infimum(1):supremum(1)
        for j = infimum(2):supremum(2)
            for k = infimum(3):supremum(3)
                for l = infimum(4):supremum(4)
                    matrix(i-infimum(1)+1,j-infimum(2)+1,k-infimum(3)+1, l-infimum(4)+1) = hash.get([i,j,k,l]);
                end
            end
        end
    end  
end
    
    
