% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

hash = hashtable;
%hash = put(hash,'a',1);
%hash = put(hash,'random numbers',rand(5));
%hash = put(hash,'b','abcdefg...');
%hash = put(hash,'c',{'foo' 'goo' 'moo'});

%hash = put(hash,1,1);
%hash = put(hash,2,5);
%hash = put(hash,3,8);
%hash = put(hash,4,2);
%hash = put(hash,4,6);
%hash
%data = get(hash,1)
%data = get(hash,2)
%data = get(hash,3)
%data = get(hash,4)

%s.title = 'Random Numbers and Mean';
%s.data = rand(100);
%s.m = mean(s.data);
%hash = put(hash,'my data struct',subhash);
%hash = put(hash,'my data struct',hash);


%vector = [sprintf('%d',vector(1)),sprintf('%d',vector(2)),sprintf('%d',vector(3))];
vector1 = [-19,6,8];
vector2 = [8,3,7];
vector3 = [8,3,8];
hash = vectorPut(hash,vector1,12);
hash = vectorPut(hash,vector2,10);
hash = vectorPut(hash,vector3,6);

hash
display('Going to -19');
subhash1 = get(hash,-19)
display('Going to 6');
subhash2 = get(subhash1,6)
display('Going to 8');
data = get(subhash2,8)
pause;
hash
display('Going to 8');
subhash1 = get(hash,8)
display('Going to 3');
subhash2 = get(subhash1,3)
display('Going to 7');
data = get(subhash2,7)
pause;
hash
display('Going to 8');
subhash1 = get(hash,8)
display('Going to 3');
subhash2 = get(subhash1,3)
display('Going to 8');
data = get(subhash2,8)
pause;
data = vectorGet(hash,vector1)
data = vectorGet(hash,vector2)
data = vectorGet(hash,vector3)

%hash

%iskey(hash,'random numbers')
%get(hash,'random numbers')
%hash = remove(hash,'random numbers');
%iskey(hash,'random numbers')

%k = keys(hash);
%v = values(hash);
%newhash = hashtable(k,v)

%isempty(hash)
%hash = clear(hash);
%isempty(hash)
