

function hash = normalizeHashImage(hash, XMin, XMax, XInc,  YMin, YMax, YInc, Name)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    

    minimum = Inf;
    maximum = 0;
    x = XMin;
    while(x <= XMax)
        y = YMin;
        while(y <= YMax)
            value = hash.get([x,y]);
            maximum = max(maximum,value);
            minimum = min(minimum,value);
            y = y + YInc;
        end
        x = x + XInc;
        clc;
        display(sprintf('Normalizing the %s HashImage...(1/3)', Name));
        display(sprintf('   %d%% Completed', round(100*(x-XMin)/(XMax-XMin))));
    end
    
    sum = 0;
    x = XMin;
    while(x <= XMax)
        y = YMin;
        while(y <= YMax)
            value = (hash.get([x,y])-minimum)/(maximum-minimum);
            hash.put([x,y], value);
            sum = sum+value;
            y = y + YInc;
        end
        x = x + XInc;
        clc;
        display(sprintf('Normalizing the %s HashImage...(2/3)', Name));
        display(sprintf('   %d%% Completed', round(100*(x-XMin)/(XMax-XMin))));
    end
    
    x = XMin;
    while(x <= XMax)
        y = YMin;
        while(y <= YMax)
            hash.put([x,y], hash.get([x,y])/sum);
            y = y + YInc;
        end
        x = x + XInc;
        clc;
        display(sprintf('Normalizing the %s HashImage...(3/3)', Name));
        display(sprintf('   %d%% Completed', round(100*(x-XMin)/(XMax-XMin))));
    end