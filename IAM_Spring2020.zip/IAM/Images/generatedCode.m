% Program:  simple_image_convolution
% Date Generated:  22-Mar-2011
% Developed by: Eric Hayden

% Start of Symbol Table Generation
global st;
st = symbol_table();
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(1, 64));
rq = ntqu_push(rq, range_new_node(1, 64));
symbol = st_new_PSnode(0, 'X', 'Rectangular', 'domain', 0, rq, 0, 'NormalScan', 'Moore');
st.add(symbol);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(1, 64));
rq = ntqu_push(rq, range_new_node(1, 64));
symbol = st_new_PSnode(0, 'a', 'int', 'image', 0, rq, 0, 'NormalScan', 'Moore');
st.add(symbol);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(1, 64));
rq = ntqu_push(rq, range_new_node(1, 64));
symbol = st_new_PSnode(0, 'c', 'int', 'image', 0, rq, 0, 'NormalScan', 'Moore');
st.add(symbol);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(0, 2));
rq = ntqu_push(rq, range_new_node(0, 2));
cq = ntqu_new;
cq = ntqu_push(cq, coord_new_node(1));
cq = ntqu_push(cq, coord_new_node(1));
symbol = st_new_PSnode(0, 's', 'int', 'tpl', 0, rq, cq, 'NormalScan', 'Moore');
st.add(symbol);
% End of Symbol Table Generation

% Start of MATLAB Image Algebra Code
global tempCount;
global stack;
tempCount = 0;
stack = ntst_new;
global Analysis;
a = hashimage();
c = hashimage();
matrix = [  1  1  1;  1  1  1;  1  1  1 ];
s = update('s', matrix);

a = update('a', 'boolONES&P.jpg');

%-----IAM GUI Pause/Stop Checkpoint------------
drawnow;
if(stopped)
    end_program(hObject, eventdata, handles);
    return;
end
if(paused)
    uiwait;
end
%-----End of IAM GUI Pause/Stop Checkpoint-----

display_Count = display_Count + 1;
display_List{display_Count, 1} = 'IMG: Image a';
display_List{display_Count, 2} = hashmatrix( a, 'a', 1);
if(strcmp( get(handles.mode, 'String') , 'Analysis' ) )
     set(handles.stack_vector_ops, 'String', display_List);
     set(handles.stack_vector_ops, 'Value', display_Count);
end

%-----IAM GUI Pause/Stop Checkpoint------------
drawnow;
if(stopped)
    end_program(hObject, eventdata, handles);
    return;
end
if(paused)
    uiwait;
end
%-----End of IAM GUI Pause/Stop Checkpoint-----

coord = [ 1 1 ];
tmp0 = IAImgMultMin(a, 'a', s, 's', coord, 'tmp0');
if( strcmp(get(handles.complexity, 'String'), 'Work/Grf') && isequal(get(handles.complexity, 'BackgroundColor'), [1,1,0] ) )
     plot_dynamic(handles);
     set(handles.stack_vector_ops, 'String', Analysis.equations());
     set(handles.stack_vector_ops, 'Value', Analysis.size());
elseif( strcmp(get(handles.error, 'String'), 'Work/Tbl') && isequal(get(handles.error, 'BackgroundColor'), [1,1,0] ) )
     table_dynamic(handles);
end

%-----IAM GUI Pause/Stop Checkpoint------------
drawnow;
if(stopped)
    end_program(hObject, eventdata, handles);
    return;
end
if(paused)
    uiwait;
end
%-----End of IAM GUI Pause/Stop Checkpoint-----

coord = [ 1 1 ];
tmp1 = IAImgMultMax(tmp0, 'tmp0', s, 's', coord, 'tmp1');
if( strcmp(get(handles.complexity, 'String'), 'Work/Grf') && isequal(get(handles.complexity, 'BackgroundColor'), [1,1,0] ) )
     plot_dynamic(handles);
     set(handles.stack_vector_ops, 'String', Analysis.equations());
     set(handles.stack_vector_ops, 'Value', Analysis.size());
elseif( strcmp(get(handles.error, 'String'), 'Work/Tbl') && isequal(get(handles.error, 'BackgroundColor'), [1,1,0] ) )
     table_dynamic(handles);
end

%-----IAM GUI Pause/Stop Checkpoint------------
drawnow;
if(stopped)
    end_program(hObject, eventdata, handles);
    return;
end
if(paused)
    uiwait;
end
%-----End of IAM GUI Pause/Stop Checkpoint-----

coord = [ 1 1 ];
tmp2 = IAImgMultMax(tmp1, 'tmp1', s, 's', coord, 'tmp2');
if( strcmp(get(handles.complexity, 'String'), 'Work/Grf') && isequal(get(handles.complexity, 'BackgroundColor'), [1,1,0] ) )
     plot_dynamic(handles);
     set(handles.stack_vector_ops, 'String', Analysis.equations());
     set(handles.stack_vector_ops, 'Value', Analysis.size());
elseif( strcmp(get(handles.error, 'String'), 'Work/Tbl') && isequal(get(handles.error, 'BackgroundColor'), [1,1,0] ) )
     table_dynamic(handles);
end

%-----IAM GUI Pause/Stop Checkpoint------------
drawnow;
if(stopped)
    end_program(hObject, eventdata, handles);
    return;
end
if(paused)
    uiwait;
end
%-----End of IAM GUI Pause/Stop Checkpoint-----

coord = [ 1 1 ];
tmp3 = IAImgMultMin(tmp2, 'tmp2', s, 's', coord, 'tmp3');
if( strcmp(get(handles.complexity, 'String'), 'Work/Grf') && isequal(get(handles.complexity, 'BackgroundColor'), [1,1,0] ) )
     plot_dynamic(handles);
     set(handles.stack_vector_ops, 'String', Analysis.equations());
     set(handles.stack_vector_ops, 'Value', Analysis.size());
elseif( strcmp(get(handles.error, 'String'), 'Work/Tbl') && isequal(get(handles.error, 'BackgroundColor'), [1,1,0] ) )
     table_dynamic(handles);
end

%-----IAM GUI Pause/Stop Checkpoint------------
drawnow;
if(stopped)
    end_program(hObject, eventdata, handles);
    return;
end
if(paused)
    uiwait;
end
%-----End of IAM GUI Pause/Stop Checkpoint-----

c = assign(tmp3, 'tmp3', 'c'); 

if( strcmp(get(handles.complexity, 'String'), 'Work/Grf') && isequal(get(handles.complexity, 'BackgroundColor'), [1,1,0] ) )
     plot_dynamic(handles);
     set(handles.stack_vector_ops, 'String', Analysis.equations());
     set(handles.stack_vector_ops, 'Value', Analysis.size());
elseif( strcmp(get(handles.error, 'String'), 'Work/Tbl') && isequal(get(handles.error, 'BackgroundColor'), [1,1,0] ) )
     table_dynamic(handles);
end
display_Count = display_Count + 1;
display_List{display_Count, 1} = 'IMG: a (v) s';
display_List{display_Count, 2} = hashmatrix( c, 'c', 1);
if(strcmp( get(handles.mode, 'String') , 'Analysis' ) )
     set(handles.stack_vector_ops, 'String', display_List);
     set(handles.stack_vector_ops, 'Value', display_Count);
end

%-----IAM GUI Pause/Stop Checkpoint------------
drawnow;
if(stopped)
    end_program(hObject, eventdata, handles);
    return;
end
if(paused)
    uiwait;
end
%-----End of IAM GUI Pause/Stop Checkpoint-----

% End of MATLAB Image Algebra Code
