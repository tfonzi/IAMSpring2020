% Program:  Mirrors
% Date Generated:  30-Apr-2020
% Developed by: Eric Hayden

% Start of Symbol Table Generation
global st;
st = symbol_table();
symbol = st_new_PSnode(0, 'M', 'int', 'nil', 71, 0, 0, 0, 0);
st.add(symbol);
symbol = st_new_PSnode(0, 'N', 'int', 'nil', 95, 0, 0, 0, 0);
st.add(symbol);
symbol = st_new_PSnode(0, 'k', 'int', 'nil', 42, 0, 0, 0, 0);
st.add(symbol);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(0, 'M'));
rq = ntqu_push(rq, range_new_node(0, 'N'));
symbol = st_new_PSnode(0, 'X', 'Rectangular', 'domain', 0, rq, 0, 'NormalScan', 'Moore');
st.add(symbol);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(0, 'M'));
rq = ntqu_push(rq, range_new_node(0, 'k'));
symbol = st_new_PSnode(0, 'Y', 'Rectangular', 'domain', 0, rq, 0, 'NormalScan', 'Moore');
st.add(symbol);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(0, 'M'));
rq = ntqu_push(rq, range_new_node('k', 'N'));
symbol = st_new_PSnode(0, 'Z', 'Rectangular', 'domain', 0, rq, 0, 'NormalScan', 'Moore');
st.add(symbol);
symbol = st_new_PSnode(0, 'f', 'Function', 'map', 0, 0, 0, 0, 0);
st.add(symbol);
symbol = st_new_PSnode(0, 'g', 'Function', 'map', 0, 0, 0, 0, 0);
st.add(symbol);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(0, 'M'));
rq = ntqu_push(rq, range_new_node(0, 'N'));
symbol = st_new_PSnode(0, 'a', 'int', 'image', 0, rq, 0, 'NormalScan', 'Moore');
st.add(symbol);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(0, 'M'));
rq = ntqu_push(rq, range_new_node(0, 'N'));
symbol = st_new_PSnode(0, 'b', 'int', 'image', 0, rq, 0, 'NormalScan', 'Moore');
st.add(symbol);
% End of Symbol Table Generation

% Start of MATLAB Image Algebra Code
global tempCount;
global stack;
tempCount = 0;
stack = ntst_new;
global Analysis;
M = 71; 
N = 95; 
k = 42; 

% Generating Map Tree for variable 'f'
stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , 'Y')));
stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , 'X')));
AST = buildTree(nt_new_node('->', 0), 2);
stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , 'x')));
stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , 'y')));
AST = buildTree(nt_new_node('f', 0), 2);
stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , 'x')));
stack = ntst_push(stack, new_stack_node(nt_new_node('numlit' , 2)));
stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , 'k')));
AST = buildTree(nt_new_node('*', 0), 2);
stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , 'y')));
AST = buildTree(nt_new_node('-', 0), 2);
AST = buildTree(nt_new_node('vector', 0), 2);
AST = buildTree(nt_new_node('Expression', 0), 1);
AST = buildTree(nt_new_node('Domain', 0), 1);
AST = buildTree(nt_new_node('specifications', 0), 3);
f = AST;
% End of Map Tree generation for variable 'f'

% Generating Map Tree for variable 'g'
stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , 'Z')));
stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , 'X')));
AST = buildTree(nt_new_node('->', 0), 2);
stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , 'x')));
stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , 'y')));
AST = buildTree(nt_new_node('f', 0), 2);
stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , 'x')));
stack = ntst_push(stack, new_stack_node(nt_new_node('numlit' , 2)));
stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , 'k')));
AST = buildTree(nt_new_node('*', 0), 2);
stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , 'y')));
AST = buildTree(nt_new_node('-', 0), 2);
AST = buildTree(nt_new_node('vector', 0), 2);
AST = buildTree(nt_new_node('Expression', 0), 1);
AST = buildTree(nt_new_node('Domain', 0), 1);
AST = buildTree(nt_new_node('specifications', 0), 3);
g = AST;
% End of Map Tree generation for variable 'g'
infimum = [ 0, 0 ];
supremum = [ 71, 95 ];
a = matimage(infimum, supremum);
infimum = [ 0, 0 ];
supremum = [ 71, 95 ];
b = matimage(infimum, supremum);

a = update('a', 'Venus.jpg');

%-----IAM GUI Pause/Stop Checkpoint------------
drawnow;
if(stopped)
    end_program(hObject, eventdata, handles);
    return;
end
if(paused)
    uiwait;
end
%-----End of IAM GUI Pause/Stop Checkpoint-----

display_Count = display_Count + 1;
display_List{display_Count, 1} = 'IMG: Image a';
display_List{display_Count, 2} = hashmatrix( a, 'a', 1);
if(strcmp( get(handles.mode, 'String') , 'Analysis' ) )
     set(handles.stack_vector_ops, 'String', display_List);
     set(handles.stack_vector_ops, 'Value', display_Count);
end

%-----IAM GUI Pause/Stop Checkpoint------------
drawnow;
if(stopped)
    end_program(hObject, eventdata, handles);
    return;
end
if(paused)
    uiwait;
end
%-----End of IAM GUI Pause/Stop Checkpoint-----

tmp0 = IAImgMap(a, 'a', f, 'f', 'tmp0');

%-----IAM GUI Pause/Stop Checkpoint------------
drawnow;
if(stopped)
    end_program(hObject, eventdata, handles);
    return;
end
if(paused)
    uiwait;
end
%-----End of IAM GUI Pause/Stop Checkpoint-----

tmp1 = IAExtend(tmp0, 'tmp0', a, 'a', 'tmp1');

%-----IAM GUI Pause/Stop Checkpoint------------
drawnow;
if(stopped)
    end_program(hObject, eventdata, handles);
    return;
end
if(paused)
    uiwait;
end
%-----End of IAM GUI Pause/Stop Checkpoint-----

b = assign(tmp1, 'tmp1', 'b'); 

display_Count = display_Count + 1;
display_List{display_Count, 1} = 'IMG: Mirror 1';
display_List{display_Count, 2} = hashmatrix( b, 'b', 1);
if(strcmp( get(handles.mode, 'String') , 'Analysis' ) )
     set(handles.stack_vector_ops, 'String', display_List);
     set(handles.stack_vector_ops, 'Value', display_Count);
end

%-----IAM GUI Pause/Stop Checkpoint------------
drawnow;
if(stopped)
    end_program(hObject, eventdata, handles);
    return;
end
if(paused)
    uiwait;
end
%-----End of IAM GUI Pause/Stop Checkpoint-----

tmp0 = IAImgMap(a, 'a', g, 'g', 'tmp0');

%-----IAM GUI Pause/Stop Checkpoint------------
drawnow;
if(stopped)
    end_program(hObject, eventdata, handles);
    return;
end
if(paused)
    uiwait;
end
%-----End of IAM GUI Pause/Stop Checkpoint-----

tmp1 = IAExtend(tmp0, 'tmp0', a, 'a', 'tmp1');

%-----IAM GUI Pause/Stop Checkpoint------------
drawnow;
if(stopped)
    end_program(hObject, eventdata, handles);
    return;
end
if(paused)
    uiwait;
end
%-----End of IAM GUI Pause/Stop Checkpoint-----

b = assign(tmp1, 'tmp1', 'b'); 

display_Count = display_Count + 1;
display_List{display_Count, 1} = 'IMG: Mirror 2';
display_List{display_Count, 2} = hashmatrix( b, 'b', 1);
if(strcmp( get(handles.mode, 'String') , 'Analysis' ) )
     set(handles.stack_vector_ops, 'String', display_List);
     set(handles.stack_vector_ops, 'Value', display_Count);
end

%-----IAM GUI Pause/Stop Checkpoint------------
drawnow;
if(stopped)
    end_program(hObject, eventdata, handles);
    return;
end
if(paused)
    uiwait;
end
%-----End of IAM GUI Pause/Stop Checkpoint-----

% End of MATLAB Image Algebra Code
