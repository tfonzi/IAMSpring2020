x = [1:1:13];
y = normpdf(x,13/2,2);

figure();
plot(x,y);


matrix = zeros(13,13);

for(i=1:13)
    
    for(j=1:13)
        
        matrix(i,j) = y(i) * y(j);
        
    end
end


        
