%{
    Filename: tplot_cosh.m
    Developer: Felipe P
    Purpose: To test plots of trig error functions
    Created On: 01/26/2018
    Last Modified: 03/16/2018

    IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%}

% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
x = linspace(-2,2);
deltaX = [0.001*x,0.002*x,0.005*x,0.01*x,0.02*x,0.05*x,0.1*x,0.2*x,0.5*x];
[deltaZ,z] = coshErr(x, deltaX(1:100));
p = plot(x,deltaZ,'-k');
set(p,'LineWidth', 2);  
hold on;
[deltaZ,z] = coshErr(x, deltaX(101:200));
p = plot(x,deltaZ,'-m');
set(p,'LineWidth', 2);  
[deltaZ,z] = coshErr(x, deltaX(201:300));
p = plot(x,deltaZ,'-c');
set(p,'LineWidth', 2);  
[deltaZ,z] = coshErr(x, deltaX(301:400));
p = plot(x,deltaZ,'-r');
set(p,'LineWidth', 2);  
[deltaZ,z] = coshErr(x, deltaX(401:500));
p = plot(x,deltaZ,'-g');
set(p,'LineWidth', 2);  
[deltaZ,z] = coshErr(x, deltaX(501:600));
p = plot(x,deltaZ,'-b');
set(p,'LineWidth', 2);  
[deltaZ,z] = coshErr(x, deltaX(601:700));
p = plot(x,deltaZ,'--k');
set(p,'LineWidth', 2);  
[deltaZ,z] = coshErr(x, deltaX(701:800));
p = plot(x,deltaZ,'--r');
set(p,'LineWidth', 2);  
[deltaZ,z] = coshErr(x, deltaX(801:900));
p = plot(x,deltaZ,'--b');
set(p,'LineWidth', 2);  
hold off;
lgd = legend('0.001x', '0.002x', '0.005x','0.01x', '0.02x', '0.05x', '0.1x', '0.2x', '0.5x', 'Location', 'best');
title(lgd,'error \deltax as a fraction of x');
ylabel('error in cosh(x)');
xlabel('x'); 
