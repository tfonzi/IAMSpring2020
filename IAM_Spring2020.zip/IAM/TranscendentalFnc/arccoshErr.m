%{
    Filename: arccoshErr.m
    Developer: Felipe P
    Purpose: To compute the error in arccosh operation
    Created On: 01/26/2018
    Last Modified: 03/16/2018

    IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%}

function [deltaZ, z] = arccoshErr(x, deltaX) 
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

    %calculate z for first 5 terms
    z = (-log(x.^-1))+(log(2))-((1/4)*x.^-2)-((3/32)*x.^-4)-((5/96)*x.^-6); 
    
    %calculate error
    deltaZ = log((x + deltaX)./x) - ((1/4)*((1./(x.^2+2*deltaX.*x+deltaX.^2))-(1./(x.^2))));
    deltaZ = deltaZ - (3/32)*((1./(x.^4+4*deltaX.*x.^3+6*deltaX.^2.*x.^2+4*deltaX.^3.*x+deltaX.^4))-(1./x.^4));
    deltaZ = deltaZ - (5/96)*((1./(x.^6+6*deltaX.*x.^5+15*deltaX.^2.*x.^4+20*deltaX.^3.*x.^3+15*deltaX.^4.*x.^2+6*deltaX.^5.*x+deltaX.^6))-(1./x.^6));
    
%     deltaZ = log((x+deltaX)./x) - (1/4)*(((x+deltaX).^-2)-(x.^-2));
%     deltaZ = deltaZ - (3/32)*(((x+deltaX).^-4)-(x.^-4)) - (5/96)*(((x+deltaX).^-6)-(x.^-6));

    
end