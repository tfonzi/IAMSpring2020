%{
    Filename: tanhTaylor_helper.m
    Developer: KR
    Purpose: Compute the deltaZ vector for a given deltaX vector
    Created On: 04/07/2019
    Last Modified: 04/08/2019

    IMPORTANT DISCLAIMER: THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
%}

%{
    FUNCTION: tanhhTaylor_helper()

    USAGE:

       INPUTS:
            vect: The current deltaX vector we are focused on. 
            x: Represents a partition with a specified stepSize 

       OUTPUT:
            deltaZ: The error vector of size 100 in the fnc arctan(x).
%}

function deltaZ = tanhTaylor_helper(x, vect)
%{
IMPORTANT DISCLAIMER: THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS. ALL ERRORS ARE THE RESPONSIBILITY OF THE
USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES
%}
deltaX = vect;

% Since the err eq for 9 terms is large, I'll break it down into pieces 
z1 = ( (deltaX) - (1/3)*(deltaX.^3) + (2/15)*(deltaX.^5) - (17/315)*(deltaX.^7) + (62/2835)*(deltaX.^9) );
z2 = ( (-deltaX.^2) + (2/3)*(deltaX.^4) - (17/45)*(deltaX.^6) + (62/315)*(deltaX.^8) ) .* x;
z3 = ( (-deltaX) + (4/3)*(deltaX.^3) - (17/15)*(deltaX.^5) + (248/315)*(deltaX.^7) ) .* (x.^2);
z4 = ( (4/3)*(deltaX.^2) - (17/9)*(deltaX.^4) + (248/135)*(deltaX.^6) ) .* (x.^3);
z5 = ( (2/3)*(deltaX) - (17/9)*(deltaX.^3) + (124/45)*(deltaX.^5) ) .* (x.^4);
z6 = ( (-17/5)*(deltaX.^2) + (124/45)*(deltaX.^4) ) .* (x.^5);
z7 = ( (-17/45)*(deltaX) + (248/135)*(deltaX.^3) ) .* (x.^6);
z8 = ( (248/315)*(deltaX.^2) ) .* (x.^7);
z9 = ( (62/315)*(deltaX) ) .* (x.^8);

deltaZ = (z1 + z2 + z3 + z4 + z5 + z6 + z7 + z8 + z9); 

end