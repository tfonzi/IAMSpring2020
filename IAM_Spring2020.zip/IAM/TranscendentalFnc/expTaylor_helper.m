%{
    Filename: expTaylor_helper.m
    Developer: KR
    Purpose: Compute the deltaZ vector for a given deltaX vector
    Created On: 04/01/2019
    Last Modified: 04/08/2019

    IMPORTANT DISCLAIMER: THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
%}

%{
    FUNCTION: expTaylor_helper()

    USAGE:

       INPUTS:
            vect: The current deltaX vector we are focused on. It should be a size of 100.
            x: 100 samples (@ a time)

       OUTPUT:
            deltaZ: The error vector of size 100 in the fnc exp(x).
%}

function deltaZ = expTaylor_helper(x, vect)
%{
IMPORTANT DISCLAIMER: THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS. ALL ERRORS ARE THE RESPONSIBILITY OF THE
USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES
%}
deltaX = vect;
% I was able to fit it into one line bc it was not very long. 
deltaZ = ( (deltaX) + (1/2)*(deltaX.^2) + (1/6)*(deltaX.^3) + (1/24)*(deltaX.^4) ) + ( ( (deltaX) + (1/2)*(deltaX.^2) + (1/6)*(deltaX.^3) ).*x ) + ( ( (1/2)*(deltaX) + (1/4)*(deltaX.^2) ).*(x.^2) ) + ( ( (1/6)*(deltaX) ).*(x.^3) );
end