%{
    Filename: sinErr.m
    Developer: Felipe P
    Purpose: To compute the error in sine operation
    Created On: 01/26/2018
    Last Modified: 03/16/2018

    IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%}

function [deltaZ, z] = sinErr(x, deltaX) 
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
    z = 0;

    %calculate z for first 5 terms
    for i = 1:5
        temp = ((-1)^(i-1))*((x.^((2*i)-1))/(factorial((2*i)-1)));
        z = z + temp;
    end

    %calculate error
    deltaZ = (deltaX - (1/6)*deltaX.^3 + (1/120)*deltaX.^5 - (1/5040)*deltaX.^7 + (1/factorial(9))*deltaX.^9);
    deltaZ = deltaZ + (-(1/2)*deltaX.^2 + (1/24)*deltaX.^4 - (1/720)*deltaX.^6 + (1/40320)*deltaX.^8).*x;
    deltaZ = deltaZ + (-(1/2)*deltaX + (1/12)*deltaX.^3 - (1/240)*deltaX.^5 + (1/10080)*deltaX.^7).*x.^2; 
    deltaZ = deltaZ + ((1/12)*deltaX.^2 - (1/144)*deltaX.^4 + (1/4320)*deltaX.^6).*x.^3;
    deltaZ = deltaZ + ((1/24)*deltaX - (1/144)*deltaX.^3 + (1/2880)*deltaX.^5).*x.^4;
    deltaZ = deltaZ + (-(1/240)*deltaX.^2 + (1/2880)*deltaX.^4).*x.^5 + (-(1/720)*deltaX + (1/4320)*deltaX.^3).*x.^6;
    deltaZ = deltaZ + ((1/10080)*deltaX.^2).*x.^7 + ((1/40320)*deltaX).*x.^8;
end