%{
    Filename: tplot_arccosh.m
    Developer: Felipe P
    Purpose: To test plots of trig error functions
    Created On: 01/26/2018
    Last Modified: 03/16/2018

    IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%}

% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
x = linspace(-pi/2,pi/2,10000);
deltaX = [0.001*x,0.002*x,0.005*x,0.01*x,0.02*x,0.05*x,0.1*x,0.2*x,0.5*x];
[deltaZ,z] = arccoshErr(x, deltaX(1:10000));
p = plot(x,deltaZ,'-k');
set(p,'LineWidth', 1);  
hold on;
[deltaZ,z] = arccoshErr(x, deltaX(10001:20000));
p = plot(x,deltaZ,'-m');
set(p,'LineWidth', 1);  
[deltaZ,z] = arccoshErr(x, deltaX(20001:30000));
p = plot(x,deltaZ,'-c');
set(p,'LineWidth', 1);  
[deltaZ,z] = arccoshErr(x, deltaX(30001:40000));
p = plot(x,deltaZ,'-r');
set(p,'LineWidth', 1);  
[deltaZ,z] = arccoshErr(x, deltaX(40001:50000));
p = plot(x,deltaZ,'-g');
set(p,'LineWidth', 1);  
[deltaZ,z] = arccoshErr(x, deltaX(50001:60000));
p = plot(x,deltaZ,'-b');
set(p,'LineWidth', 1);  
[deltaZ,z] = arccoshErr(x, deltaX(60001:70000));
p = plot(x,deltaZ,'--k');
set(p,'LineWidth', 2);  
[deltaZ,z] = arccoshErr(x, deltaX(70001:80000));
p = plot(x,deltaZ,'--r');
set(p,'LineWidth', 2);  
[deltaZ,z] = arccoshErr(x, deltaX(80001:90000));
p = plot(x,deltaZ,'--b');
set(p,'LineWidth', 2);  
hold off;
lgd = legend('0.001x', '0.002x', '0.005x','0.01x', '0.02x', '0.05x', '0.1x', '0.2x', '0.5x', 'Location', 'best');
title(lgd,'error \deltax as a fraction of x');
ylabel('Error In Arccosh(x)');
xlabel('x'); 
