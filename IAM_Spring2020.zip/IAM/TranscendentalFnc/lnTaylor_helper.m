%{
    Filename: lnTaylor_helper.m
    Developer: KR
    Purpose: Compute the deltaZ vector for a given deltaX vector
    Created On: 04/05/2019
    Last Modified: 04/08/2019

    IMPORTANT DISCLAIMER: THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
%}

%{
    FUNCTION: lnTaylor_helper()

    USAGE:

       INPUTS:
            vect: The current deltaX vector we are focused on. 
            x: 1,000,000 samples

       OUTPUT:
            deltaZ: The error vector of size 1,000,000 in the fnc ln(x).
%}

function deltaZ = lnTaylor_helper(x, vect)
%{
IMPORTANT DISCLAIMER: THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS. ALL ERRORS ARE THE RESPONSIBILITY OF THE
USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES
%}
deltaX = vect;

% Since the err eq for 5 terms is large, I'll break it down into pieces 
z1 = (5*deltaX) - 5*(deltaX.^2) + (10/3)*(deltaX.^3) - (5/4)*(deltaX.^4) + (1/5)*(deltaX.^5);
z2 = ( (-10*deltaX) + 10*(deltaX.^2) - 5*(deltaX.^3) + (deltaX.^4) ) .* (x);
z3 = ( (10*deltaX) - (15/2)*(deltaX.^2) + (2*deltaX.^3) ) .* (x.^2);
z4 = ( (-5*deltaX) + 2*(deltaX.^2) ) .* (x.^3);
z5 = (deltaX).*(x.^4);

deltaZ = z1 + z2 + z3 + z4 + z5; 

end