%{

IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS. ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

Function Name: classicalFD_analysis
Inputs: None
Output: Analysis object set for classicalFD error analysis
Description: This function is an object that is used to perform non classicalFD analysis. Note that this is an empty object.  All operations performed are executed with the desired functions.

%}

function listObject = classicalFD_analysis()

% Summary of this function goes here
% Detailed explanation goes here
  
  equations = {};  % used to store the equation of each IAM operation that is performed
  count = 0; % global count value
  check = 0; % makes sure data has been added before plotting
  errcount = 1; % keeps track of what set of data shoud be plotted
  values = [0]; % normalized matrix representation of error list produced from every operation
  nonnorm = [0]; % unnormalized matrix representation of error list
  
  
  listObject = struct('type', 'classicalFD',... % gives names to the functions that are available 
                      'values',@get_values,... % Analysis.values() will execute the get_values function
                      'add' , @add_data,...
                      'plot', @plot_data,...
                      'delete', @delete_data,...
                      'count', @get_count,...
                      'inc', @inc_count,...
                      'dec', @dec_count,...
                      'stats', @generate_stats,...
                      'equations', @get_equations,...
                      'size', @get_size,...
                      'set', @set_count,...
                      'error_count', @get_errcount,...
                      'max', @get_max);
                  
                  
   function matrix = get_values()
       matrix = values; % returns all the error matrix that stores errorLists for each operation
   end % *** END OF FNC ***

   function add_data(equation, errorlist)
       count = count + 1; % increment global counter
       values(count, 1:length(errorlist)) = errorlist./sum(errorlist); %adds normalized errorList to values
       nonnorm(count, 1:length(errorlist)) = errorlist;%adds non-normalized errorList to nonnorm
       equations{count} = sprintf('%d : %s', count, equation);%adds the equation representing the errorList to equations
       check = 1; %sets the flag that data has been added
   end % *** END OF FNC ***
    
   function plot_data(handles)        
         [counts,bins] = hist(values(errcount,1:size(values,2)),100); % get counts and bin locations for the data in the row of values specified by errcount
         h = barh(handles.display_canvas, bins,counts, 'hist'); %gets graphics handle for plot        
         set(get(h,'Parent'),'xdir','r')  %makes the plot horizontal        
         xlabel(sprintf('%d', errcount))  %sets the plot label       
   end % *** END OF FNC ***
   
   function delete_data()       
       values = [0]; %reset data
       nonnorm = [0];%reset data
   end  % *** END OF FNC ***

   function value = inc_count()     
       if(errcount > 0 && errcount < size(values,1) && check == 1) % check the errcount is within range of the number of rows of values and that data has been added
           errcount = errcount + 1; %increment errorcount
       end   % *** END OF IF *** 
       value = errcount;
   end  % *** END OF FNC ***

   function value = dec_count()
       if(errcount > 1 && errcount <= size(values,1) && check == 1) % check the errcount is within range of the number of rows of values and that data has been added
           errcount = errcount - 1; %decrement errorcount
       end  % *** END OF IF ***  
       value = errcount; 
   end  % *** END OF FNC ***
   
    function number = get_count()  
    % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
    % ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
    % OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    % ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
    % SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        number = ceil(0.5:0.5:length(equations) + 1 + completed) ; % 0:length(equations); Gets the # of operators?
    end % *** END OF FNC *** 

   function matrix = generate_stats() % generates all the stats (max, min, mean, median, var, std) used in the error table       
        for i = 1:size(nonnorm,1) %loops throught each row of nonnorm
            matrix(i,1) = min(nonnorm(i,1:size(nonnorm,2))); %find min
            matrix(i,2) = max(nonnorm(i,1:size(nonnorm,2))); %find max
            matrix(i,3) = mean(nonnorm(i,1:size(nonnorm,2))); %find avg
            matrix(i,4) = median(nonnorm(i,1:size(nonnorm,2))); %find median
            matrix(i,5) = var(nonnorm(i,1:size(nonnorm,2))); %find variance
            matrix(i,6) = std(nonnorm(i,1:size(nonnorm,2))); %find standard deviation
        end % *** END OF FOR ***
   end % *** END OF FNC ***

   function list = get_equations()       
       list = equations;      % returns the list of equations used for the operations list in the GUI
   end % *** END OF FNC ***

   function number = get_size()
       number = length(equations);       % return number of equations
   end % *** END OF FNC ***

 function set_count(value)
       if(value > 0 && value <= size(values,1) && check == 1) % Validate the value then return it 
           errcount = value;  % sets errcount to the value passed in so that the correct plot is displayed. 
       end                    % so that the user can click the desired operation in the operation list and the corresponding graph is shown   
 end % *** END OF FNC ***


function value = get_errcount() % The total number of data in the errCount table         
     value = errcount;
end % *** END OF FNC ***


function number = get_max()        
        number = max(max((values))); % Gets the max of the whole table 
    end % *** END OF FNC ***
end % *** END OF MAIN FNC ***