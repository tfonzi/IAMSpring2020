
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: disp_error
%% Inputs: The value is the token of error and varargin is an optional input to output the error description.
%% Output: None
%% Description:
%% This primary function to handle errors throwing exception with description of error.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function disp_error(value, varargin)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ts;
row = ts.row();
column = ts.column();
if(strcmp(value, 'Runtime'))
    throw(MException('Runtime:Error', varargin{1}));
else
    if(size(varargin, 1))
        throw(MException('Parser:Error', sprintf(' Token: "%s" [Line: %d, Token: %d], %s', value, row, column, varargin{1})));
    else
        throw(MException('Parser:Error', sprintf(' Token: "%s" [Line: %d, Token: %d]', value, row, column)));
    end
end
