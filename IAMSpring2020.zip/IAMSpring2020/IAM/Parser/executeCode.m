
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: executeCode
%% Inputs: fileName: Name of the .obj file to be generated
%%         AST : The abstract syntax tree constructed from the parser
%% Output: None
%% Description:
%% This function generates the MATLAB code from the abstract syntax tree generated from the Image Algebra code.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function executeCode(AST)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global completed;
global AST_level;
%global AST;


 %global output;
%global obj_file_handle;
%global output;
%global whileCounter;

    %whileCounter = 0;
    %fileName = strcat(fileName, '.obj');
    %obj_file_handle=fopen(fileName);
    %output = (' ' );
    %output = strcat( output, '%%%% Program:');
    %output = strcat( output, sprintf('  %s', prog_name));
    %output = strcat( output, '\n%%%% Date Generated:');
    %output = strcat( output, sprintf('  %s', date));
    %output = strcat( output, '\n%%%% Developed by: Eric Hayden\n');
    %addSymbolTable;
    %output = strcat( output, '\n%%%% Start of MATLAB Image Algebra Code\n');
    %output = strcat( output ,'global tempCount;\nglobal stack;\nstack = ntst_new;\ntempCount = 0;\n');
        if(strcmp(AST.type, 'program'))
            node = AST.firstChild;
            
            for i = 1:AST_level(1)
                node = node.sibling;
            end
            if(strcmp(node.type ,'All_Var_Dec'))
                printAllVarDec(node,AST.type);
            elseif(strcmp(node.type ,'Command_Sequence'))
                printCommandSequence(node, 2);                %output= strcat(output, '\n');
            end

        elseif(strcmp(AST.type, 'function'))
            if(strcmp(AST.firstChild.type ,'All_Params') == 0)
                %output = strcat(output, sprintf('function %s()',fileName));
                %output = strcat( output , '\n');
            end
            node = AST.firstChild;
            for i=1:AST.noChildren
                if(strcmp(node.type ,'All_Params'))
                    %output = strcat(output, sprintf('function %s(',fileName));
                    %printAllVarDec(node,AST.type);
                    %output = output(1 : length(output)-1);
                    %output = strcat( output , ')\n');
                elseif(strcmp(node.type ,'All_Var_Dec'))
                    printAllVarDec(node,'program');
                elseif(strcmp(node.type ,'Command_Sequence'))
                    output= strcat(output, '\n');
                    printCommandSequence(node);
                end
                node = node.sibling;
            end
        end
        if(AST_level(1) >= AST.noChildren)
            completed = 1;
        end
    %output = strcat( output, '%%%% End of MATLAB Image Algebra Code\n');
    %file = fopen('generatedCode.m','w');
    %fprintf(file,sprintf(output));
    %fclose(file);

    %sprintf(output)
    %return;
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printCommandSequence
%% Inputs: AST : The abstract syntax tree constructed from the parser
%% Output: None
%% Description:
%% This function generates the MATLAB for the command sequences.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 function [] = printCommandSequence(AST, level)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
     
global AST_level;

if(AST_level(level) > AST.noChildren)
        AST_level(level) = 0;
        AST_level(level - 1) = AST_level(level - 1) + 1;
    else
        node = AST.firstChild;
        for i=1:AST_level(2)
             node = node.sibling;
        end
        printCommand(node, level + 1);
        AST_level(level) = AST_level(level) + 1;
    end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printCommand
%% Inputs: node : The node whose MATLAB is to be generated
%% Output: None
%% Description:
%% This function generates the MATLAB for the given command.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 function [] = printCommand(node, level)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
     
 %global obj_file_handle;
 global output; 
 global st;
 global values;
 %global whileCounter;
 global tempCount;
 global AST_level;
 
  hyphen = 39;
 %global debug;
%  node.type
%  pause;
 if(strcmp(node.type , 'procedure'))
     evaluateProcedure(node);     
 elseif(strcmp(node.type , 'assign'))
     LHS = node.firstChild;
     RHS = node.firstChild.sibling;

     tempCount = 0;
     value = evaluateNode(RHS.firstChild);
     
     %if(LHS.noChildren ~= 0)
     %   output = strcat(output, ' [');     
     %    varNode = LHS.firstChild;    
     %   for i=1:LHS.noChildren
     %       output = strcat(output, sprintf(' %s', varNode.value));
     %       varNode = varNode.sibling;
     %   end
     %   output = strcat( output, ' ] =');
     %else
     %    %output = strcat(output, sprintf( '%s =', LHS.value));
     %end
     
    %if(value.name ~= value.value)
    %    name = '0';
    %else
    %    name = value.name;
    %end
     %output = strcat(output, sprintf( '%s = assign(%s, %c%s%c, %c%s%c)', LHS.value, value.name, hyphen, value.name, hyphen, hyphen, LHS.value, hyphen));
     %output = strcat( output , '; \n\n');
     indexOut = st.index(value.name);
     data = values{indexOut};
     assign('', sprintf('%s', value.name), sprintf('%s', LHS.value));
     index = st.index(LHS.value);
     values{index} = data;

    %output = strcat(output, '\n');
     
 elseif(strcmp(node.type , 'assignArray'))
     %stvalue = ntqu_search(st, node.firstChild.value);
     stvalue = st.search(node.firstChild.value);
     if(stvalue ~= 0)
         arrayNode = node.firstChild.sibling;
         for i = 1:node.noChildren-2
             arrayNode = arrayNode.sibling;
         end
         tempCount = 0;
         var = evaluateNode(arrayNode.firstChild);
         
         output = strcat(output, sprintf('%s.put([', node.firstChild.value, node.firstChild.value));
         
         arrayNode = node.firstChild.sibling;
         
         range = stvalue.ptr_range.firstElement;

         stvalue = st.search(range.start_range);
         if(stvalue == 0)
             output = strcat(output, sprintf('%d', arrayNode.value));
         else
             output = strcat(output, sprintf(', %s', arrayNode.value));
         end
         arrayNode = arrayNode.sibling;
         
         for i = 1:node.noChildren-3
             range = range.next;
             stvalue = st.search(range.start_range);
             if(stvalue == 0)
                 output = strcat(output, sprintf(', %d', arrayNode.value));
             else
                 output = strcat(output, sprintf(', %s', arrayNode.value));
             end
             arrayNode = arrayNode.sibling;
         end
         
         output = strcat(output, sprintf('] , assign(%s, %c%s%c, 0) );', var.name, hyphen, var.name, hyphen));
         
         indexOut = st.index(node.firstChild.value);
         value = values{indexOut};
         index = st.index(node.firstChild.value);
         values{index}.put(vector, assign( value , sprintf('%s', var.name), 0) );

         
         
         %output = strcat(output, sprintf('%s(', node.firstChild.value));
         
         %arrayNode = node.firstChild.sibling;
         
         %range = stvalue.ptr_range.firstElement;
         %stvalue = ntqu_search(st, range.start_range);
         %if(stvalue == 0)
         %    output = strcat(output, sprintf('%s - %d + 1', arrayNode.value, range.start_range));
         %else
         %    output = strcat(output, sprintf('%s - %s + 1', arrayNode.value, stvalue.name));
         %end
         %arrayNode = arrayNode.sibling;
         
         %for i = 1:node.noChildren-3
         %    range = range.next;
         %    stvalue = ntqu_search(st, range.start_range);
        %     if(stvalue == 0)
        %         output = strcat(output, sprintf(',%s - %d + 1', arrayNode.value, range.start_range));
         %    else
         %        output = strcat(output, sprintf(',%s - %s + 1', arrayNode.value, stvalue.name));
         %    end
         %    arrayNode = arrayNode.sibling;
         %end
         
         
         %output = strcat(output, sprintf(') = assign(%s, %c%s%c, %c%s%c);', var.name, hyphen, var.name, hyphen, hyphen, node.firstChild.value, hyphen));
         
             %end
         output = strcat(output, '\n');
     end
 elseif(strcmp(node.type , 'if_statement'))
     
     expr = node.firstChild;
     statement = node.firstChild.sibling;
     %output= strcat(output, 'if(');
     
     %valid = 0;
     %if(strcmp(expr.type, 'expression'))
     %    evaluateCondition(expr.firstChild);
     %end
     if(evaluateCondition(expr.firstChild))
         printCommandSequence(statement, level +1);
     end
     %output= strcat(output, ') \n');
     
     
     %if(strcmp(statement.type, 'Command_Sequence') && valid)
         
     %end
     if(node.noChildren == 3)
        elsepart = node.firstChild.sibling.sibling;
        elsenode = elsepart.firstChild;
        for i=1:elsepart.noChildren
            
            if(strcmp(elsenode.type , 'else_if'))
                
                expr = elsenode.firstChild;
                statement = elsenode.firstChild.sibling;
                if(evaluateCondition(expr.firstChild))
                     printCommandSequence(statement, level +1);
                end
                
                %expr = elsenode.firstChild;
                %statement = elsenode.firstChild.sibling;
                %output= strcat(output, 'elseif(');
                %valid = 0;
                %if(strcmp(expr.type, 'expression'))
                %    evaluateCondition(expr.firstChild);
                %end
                %output= strcat(output, ') \n');
                %if(strcmp(statement.type, 'Command_Sequence') && valid)
                %    printCommandSequence(statement, level +1);
                %end
            else
                statement = elsenode.firstChild.sibling;
                if(evaluateCondition(expr.firstChild))
                     printCommandSequence(statement, level +1);
                end
                    
            end

            elsenode = elsenode.sibling;
        end
     end
     %output =  strcat(output, 'end');
     %output= strcat(output, '\n');
 elseif (strcmp(node.type , 'dowhile_statement'))
     expr =  node.firstChild.sibling;
     statement = node.firstChild;
     %output= strcat(output, '\n'); 
     %if(strcmp(statement.type, 'Command_Sequence'))
     printCommandSequence(statement);
     %end
     %output= strcat(output, 'while (');     
     %if(strcmp(expr.type, 'expression') ==1)
     %   ;
     %end
     %output= strcat(output, ') \n');
     if( evaluateCondition(expr.firstChild))
         printCommandSequence(statement);
     end
     %output =  strcat(output, 'end');
     %output= strcat(output, '\n\n');     
 elseif(strcmp(node.type , 'while_statement'))
     statement =  node.firstChild.sibling;
     expr = node.firstChild;
     %output= strcat(output, '\nwhile (');
     
     %output= strcat(output, ') \n');
     if(evaluateCondition(expr.firstChild))
         printCommandSequence(statement);
     end
     %output =  strcat(output, 'end');
     %output= strcat(output, '\n\n');
 elseif(strcmp(node.type , 'for_statement'))
     statement =  node.firstChild.sibling;
     forstart = node.firstChild.firstChild.sibling;
     forend = node.firstChild.firstChild.sibling.sibling;
    
     if(strcmp(forstart.type , 'numlit'))
         forstart = forstart.value;
     else
         index = st.insex(forstart.value);
         forstart = values{index};
     end
     
     if(strcmp(forend.type , 'numlit'))
         forend = forend.value;
     else
         index = st.insex(forstart.value);
         forend = values{index};
     end
     
     if(AST_level(level) == 0)
         indexA = st.index(node.firstChild.firstChild.value);
         if(indexA)
             temp_symbol = st.get(index);
             temp_value = values{index};
             st.add(sprintf('temp_level%d', level) , temp_symbol);
         end
         st.replace(node.firstChild.firstChild.value, st_new_node(0, node.firstChild.firstChild.value, 'int', 'nil', forstart, 0, 0));
         
     end
     
	if(forstart + AST_level(level) > forend)
         find = st.get(sprintf('temp_level%d', level));
         if(find == 0)
             st.remove(node.firstChild.firstChild.value);
         else
             st.replace(node.firstChild.firstChild.value, find);
             st.remove(sprintf('temp_level%d', level));
         end
        
        AST_level(level) = 0;
        AST_level(level - 1) = AST_level(level - 1) + 1;
	else
         
        printCommandSequence(statement, level + 1);
        
        %AST_level(level) = AST_level(level) + 1;
	end
     
     

     %index = st.index(node.firstChild.firstChild.value);
     
     %for i = forstart:forend
         
    %     if(strcmp(statement.type, 'Command_Sequence') ==1)
    %         printCommandSequence(statement, level + 1);
    %     end
         
    %     values{index} = i;
    % end
    % if(indexA)
    %     st.replace(node.firstChild.firstChild.value, temp_symbol);
    %     values{index} = temp_value;
    % end
     
 elseif(strcmp(node.type,'matlab_sequence'))
     %output= strcat(output, node.firstChild.value);
     %output= strcat(output, '\n');
     
 end
 %pause;
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: evaluateExpression
%% Inputs: exprNode : The expression node whose MATLAB code is to be generated
%% Output: None
%% Description:
%% This function generates the MATLAB for the given expression operation.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function var = evaluateCondition(node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    
    
global output;
 global st;
 global values;
 
 if(strcmp(node.type, 'identifier'))
    find= st.search(node.value);
    if(find == 0)
        display(sprintf('ERROR: %s is not declared',  node.value));
    end
    
    if(node.noChildren > 0)
        range = var.ptr_range.firstElement;
        dimension = node.firstChild;
        matrix = 0;
        for i = 1:node.noChildren
            if(strcmp(dimension.type, 'identifier'))
                index = st.index(dimension.value);
                matrix(i) = values{index};
            else
                matrix(i) = dimension.value;

            end
            range = range.next;
            dimension = dimension.sibling;
        end
        index = st.index(node.value);
        var = values{index}.get(matrix);
    else
        index = st.index(node.value);
        var = values{index};
    end
 elseif(strcmp(node.type, 'numlit'))
    var = node.value;
 elseif(strcmp(node.type, '()') == 1)
    var = evaluateCondition(node.firstChild);
 else
    if(node.noChildren > 1)
        valueA = evaluateCondition(node.firstChild);
        valueB = evaluateCondition(node.firstChild.sibling);
    else
        valueA = evaluateCondition(node.firstChild);
    end
    
    if(strcmp(node.type, '-') && node.noChildren == 1)
        var = -valueA;
    elseif(strcmp(node.type, '+'))
        var = valueA + valueB;
    elseif(strcmp(node.type, '-'))
        var = valueA - valueB;
    elseif(strcmp(node.type, '*'))
        var = valueA * valueB;
    elseif(strcmp(node.type, '/'))
        var = valueA / valueB;
    elseif(strcmp(node.type, '=='))
        if(valueA == valueB)
            var = 1;
        else
            var = 0;
        end
    elseif(strcmp(node.type, '>='))
        if(valueA >= valueB)
            var = 1;
        else
            var = 0;
        end
    elseif(strcmp(node.type, '<='))
        if(valueA <= valueB)
            var = 1;
        else
            var = 0;
        end
    elseif(strcmp(node.type, '>'))
        if(valueA > valueB)
            var = 1;
        else
            var = 0;
        end
    elseif(strcmp(node.type, '<'))
        if(valueA < valueB)
            var = 1;
        else
            var = 0;
        end
    elseif(strcmp(node.type, '&&'))
        if(valueA ~= 0 && valueB ~= 0)
            var = 1;
        else
            var = 0;
        end
    elseif(strcmp(node.type, '||'))
        if(valueA ~= 0 || valueB ~= 0)
            var = 1;
        else
            var = 0;
        end
    else
        disp_error('RunTime', sprintf('Incompatible condition operation: %s', node.type) );
    end
        
 end

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: evaluateNode
%% Inputs: node : The expression node whose MATLAB code is to be generated
%% Output: None
%% Description:
%% This function generates the MATLAB for the given compound expression operation.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 function var = evaluateNode(node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

 %global obj_file_handle;

 global st;
 global values;
 global tempCount;
 forwardslash = 92;
 
 if(strcmp(node.type, 'identifier'))
    var = st.search(node.value);
    if(var == 0)
        disp_error('Runtime', sprintf(' %s is not declared',  node.value));
    end
    
    if(node.noChildren > 0)
        range = var.ptr_range.firstElement;
        arraypoint = ' ';
        arraypoint = strcat(arraypoint, sprintf('%s(', node.value));
        dimension = node.firstChild;
        startrange = st.search(range.start_range);
        if(startrange == 0)
            startrange = sprintf('%d',range.start_range);
        else
            startrange = startrange.name;
        end
        if(strcmp(dimension.type, 'identifier'))
            arraypoint = strcat(arraypoint, sprintf('%s - %s + 1', dimension.value, startrange));
        else
            arraypoint = strcat(arraypoint, sprintf('%d - %s + 1', dimension.value, startrange));
        end
        range = range.next;
        dimension = dimension.sibling;
        for i = 1:node.noChildren-1
            startrange = st.search(range.start_range);
            if(startrange == 0)
                startrange = sprintf('%d',range.start_range);
            else
                startrange = startrange.name;
            end
            if(strcmp(dimension.type, 'identifier'))
                arraypoint = strcat(arraypoint, sprintf(',%s - %s + 1', dimension.value, startrange));
            else
                arraypoint = strcat(arraypoint, sprintf(',%d - %s + 1', dimension.value, startrange));
            end
            range = range.next;
            dimension = dimension.sibling;
        end
        arraypoint = strcat(arraypoint,')');
        var = st_new_node(0, arraypoint, 'int', 'nil', arraypoint, 0, 0);
    end
 elseif(strcmp(node.type, 'numlit'))
    var = st_new_node(0, sprintf('%d',node.value), 'int', 'nil', node.value, 0, 0);
 elseif(strcmp(node.type, '()') == 1)
    var = evaluateNode(node.firstChild);
 else
     
    node1 = evaluateNode(node.firstChild);
    index1 = st.index(node1.name);
    if(index1)
        value1 = values{index1};
    else
        value1 = node1.value;
    end
    
    if(node.noChildren > 1)
        node2 = evaluateNode(node.firstChild.sibling);
        index2 = st.index(node2.name);
        if(index2)
            value2 = values{index2};
        else
            value2 = node2.value;
        end
    else
        node2 = 0;
    end
    
    
    %Generate a temp value
    tempID = sprintf('tmp%d', tempCount);
    tempCount = tempCount + 1;

    if((strcmp(node.type, '(+)') || strcmp(node.type,'!gcon') || strcmp(node.type, '[^]') || strcmp(node.type,'!mmax') || strcmp(node.type, '[v]') || strcmp(node.type,'!mmin') || strcmp(node.type, '(^)') || strcmp(node.type,'!amax') || strcmp(node.type, '(v)') || strcmp(node.type,'!amax') || strcmp(node.type, '(^)<') || strcmp(node.type, '(v)<') || strcmp(node.type, '[^]<') || strcmp(node.type, '[v]<') || strcmp(node.type, '(+)<')) )
        
        coord = 0;
        if(strcmp(node2.arrayType, 'vartpl') == 0)
            nodeR = node2.ptr_coord.firstElement;
            for c=1:node2.ptr_coord.noElements
                coord(c) = nodeR.coord;
                nodeR = nodeR.next;
            end
        end
    end

    if(strcmp(node.type, '+'))
        temp = IAImgAdd(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), sprintf('%s', tempID));
    elseif(strcmp(node.type, '-') && node.noChildren == 1)
        temp =  IAImgNeg(value1, sprintf('%s', node1.name), sprintf('%s', tempID));
    elseif(strcmp(node.type, '*'))
        temp = IAImgMult(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), sprintf('%s', tempID));
    elseif(strcmp(node.type, '^'))
        temp = IAImgPower(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), sprintf('%s', tempID));
    elseif(strcmp(node.type, '/'))
        temp = IAImgDiv(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), sprintf('%s', tempID));
    elseif(strcmp(node.type, '@'))
        temp = IAImgMap(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), sprintf('%s', tempID));
    elseif(strcmp(node.type, '!restrict') || strcmp(node.type, '|_'))
        temp = IASingleBarRestrict(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), sprintf('%s', tempID));
    elseif(strcmp(node.type, '!extend') || strcmp(node.type, '|^'))
        temp = IAExtend(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), sprintf('%s', tempID));
    elseif(strcmp(node.type, '!union'))
        temp = IAUnion(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), sprintf('%s', tempID));
    elseif(strcmp(node.type, '!intsct'))
        temp = IAIntsct(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), sprintf('%s', tempID));
    elseif(strcmp(node.type, forwardslash))
        temp = IASubset(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), sprintf('%s', tempID));
    elseif( strcmp(node.type, '(+)') || strcmp(node.type,'!gcon'))
        temp = IAImgConvolve(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), coord, sprintf('%s', tempID));
    elseif(strcmp(node.type, '[^]') || strcmp(node.type,'!amax'))
        temp = IAImgAddiMin(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), coord, sprintf('%s', tempID));
    elseif(strcmp(node.type, '[v]') || strcmp(node.type,'!amin'))
        temp = IAImgAddiMax(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), coord, sprintf('%s', tempID));
    elseif(strcmp(node.type, '(^)')|| strcmp(node.type,'!mmax'))
        temp = IAImgMultMin(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), coord, sprintf('%s', tempID));
    elseif(strcmp(node.type, '(v)')|| strcmp(node.type,'!mmin'))
        temp = IAImgMultMax(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), coord, sprintf('%s', tempID));
    elseif(strcmp(node.type, '(+)<') || strcmp(node.type,'!gcon'))
        temp = IAImgRecursiveTemplateConvolve(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), coord, sprintf('%s', tempID));
    elseif(strcmp(node.type, '[^]<') || strcmp(node.type,'!amax'))
        temp = IAImgRecursiveTemplateAddiMin(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), coord, sprintf('%s', tempID));
    elseif(strcmp(node.type, '[v]<') || strcmp(node.type,'!amin'))
        temp = IAImgRecursiveTemplateAddiMax(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), coord, sprintf('%s', tempID));
    elseif(strcmp(node.type, '(^)<')|| strcmp(node.type,'!mmax'))
        temp = IAImgRecursiveTemplateMultMin(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), coord, sprintf('%s', tempID));
    elseif(strcmp(node.type, '(v)<')|| strcmp(node.type,'!mmin'))
        temp = IAImgRecursiveTemplateMultMax(value1, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), coord, sprintf('%s', tempID));
    elseif(strcmp(node.type,'domain'))
        temp =  domain(sprintf('%s', node1.name), sprintf('%s', tempID));
    elseif(strcmp(node.type,'!sum'))
        temp =  IAImgSum(value1, sprintf('%s', node1.name), sprintf('%s', tempID));
    elseif(strcmp(node.type,'!prod'))
        temp =  IAImgProd(value1, sprintf('%s', node1.name), sprintf('%s', tempID));
    elseif(strcmp(node.type,'!max'))
        temp =  IAImgMax(value1, sprintf('%s', node1.name), sprintf('%s', tempID));
    elseif(strcmp(node.type,'!min'))
        temp =  IAImgMin(value1, sprintf('%s', node1.name), sprintf('%s', tempID));
    elseif(strcmp(node.type,'!mean'))
        temp =  IAImgMean(value1, sprintf('%s', node1.name), sprintf('%s', tempID));
    elseif(strcmp(node.type,'!stdev'))
        temp =  IAImgStdev(value1, sprintf('%s', node1.name), sprintf('%s', tempID));
    elseif(strcmp(node.type, '-'))
        temp = IAImgSub(node1.name, sprintf('%s', node1.name),  value2, sprintf('%s',  node2.name), sprintf('%s', tempID));
    elseif(strcmp(node.type,'!chi') || strcmp(node.type,'chi'))
        temp = IAImgCHI(sprintf('%s', node.firstChild.sibling.sibling.value), value2, sprintf('%s', node2.name), value1, sprintf('%s', node1.name), sprintf('%s', tempID));
    elseif(strcmp(node.type,'restrict') || strcmp(node.type, '||_'))
        temp =  IADoubleBarRestrict(sprintf('%s', node.firstChild.sibling.sibling.value), value2, sprintf('%s', node2.name), value1, sprintf('%s', node1.name), sprintf('%s', tempID));
    else
        disp_error('RunTime', sprintf('Unknown Type: %s', node.type) );
    end
    var = st.search(tempID);
    indexOut = st.index(tempID);
    values{indexOut} = temp;
 end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: evaluateUnExpr
%% Inputs: AST : The unary expression whose MATLAB is to be generated.
%% Output: None
%% Description:
%% This function generate MATLAB for unary expression
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [variable] = evaluateUnExpr(node)
% %global obj_file_handle;
% global output;
% global st;
%    
%     nodeOper =  node.firstChild;
%     nodeOperand = nodeOper.sibling;
%     nodeOperand.type;
%     nodeOperand.value;
%    if((strcmp(nodeOper.type , 'STRONG_OP') == 1) && (strcmp(nodeOper.value,'!sum') == 1))    
%         output = strcat( output, sprintf(' IAImgSum(')); 
%    elseif((strcmp(nodeOper.type , 'STRONG_OP') == 1) && (strcmp(nodeOper.value,'!prod') == 1)) 
%        output = strcat( output, sprintf(' IAImgProd(' ));
%    elseif((strcmp(nodeOper.type , 'STRONG_OP') == 1) && (strcmp(nodeOper.value,'!max') == 1))    
%        output = strcat( output, sprintf(' IAImgMax(' ));
%    elseif((strcmp(nodeOper.type , 'STRONG_OP') == 1) && (strcmp(nodeOper.value,'!min') == 1))    
%        output = strcat( output, sprintf(' IAImgMin(' ));
%    elseif((strcmp(nodeOper.type , 'STRONG_OP') == 1) && (strcmp(nodeOper.value,'!mean') == 1))    
%         output = strcat( output, sprintf(' IAImgMean(' ));
%    elseif((strcmp(nodeOper.type , 'STRONG_OP') == 1) && (strcmp(nodeOper.value,'!stdev') == 1))    
%         output = strcat( output, sprintf(' IAImgStdev(' ));
%    elseif((strcmp(nodeOper.type , 'STRONG_OP') == 1) && (strcmp(nodeOper.value,'!stat') == 1))    
%         output = strcat( output, sprintf(' IAImgStatistic(' ));     
%    elseif((strcmp(nodeOper.type , 'STRONG_OP') == 1) && (strcmp(nodeOper.value,'!gray') == 1))    
%         output = strcat( output, sprintf(' Grayscale(' ));     
%    elseif((strcmp(nodeOper.type , 'WEAK_OP') == 1) && (strcmp(nodeOper.value,'-') == 1)) 
%         output = strcat( output, sprintf('-(')); 
%    end
%     if((strcmp(nodeOperand.type , 'expression') == 1))
%        evaluateExpression(nodeOperand);  
%        output = strcat(output,  sprintf(' ) '));
%     elseif((strcmp(nodeOperand.type , 'identifier') == 1))
%          %node1 = ntqu_search(st, nodeOperand.value);
%          node1 = st.search(nodeOperand.value);
%          if(node1 ~= 0)
%              if((strcmp(node1.arrayType,'image') == 1))
%                  tempVar = node1;
%              elseif((strcmp(node1.arrayType,'tpl') == 1)) 
%                  %% Write the code for other types later...  
%                  Display('Template found ReST later');  
%                  %pause;
%              else
%                  tempVar = node1;
%              end  
%              output = strcat(output,  sprintf('%s) ', nodeOperand.value));
%              variable = tempVar;
%          end
%     end
     %nodeOper.value;
     %pause;

     %%variable.name = tName;
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: evaluateBinExpr
%% Inputs: node : The binary expression whose MATLAB is to be generated.
%% Output: None
%% Description:
%% This function generate MATLAB for binary expression
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %function [] = evaluateBinExpr(node)
 %global obj_file_handle;
 %global output;
%global st;
 %hyphen = 39;
 %global debug;
 %nodeFactor = node.firstChild;
 %if(strcmp(nodeFactor.type , 'Binary_Expression') == 1)
 %    evaluateBinExpr(nodeFactor);
 %else
 %       for i= 1:node.noChildren
 %           if(strcmp(nodeFactor.type , 'identifier') == 1)
 %               output = strcat(output, sprintf(' %s ', nodeFactor.value));                       
 %           else
 %               if((strcmp(nodeFactor.type , 'WEAK_OP') == 1) && (strcmp(nodeFactor.value , '!=') == 1))
 %                   output = strcat(output, sprintf(' ~= '));
 %               elseif(strcmp(nodeFactor.type , 'numlit') == 1)
 %                   output = strcat(output, sprintf(' %d ', nodeFactor.value));
 %               elseif(strcmp(nodeFactor.type , 'Unary_Expression') == 1)
 %                   evaluateUnExpr(nodeFactor);
 %               else
 %                   output = strcat(output, sprintf(' %s ', nodeFactor.value));
 %               end
 %           end
 %           nodeFactor = nodeFactor.sibling;
 %       end 
 %end
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: evaluateProcedure
%% Inputs: node : The procedure node whose MATLAB code is to be generated.
%% Output: None
%% Description:
%% This function generates MATLAB for a procedure
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 function [] = evaluateProcedure(node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*     
     
 global output;
 global st;
 global values;
 global display_List;
 global display_Count;
 hyphen = 39;
 
 procName = node.firstChild.value;
 
 if(strcmp(procName, 'size') == 1)
     output = strcat(output, ' size (');     
     if(strcmp(node.firstChild.sibling.firstChild.type, 'expression') == 1)
         evaluateExpression(node.firstChild.sibling.firstChild);
         output = strcat(output, ' )');
     else
         display(' Illegal argument for function ');
     end
 elseif (strcmp(procName, 'domain') == 1)
     nodeChild = node.firstChild.sibling.firstChild;
     if(strcmp(nodeChild.type, 'expression') == 1)
         if(strcmp(nodeChild.firstChild.type, 'identifier') == 1)
             %output = strcat(output, sprintf('IAimgsiz(%s, ndims%s, npixels%s)',nodeChild.firstChild.value,nodeChild.firstChild.value,nodeChild.firstChild.value ));
             output = strcat(output, sprintf(' %s ',nodeChild.firstChild.value));
            %evaluateExpression(nodeChild);
         else
         end
     else
         display(' Illegal argument for function ');
     end
 elseif(strcmp(procName, 'readimage') ==1)   
    paramNode = node.firstChild.sibling;     
         if(paramNode.noChildren == 2)
             if(strcmp(paramNode.firstChild.type, 'strlit') ==1)
                 fileName = paramNode.firstChild.value;
                 if(strcmp(paramNode.firstChild.sibling.type, 'identifier') ==1)
                     iden = paramNode.firstChild.sibling.value;
                     node = st.search(iden);
                     if(node == 0)
                         disp_error('Runtime', 'Variable not declared');
                     end
                     if(strcmp(node.arrayType, 'image') ~= 1)
                         disp_error('Runtime', 'Variable not an image');
                     end
                     
                     imgName = paramNode.firstChild.sibling.firstChild.value;
                     temp = update(sprintf('%s', imgName), sprintf('%s', fileName));
                     index = st.index(imgName);
                     values{index} = temp;
                  
                end
             else
                 disp_error('Runtime', 'Invalid value for filename in read Image');
             end
         end
% elseif(strcmp(procName, 'chi') ==1 ||strcmp(procName, '!chi') ==1)     
%     paramNode = node.firstChild.sibling; 
%        if(paramNode.noChildren == 3)
%            if(strcmp(paramNode.firstChild.firstChild.type, 'strlit') ==1)
%                 op = paramNode.firstChild.firstChild.value;
%                 if(strcmp(paramNode.firstChild.sibling.firstChild.type, 'numlit') ==1 || strcmp(paramNode.firstChild.sibling.firstChild.type, 'identifier') ==1)
%                 number = paramNode.firstChild.sibling.firstChild.value;
%                    if(strcmp(paramNode.firstChild.sibling.sibling.firstChild.type, 'identifier') ==1)
%                        iden = paramNode.firstChild.sibling.sibling.firstChild.value;
%                        %node = ntqu_search(st, iden);
%                        node = st.search(iden);
%                        if(node == 0)
%                            display(' Identifier not present ');
%                        end
%                        if(strcmp(node.arrayType, 'image') ~= 1)
%                            display('The identifier in which the image is read is not of image type');
%                            display(iden);
%                            return;
%                        end
%                        if(strcmp(paramNode.firstChild.sibling.firstChild.type, 'numlit') ==1)
%                            output = strcat(output, sprintf (' IAImgCHI( %c%s%c,%d, %s)',hyphen, op, hyphen, number, iden));
%                        else
%                            output = strcat(output, sprintf (' IAImgCHI( %c%s%c,%s, %s)',hyphen, op, hyphen, number, iden));
%                        end
%                    end
%                
%                  end
%             else
%                 display('Invalid value for operation in CHI... ');
%             end
%         end
         
 elseif((strcmp(procName, 'display') ==1) || (strcmp(procName, 'write') ==1))
     
     argList = node.firstChild.sibling;
     arg = argList.firstChild;
     %image =0;
     %displayStr = ' ' ;
%      if(debug == 1)
%         display('in display');
%         pause;
%      end
     if(argList.noChildren ~=0)
         arg.type;
         arg.value;
         
        %node =ntqu_search(st, arg.firstChild.value);
        node = st.search(arg.value);
       % node.arrayType
        %pause;
        if((node ~=0) && (strcmp(node.arrayType,'image') == 1))
            arg2 = arg.sibling;
%             arg2.firstChild.type
%             pause;
            if(strcmp(arg2.type, 'strlit') == 1)
                if(strcmp(procName, 'display') ==1)
                    index = st.index(arg.value);
                    display_Count = display_Count + 1;
                    display_List{display_Count, 1} = sprintf('IMG: %s', arg2.value);
                    display_List{display_Count, 2} = hashmatrix( values{index}, sprintf('%s', arg.value) );
                else
                    imwrite(hashmatrix(arg.firstChild.value, sprintf('%s', arg.value)), -1, sprintf('%s', arg2.value) );
                end
            else
               disp_error('Runtime', 'Title should be a string');
            end
        elseif(node ~= 0 || strcmp(arg.firstChild.type,'strlit') == 1)
%             if((strcmp(node.type, 'int') == 1) & (strcmp(node.arrayType, 'nil') == 1) )
%                 displayStr = strcat(displayStr, sprintf(' %d', node.value));
%             elseif((strcmp(node.type, 'float') == 1 | strcmp(node.type, 'double') == 1) & (strcmp(node.arrayType, 'nil') == 1))
%                 displayStr = strcat(displayStr, sprintf(' %f', node.value));
%             else
%                 display('Invalid string 2'); 
%             end
            for i=1:argList.noChildren
            
                %node =ntqu_search(st, arg.firstChild.value);
                node = st.search(arg.firstChild.value);
                if(node ~= 0) 
                    displayStr = strcat(displayStr, sprintf(' %d', node.value));
                else
                    displayStr = strcat(displayStr, sprintf(' %s', arg.firstChild.value));
                end
                
                arg = arg.sibling;
            end
            
            display(displayStr);
            
           % displayStr = strcat(displayStr, sprintf(' %s ', node.name));
%             output = strcat(output, sprintf(' %s', node.name));
%             arg = arg.sibling;
 %       elseif(strcmp(arg.firstChild.type,'strlit') == 1)          
 %           arg.firstChild.value
 %           %pause;
 %           displayStr = strcat(displayStr, sprintf(' %s', arg.firstChild.value));
 %           arg = arg.sibling;
        else
            display('Invalid string'); 
            %arg = arg.sibling;
        end
        
%        if(image == 0)
            %arg = arg.sibling.sibling;
%                for i=2:argList.noChildren
%                     arg.firstChild.value
%                     pause;
%                    if(strcmp(arg.firstChild.type,'strlit') == 1)
%                        displayStr = strcat(displayStr, sprintf(' %s', arg.firstChild.value));
%                    else
%                        node =ntqu_search(st, arg.firstChild.value);
%                        if(node~= 0)
%                             if((strcmp(node.type, 'int') == 1) & (strcmp(node.arrayType, 'nil') == 1) )
%                                     displayStr = strcat(displayStr, sprintf(' %d',node.value));
%                             elseif((strcmp(node.type, 'float') == 1 | strcmp(node.type, 'double') == 1) & (strcmp(node.arrayType, 'nil') == 1))
%                                     displayStr = strcat(displayStr, sprintf(' %f', node.value));
%                             else
%                                 display('Invalid string 2'); 
%                             end
 %                           output = strcat(output, sprintf(' %s', node.name)); 
 %                       else
 %                            display('Invalid string 2'); 
 %                       end
 %                   end
 %                   arg = arg.sibling;
 %               end
 %               arg = arg.sibling;
 %               output = strcat(output, sprintf('display(%s);',displayStr));
 %               output = strcat( output, '\n'); 
 %               
 %       end
     end
elseif(strcmp(procName, 'quit') ==1)
    output = strcat( output, 'quit;\n'); 
 end
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printAllVarDec
%% Inputs: AST : The AST whose variable declarations are to be evaluated.
%% Output: None
%% Description:
%% This function generates MATLAB for a variable declaratios
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
 
 function [] = printAllVarDec(AST, program)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*     
     
global AST_level;
%global ASTcount_2;
 %global obj_file_handle;
 %global output;

    if(AST_level(2) > AST.noChildren)
        AST_level(2) = 0;
        AST_level(1) = AST_level(1) + 1;
    else
        node = AST.firstChild;
        for i = 1:AST_level(2)
             node = node.sibling;
        end

        printVarDec(node, program);
        AST_level(2) = AST_level(2) + 1;
    end

 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printVarDec
%% Inputs: node : The node which is a declaration
%% Output: None
%% Description:
%% This function calls functions to generate MATLAB code depending on the
%% declaration type (i.e. image, template or variable)
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
 function printVarDec(node, program)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*     

    node = node.firstChild;
    if(strcmp(node.type,'type'))
        %type = node.value;
        node = node.sibling;

        if(strcmp(node.type,'array_list'))
            %node = node.sibling;
            %printArrayList(node);
        elseif(strcmp(node.type,'img_list'))
            %node = node.sibling;
            printImgList(node, program);
        elseif(strcmp(node.type,'tpl_list'))
            %node = node.sibling;
            printImgList(node, program);
        elseif(strcmp(node.type,'matrix_dec'))
            %node = node.sibling;
            printImgMatrix(node);
        elseif(strcmp(node.type,'matlab_sequence'))
            execute(node.firstChild.value);
        elseif(strcmp(node.type,'map_dec') || (strcmp(node.type,'variant_template_dec')))
            printMapTree(node);
        elseif(strcmp(node.type,'valset_list'))
            printValSet(node);
        elseif(strcmp(node.type,'pointset_dec'))
        else
            printVarDecList(node, program);
        end
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printValSet
%% Inputs: node : The node which generates code for declaration of images
%%         type : The type of the image
%% Output: None
%% Description:
%% The function creates a MATLAB array from the provided valset
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function printValSet(node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    
    
    global st;
    global values;
    %global output;
   % output = '';
    ValsetNode = node.firstChild;
    for i = 1: node.noChildren
        index = st.index(ValsetNode.firstChild.value);
        
        output = strcat( output, sprintf('values{%d} = [', index));
        
        
        if(strcmp(ValsetNode.firstChild.sibling.type, 'identifier'))
            matrix(1) = 0;
            %output = strcat( output, ' 0');
            for j = 1:ValsetNode.firstChild.sibling.sibling.value
                %output = strcat( output, sprintf(', %d', j));
                matrix(j+1) = j;
            end
            values{index} = matrix;
        else
            node = ValsetNode.firstChild.sibling;
            output = strcat( output, sprintf(' %d', node.value));
            matrix(1) = node.value;
            node = node.sibling;
            for j = 2:ValsetNode.noChildren-1
                %output = strcat( output, sprintf(', %d', node.value));
                matrix(j) = node.value;
                node = node.sibling;
            end
             values{index} = matrix;
        end
        %output = strcat( output, ' ];\n');
        ValsetNode = ValsetNode.sibling;
    end
    %execute(output);
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printMapTree
%% Inputs: node : The node which generates code for declaration of images
%%         type : The type of the image
%% Output: None
%% Description:
%% This function creates a MATLAB tree defined by the code.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function [] = printMapTree(node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    
    
    %global output;
    global st;
    global values;
    global AST;
    %global AST;
    AST = nt_new;
    %output = '';
    %output = strcat( output, '\n');
    %output = strcat( output, '%%%% Generating Map Tree for variable');
    %output = strcat( output, sprintf(' %c%s%c', 39, AST.firstChild.value, 39));
    %output = strcat( output, '\n');
    printMapTreeNode(node.firstChild.sibling);
    index  = st.index(node.firstChild.value);
    %output = strcat(output, sprintf('values{%d} = AST;', index));
    values{index} = AST;
    %execute(output);
    %ASTcount_2 = ASTcount_2 + 1;
    %output = strcat( output, '\n');
    %output = strcat( output, '%%%% End of Map Tree generation for variable');
    %output = strcat( output, sprintf(' %c%s%c', 39, AST.firstChild.value, 39));
    %output = strcat( output, '\n');
    
function [] = printMapTreeNode(node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    
    
%global output;
global AST;
global stack;
 if(node.noChildren > 0)
     currentNode = node.firstChild;
     for i = 1:node.noChildren
         printMapTreeNode(currentNode);
         currentNode = currentNode.sibling;
     end
     %output = strcat(output, sprintf('AST = buildTree(nt_new_node(%c%s%c, 0), %d);', 39, node.type, 39, node.noChildren));
     %output = strcat( output, '\n'); 
     AST = buildTree(nt_new_node(sprintf('%s', node.type), 0), node.noChildren);
 elseif(strcmp(node.type, 'identifier'))
    %output = strcat(output, sprintf('stack = ntst_push(stack, new_stack_node(nt_new_node(%cidentifier%c , %c%s%c)));', 39, 39, 39, node.value, 39));
    %output = strcat( output, '\n'); 
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , sprintf('%s', node.value))));
 elseif(strcmp(node.type, 'numlit'))
    %output = strcat(output, sprintf('stack = ntst_push(stack, new_stack_node(nt_new_node(%cnumlit%c , %d)));', 39, 39, node.value));
    %output = strcat( output, '\n');
    stack = ntst_push(stack, new_stack_node(nt_new_node('numlit' , node.value)));
 end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printImgMatrix
%% Inputs: node : The node which generates code for declaration of images
%%         type : The type of the image
%% Output: None
%% Description:
%% This function creates a MATLAB matrix defined by the code.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function [] = printImgMatrix(AST)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    
    
    global st;
    global values;
    Row = AST.firstChild.sibling.firstChild;
    
    %output = sprintf('matrix = [');
    i = 1;
    matrix = 0;
    while(strcmp(Row.type, 'identifier') == 1)
        j = 1;
        Column = Row.firstChild;
        while(strcmp(Column.type, 'identifier') == 1)
            %output = strcat(output, sprintf(' %s',Column.value));
            matrix(i, j) =  str2double(Column.value);
            Column = Column.sibling;
            j = j + 1;
        end
        %output = strcat(output, ';');
        Row = Row.sibling;
        i = i + 1;
    end
    %output = output(1 : length(output)-1);
    %output = strcat(output, ' ];\n');
    temp = update(sprintf('%s',AST.firstChild.value), matrix);
    index  = st.index(AST.firstChild.value);
    %output = strcat(output, sprintf('values{%d} = update(%c%s%c, matrix);', index, 39, AST.firstChild.value, 39));
    values{index} = temp;
    %output = strcat(output, '\n');
    %execute(output);
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printImgList
%% Inputs: node : The node which generates code for declaration of images
%%         type : The type of the image
%% Output: None
%% Description:
%% This function calls functions to generate MATLAB code for image declarations
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function printImgList(AST, program)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    
    
%global obj_file_handle;
%global output;
global st;
global values;
%global output;
%global ASTcount_3;

%node = AST.firstChild;
%for i=1:AST.noChildren-1
%            node = node.sibling;
%end
%if(strcmp(node.type, 'Range_List')~=1)
%    return;
%end
%nDims = node.noChildren;
%nodeDims = node;
node = AST.firstChild;

if(strcmp(program,'function') == 1)
    for i=1:(AST.noChildren -1)
        %output = strcat(output, sprintf ('%s, ', node.value)); 
        node = node.sibling;
    end
else
    %output = '';
    for i = 1:AST.noChildren - 1
        %node.value
        %st.display()
        index = st.index(node.value);
        
        %output = strcat(output, sprintf ('values{%d} = hashtable;', index) );
        values{index} = hashimage();%values{index} = hashtable;
        %output = strcat(output, '\n');
        node = node.sibling;
    end
    %execute(output);
end
    %if(ASTcount_3 > AST.noChildren)
    %    ASTcount_3 = 1;
    %    ASTcount_2 = ASTcount_2 + 1;
    %else
    %    i = 1;
    %    
    %    while( i < ASTcount_3)
    %         node = node.sibling;
    %    end
    %    execute(sprintf ('%s = hashtable;',node.value));
    %    ASTcount_3 + ASTcount_3 + 1;
    %end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printVarDecList
%% Inputs: AST : The node which is a variable declaration
%% Output: None
%% Description:
%% This function generates MATLAB code for a variable declaration
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  


function printVarDecList(AST, program)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    
    
%global obj_file_handle;
%global output;
global st;
global values;
    %display_Tree(AST);
    node = AST.firstChild;
    if(strcmp(program,'function'))
        for i=1:AST.noChildren
            %output = strcat(output, sprintf ('%s, ', node.firstChild.value)); 
            node = node.sibling;
        end
    else
        %output = '';
        for i=1:AST.noChildren
            
            idenNode = node.firstChild;
            index = st.index(idenNode.value);
            %output = strcat(output, sprintf ('values{%d} = ', index));
            
            if(node.noChildren == 2)
                nodeInit = idenNode.sibling;
                if((strcmp(nodeInit.type,'numlit') == 1) || (strcmp(nodeInit.type,'boollit') == 1))
                    %output = strcat(output , sprintf(' %d ;' , nodeInit.value));
                    values{index} = nodeInit.value;
                else
                    index2 = st.index(idenNode.value);
                    %output = strcat(output, sprintf (' values{%d}', index));
                    values{index} = values{index2};
                end 
            elseif(node.noChildren == 3)
                nodeInitreal = idenNode.sibling;
                nodeInitImaginary = nodeInitreal.sibling;
                %output = strcat(output , sprintf(' complex(%d,%d);' , nodeInitreal.value, nodeInitImaginary.value ));
                values{index} = complex(nodeInitreal.value,nodeInitImaginary.value);
                
            else
                %output = strcat( output, ' = 0 ;');
                values{index} = 0;
            end
            %output = strcat(output, '\n ');
            node = node.sibling;
        end
        %execute(output);
    end
   % node = AST.firstChild;
   % for i=1:AST.noChildren
   %     if((strcmp(node.type,'var_init') == 1) & (strcmp(program,'function') == 1))
            %idenNode = node.firstChild;
            %identifier = idenNode.value;
            %output = strcat(output, sprintf ('%s, ', identifier));       
   %     elseif((strcmp(node.type,'var_init') == 1))
%             display('here');
%             node.noChildren
            %idenNode = node.firstChild;
            
            %identifier = idenNode.value;
            %output = strcat(output, sprintf ('%s ', identifier));       

    %    end
        
    %end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: addSymbolTable
%% Inputs: AST : None
%% Output: None
%% Description:
%% This function generates the Symbol Table for which the program will use
%% to perform the Image Algebra operations%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%function [] = addSymbolTable()
%global obj_file_handle;
%global output;
%global st;
%hyphen = 39;
%output = strcat( output, '\n%%%% Start of Symbol Table Generation\n');
%node = st.firstElement;
%output = strcat( output, 'global st;\nst = ntqu_new;\n');
%    for i=1:st.noElements
%        if(node.ptr_range ~= 0)%Generate Ranges
%            output = strcat( output, 'rq = ntqu_new;\n');
%            nodeR = node.ptr_range.firstElement;
%            for j=1:node.ptr_range.noElements
%                
%               if(ntqu_search(st, nodeR.start_range) == 0)
%                   startrange = sprintf('%d', nodeR.start_range);   
%               else
%                   startrange = sprintf('%c%s%c', hyphen, nodeR.start_range, hyphen);   
%               end
%               if(ntqu_search(st, nodeR.end_range) == 0)
%                   endrange = sprintf('%d', nodeR.end_range);   
%               else
%                   endrange = sprintf('%c%s%c', hyphen, nodeR.end_range, hyphen);   
%               end
%                output = strcat(output, sprintf('rq = ntqu_push(rq, range_new_node(%s, %s));',startrange, endrange));%Push range 1 on stack for symbol table
%                output = strcat( output, '\n');
%                nodeR = nodeR.next;
%            end
%            rqtext = 'rq';
%        else
%            rqtext = '0';
%        end
%        if(node.ptr_coord ~= 0)%Generate Coordinates
%            output = strcat( output, 'cq = ntqu_new;\n');
%            nodeC = node.ptr_coord.firstElement;
%            for k=1:node.ptr_coord.noElements
%                
%                coord = nodeC.coord;
%                output = strcat(output, sprintf('cq = ntqu_push(cq, coord_new_node(%d));', coord));%Push range 1 on stack for symbol table
%                output = strcat( output, '\n');
%                nodeC = nodeC.next;
%            end
%            cqtext = 'cq';
%        else
%            cqtext = '0';
%        end
%        if(node.scan == 0)%Generate Scan
%            scan = '0';
%        else
%            scan =  sprintf('%c%s%c', hyphen, node.scan, hyphen);
%        end
%        if(node.connectivity == 0)% Generate Neigbor
%            connectivity = '0';
%        else
%            connectivity =  sprintf('%c%s%c', hyphen, node.connectivity, hyphen);
%        end
%        if(node.value == 0)%Generate Value
%            value = '0';
%        else
%            value = sprintf('%d',node.value);
%        end
%        output = strcat(output, sprintf('node = st_new_PSnode(0, %c%s%c, %c%s%c, %c%s%c, %s, %s, %s, %s, %s);', hyphen,node.name, hyphen, hyphen, node.type, hyphen, hyphen,node.arrayType, hyphen, value, rqtext, cqtext, scan, connectivity));%TPL symbol
%        output = strcat( output, '\nst = ntqu_push(st, node);\n');
%        node = node.next;
%    end
%    output = strcat( output, '%%%% End of Symbol Table Generation\n');
%    %output = strcat( output, 'display_st(st);pause;\n');%
%

        

        
        
        
        
        
        %AST = T1
        %ASTcount_2 = T2
        %ASTcount_1 = T3
        %completed = T4
        %st = T5
