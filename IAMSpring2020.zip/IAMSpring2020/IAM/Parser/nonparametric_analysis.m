
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: nonparametric_analysis
%% Inputs: None
%% Output: Analysis object set for nonparametric error analysis
%% Description:
%% This function is an object that is used to perform non parametric analysis
%% Note that this is n empty object.  All operations performed are executed
%% with the desired functions.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function listObject = nonparametric_analysis()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%NONPARAMETRIC_CNALYSIS Summary of this function goes here
%   Detailed explanation goes here




  
  listObject = struct('type', 'nonparametric'); 
end

