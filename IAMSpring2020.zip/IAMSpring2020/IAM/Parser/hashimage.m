
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: hashimage
%% Inputs: none
%% Output: a MATLAB struct
%% Side Effects:
%% Description: This function builds a hash image that can be used
%% to hold large volumes of data using the Yoder set concept
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function listObject = hashimage() 
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

  keys = {};
  data = {};
   listObject = struct('matrix',@to_matrix_hash,...
                       'populate',@populate_hash,...
                       'clone',@hash_clone,...
                       'get',@get_vector,...
                       'put',@put_vector,...
                       'inc',@inc_vector, ...
                       'display', @display_hash); 
                  
  %% displays the hash
  function display_hash()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*      
      
      for i = 1:length(data)
          display(keys{i});
          display(data{i});
      end
  end
                  
  % creates a copy of the hashimage
  function hash = hash_clone()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*      

      hash = hashimage();
      if(isempty(data) == 0)
          if(isstruct(data{1}))

              for i = 1:length(data)

                  hash.put(keys{i}, data{i}.clone());
              end
          else
              for i = 1:length(data)
                  hash.put(keys{i}, data{i});
              end
          end
      end
  end
  
  % gets a value in the hashimage at the vector location
  function value = get_vector(vector)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
      
    if(length(vector) == 1)
        index = find(cell2mat(keys) == vector);
        if isempty(index)
            value = 0;
        else
            value = data{index};
        end
        
    else
        index = find(cell2mat(keys) == vector(1));
        if isempty(index)
            value = 0;
        else
            value = data{index}.get(vector(2:end));
        end
    end
  end


  %puts a value in the hashimage at the vector location
  function put_vector(vector, value)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

    if(length(vector) == 1)
        index = find(cell2mat(keys) == vector);
        if isempty(index)
            if isempty(keys)
                keys{1} = vector;
                data{1} = value;
            else
                keys{end+1} = vector;
                data{end+1} = value;
            end
        else
            data{index} = value;
        end
    
    else
        index = find(cell2mat(keys) == vector(1));
        if isempty(index)
            if isempty(keys)
                keys{1} = vector(1);
                data{1} = hashimage();
                data{1}.put(vector(2:end), value);
            else
                keys{end+1} = vector(1);
                data{end+1} = hashimage();
                data{end}.put(vector(2:end), value);
                
            end
        else
            data{index}.put(vector(2:end), value);
        end
    end
    
  end

    %returns a matrix from the hashimage with boundries as inputs.
    function matrix = to_matrix_hash(infimum, supremum)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*        
        
        l = length(infimum);
        
        if(l == 1)
            matrix(supremum(1)- infimum(1) +1) = 0;
            for i = infimum(1):supremum(1)
                matrix(i-infimum(1)+1) = get_vector(i);
            end
        elseif(l == 2)
            matrix(supremum(1)- infimum(1) +1, supremum(2)- infimum(2) +1) = 0;
            for i = infimum(1):supremum(1)
                for j = infimum(2):supremum(2)
                    matrix(i-infimum(1)+1,j-infimum(2)+1) = get_vector([i,j]);
                end
            end
        elseif(l == 3)
            matrix(supremum(1)- infimum(1) +1, supremum(2)- infimum(2) +1, supremum(3)- infimum(3) +1) = 0;
            for i = infimum(1):supremum(1)
                for j = infimum(2):supremum(2)
                    for k = infimum(3):supremum(3)
                        matrix(i-infimum(1)+1,j-infimum(2)+1,k-infimum(3)+1) = get_vector([i,j,k]);
                    end
                end
            end
        elseif(l == 4)
            matrix(supremum(1)- infimum(1) +1, supremum(2)- infimum(2) +1, supremum(3)- infimum(3) +1, supremum(4)- infimum(4) +1) = 0;
            for i = infimum(1):supremum(1)
                for j = infimum(2):supremum(2)
                    for k = infimum(3):supremum(3)
                        for l = infimum(4):supremum(4)
                            matrix(i-infimum(1)+1,j-infimum(2)+1,k-infimum(3)+1, l-infimum(4)+1) = get_vector([i,j,k,l]);
                        end
                    end
                end
            end  
        end
        
    end

    %inserts a series of data from a matlab matrix starting at an input infimum
    function populate_hash(matrix, infimum)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*        
        
        a = length(infimum);
        b = size(matrix);
        if(a == 1)
            for i = infimum(1):b(1)-infimum(1)+1
                put_vector([i], matrix(i-infimum(1)+1))
            end
        elseif(a == 2)
            for i = infimum(1):b(1)-infimum(1)+1
                for j = infimum(2):b(2)-infimum(2)+1
                    put_vector([i, j], matrix(i-infimum(1)+1, j-infimum(2)+1))
                end
            end
        elseif(a == 3)
            for i = infimum(1):b(1)-infimum(1)+1
                for j = infimum(2):b(2)-infimum(2)+1
                    for k = infimum(3):b(3)-infimum(3)+1
                        put_vector([i, j, k], matrix(i-infimum(1)+1, j-infimum(2)+1,k-infimum(3)+1))
                    end
                end
            end
        elseif(a == 4)
            for i = infimum(1):b(1)-infimum(1)+1
                for j = infimum(2):b(2)-infimum(2)+1
                    for k = infimum(3):b(3)-infimum(3)+1
                        for l = infimum(4):b(4)-infimum(4)+1
                            put_vector([i, j, k, l], matrix(i-infimum(1)+1, j-infimum(2)+1,k-infimum(3)+1, l-infimum(4)+1))
                        end
                    end
                end
            end  
        end
    end
 
  %Increments a value at an input vector
  function inc_vector(vector)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

    if(length(vector) == 1)
        index = find(cell2mat(keys) == vector);
        if isempty(index)
            if isempty(keys)
                keys{1} = vector;
                data{1} = 1;
            else
                keys{end+1} = vector;
                data{end+1} = data{end} + 1;
            end
        else
            data{index} = data{index} + 1;
        end
    else
        index = find(cell2mat(keys) == vector(1));
        if isempty(index)
            if isempty(keys)
                keys{1} = vector(1);
                data{1} = hashimage();
                data{1}.inc(vector(2:end));
            else
                keys{end+1} = vector(1);
                data{end+1} = hashimage();
                data{end}.inc(vector(2:end));
            end
        else
            data{index}.inc(vector(2:end));
        end
    end
  end

end
