% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global library;
global kernallibrary;
global path;
d = pwd;
cd(path);
clear library;
clear kernallibrary;
clear path;
if(isunix)
    rmpath(strcat(d, '/General'));
    rmpath(strcat(d, '/ImageArray'));
    rmpath(strcat(d, '/Images/64x64/English'));
    rmpath(strcat(d, '/Images/64x64/Negative'));
    rmpath(strcat(d, '/Images/64x64/Number'));
    rmpath(strcat(d, '/Images/64x64/Spanish'));
    rmpath(strcat(d, '/Images/Picture'));
    rmpath(strcat(d, '/Images/Pictures/50'));
    rmpath(strcat(d, '/Images/Pictures/1600'));
    rmpath(strcat(d, '/Images/Pictures/2560/A'));
    rmpath(strcat(d, '/Images/Pictures/2560/B'));
    rmpath(strcat(d, '/Images/Pictures/2560/C'));
    rmpath(strcat(d, '/Images/Pictures/2560/D'));
    rmpath(strcat(d, '/Images/Pictures/2560/E'));
    rmpath(strcat(d, '/Images/SmallNegative'));
    rmpath(strcat(d, '/Images/SmallNumber'));
    rmpath(strcat(d, '/Images/testimage2'));
    rmpath(strcat(d, '/Images/testimageG'));
    rmpath(strcat(d, '/Images/testimages'));
    rmpath(strcat(d, '/Mapping'));
    rmpath(strcat(d, '/class'));
elseif(ispc)
    rmpath(strcat(d, '\General'));
    rmpath(strcat(d, '\ImageArray'));
    rmpath(strcat(d, '\Images\64x64\English'));
    rmpath(strcat(d, '\Images\64x64\Negative'));
    rmpath(strcat(d, '\Images\64x64\Number'));
    rmpath(strcat(d, '\Images\64x64\Spanish'));
    rmpath(strcat(d, '\Images\Picture'));
    rmpath(strcat(d, '\Images\Pictures\50'));
    rmpath(strcat(d, '\Images\Pictures\1600\A'));
    rmpath(strcat(d, '\Images\Pictures\2560\B'));
    rmpath(strcat(d, '\Images\Pictures\2560\C'));
    rmpath(strcat(d, '\Images\Pictures\2560\D'));
    rmpath(strcat(d, '\Images\Pictures\2560\E'));
    rmpath(strcat(d, '\Images\SmallNegative'));
    rmpath(strcat(d, '\Images\SmallNumber'));
    rmpath(strcat(d, '\Images\testimage2'));
    rmpath(strcat(d, '\Images\testimageG'));
    rmpath(strcat(d, '\Images\testimages'));
    rmpath(strcat(d, '\Mapping'));
    rmpath(strcat(d, '\class'));
else
    display('Cannot run on this operating system ');
    stop;
end
