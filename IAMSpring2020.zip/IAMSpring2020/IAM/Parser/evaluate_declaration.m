
%% I have separated some functions because the file size was becoming too
%% big. Here is a list of some of the functions.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: evaluate_declaration
%% Inputs: none (The input program string is present in a global
%% variable)
%% Output: None
%% Side Effects: 
%% Description: Parses a declaration
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function evaluate_declaration()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%<rest_of_dec> ::= <variable_dec_list> | array <array_list>| img <img_list>| tpl <tpl_list>

global stack;
global st; % symbol table
global ts; %token stream
type  = ts.spelling();
ts.nextToken();
stack = ntst_push(stack, new_stack_node(nt_new_node('type', ts.spelling())));
if(strcmp(type,'!ML'))

    if(ts.compare('{') == 0)
        disp_error(ts.spelling(), 'Expected: "{"');
    end
    startpos = ts.pos();
    while(ts.compare('}') == 0)
        ts.nextToken();
    end
    input = ts.input();
    data = sprintf('%s',input(startpos : ts.pos()-2));
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', data)));%Push identifier on stack
    node2 = nt_new_node('matlab_sequence', 0);
    buildTree(node2, 1);
    ts.get(';');
elseif(strcmp(type, 'define') && ts.compare('int'))%strcmp(ts.spelling(),'int')==1)
    ts.nextToken();
    if(ts.compare('image') == 0 && ts.compare('tpl') == 0)
        disp_error(ts.spelling(), 'Epected: "image" or "tpl"');
    end

    type = ts.spelling();
    ts.nextToken();
    if(strcmp(type,'tpl')==1)
        if(ts.compare('recursive'))
            type = 'tplrec';
            ts.nextToken();
        end
    end

    if(ts.compare_kind('IDEN') == 0) %strcmp(token.kind, 'IDEN') == 0)
        disp_error(ts.spelling(), 'Expected: IDEN');
    end

    name = nt_new_node('identifier', ts.spelling());%Create note for symbol table
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
    if(st.search(ts.spelling()) ~= 0)            
        disp_error(ts.spelling(), 'Variable already declared');
    end
    ts.get('[');
    count1 = 0;
    while(ts.compare('[') )%strcmp(token.spelling, '['))%Load values into matrix
        ts.nextToken();
        count2 = 0;
        while(ts.compare_kind('NUMLIT') || ts.compare_kind('WEAK_OP') )%strcmp(token.kind, 'NUMLIT') || strcmp(token.kind, 'WEAK_OP'))
            if(ts.compare_kind('WEAK_OP')) %strcmp(token.kind, 'WEAK_OP'))%If negative
                ts.nextToken();
                value = sprintf('-%s',ts.spelling());
            else
                value = sprintf(' %s',ts.spelling());
            end
            stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , value)));%Push integer
            ts.nextToken();
            count2 = count2+1;
        end
        count1 = count1+1;
        buildTree(nt_new_node('identifier', sprintf('Row %d', count1)), count2);%Build row

        if(ts.compare(']') == 0)%strcmp(token.spelling,']') == 0)
            disp_error(ts.spelling(), 'Expected: "]"');
        end
        ts.nextToken();
        if(ts.compare(';') == 0 && ts.compare('(') == 0 && ts.compare('[') == 0 )%strcmp(token.spelling,';') == 0 && strcmp(token.spelling,'(') == 0 && strcmp(token.spelling,'[') == 0)
            disp_error(ts.spelling(), 'Expected: ";" or "(" or "["');
        end

    end%End of loops to add values into matrix
    rq = ntqu_new;%Load range of matrix into symbol table
    rq = ntqu_push(rq, range_new_node(0, count1-1));%Push range 1 on stack for symbol table
    rq = ntqu_push(rq, range_new_node(0, count2-1));%Push range 2 on stack for symbol table
    if(strcmp(type,'tpl')==1 || strcmp(type,'tplrec'))%If its a template, load its coordinates into the symbol table
        if(ts.compare('(') == 0)
            disp_error(ts.spelling(), 'Expected: "("');
        end
        cq = coord_list(ntqu_new, 0);
        tpl = 1;
        node = st_new_PSnode(0, name.value, 'int', type, 0, rq, cq, 'NormalScan', 'Moore');%TPL symbol
    else
        node = st_new_PSnode(0, name.value, 'int', type, 0, rq, 0, 'NormalScan', 'Moore');%Image symbol
        tpl = 0;
    end
    buildTree(nt_new_node('Row_list', 0), count1+tpl);%Build matrix tree
    st.add(node);
    node2 = nt_new_node('matrix_dec', 0);
    buildTree(node2, 2);
    
elseif(strcmp(type, 'int') && (ts.compare('image') || ts.compare('array') ) )
    array_list(type);
    ts.get(';');
elseif(strcmp(type, 'int') && ts.compare('tpl'))
    tpl_list(ntqu_new, type, 0);
    ts.get(';');
elseif(strcmp(type, 'define') && ts.compare('pointset'))
    ts.get_kind('IDEN');
    name = ts.spelling();
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', name)));%Push value on stack
    ts.nextToken();
    
    if(ts.compare('('))
        ts.get_kind('IDEN');
        type = ts.spelling();
        stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , type)));%Push name on stack
        buildTree(nt_new_node('Name', 0), 1);
        ts.get(',');
        ts.get('[');
        rq = range_list(ntqu_new, 0);
        ts.get(',');
        ts.get_kind('IDEN');
        scan = ts.spelling();
        stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , scan)));%Push scan on stack
        buildTree(nt_new_node('Scan', 0), 1);
        ts.get(',');
        ts.get_kind('IDEN');
        connectivity = ts.spelling();
        stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , connectivity)));%Push connectivity on stack
        buildTree(nt_new_node('Connectivity', 0), 1);
        buildTree(nt_new_node('specifications', 0), 4);
        buildTree(nt_new_node('pointset_dec', 0), 2);
        st.add( st_new_PSnode(0, name, type, 'domain', 0, rq, 0, scan, connectivity));
        ts.get(')');
    elseif(ts.compare('{'))
        callExpression()
        if(ts.compare(':') == 0 )
            disp_error(ts.spelling(), 'Expected: ":"');
        end

        ts.get_kind('IDEN');
        stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , ts.spelling())));%Push name on stack
        ts.nextToken();
        if(ts.compare(',') )
            ts.get_kind('IDEN');
            stack = ntst_push(stack, new_stack_node(nt_new_node('identifier' , ts.spelling())));%Push name on stack
            ts.nextToken();
        end
        if(ts.compare('in') == 0)
            disp_error(ts.spelling(), 'Expected: "in"');
        end
        ts.get_kind('IDEN');
        symbol = st.search(ts.spelling());
        if(symbol == 0)
             disp_error(ts.spelling(), 'Pointset not declared');
        end
        buildTree(nt_new_node('identifier', ts.spelling()), 2);
        buildTree(nt_new_node('domain', 0), 1);
        buildTree(nt_new_node('specifications', 0), 2);
        buildTree(nt_new_node('restricted_pointset_dec', 0), 2);
        st.add( st_new_PSnode(0, name, symbol.type, 'domain', symbol.value, symbol.ptr_range, symbol.ptr_coord, symbol.scan, symbol.connectivity));
        ts.get('}');
    else
        disp_error(ts.spelling(), 'Expected: "(", "{"');
    end

    ts.get(';');
elseif(strcmp(type, 'define') && ts.compare('map'))
    ts.get_kind('IDEN');
    name = ts.spelling();
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
    ts.get('{');
    ts.get_kind('IDEN');
    if(st.search(ts.spelling()) == 0)
        disp_error(ts.spelling(), 'Pointset not declared');
    end
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
    ts.get('-');
    ts.get('>');
    ts.get_kind('IDEN');
    if(st.search(ts.spelling()) == 0)
        disp_error(ts.spelling(), 'Pointset not declared');
    end
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
    buildTree(nt_new_node('->', 0), 2);
    ts.get(',');
    ts.get_kind('IDEN');%ts.nextToken();
    func = ts.spelling();
    ts.nextToken();
    if(ts.compare('('))
        ts.get_kind('IDEN');
        stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
        ts.nextToken();
        N = 1;
        while(ts.compare(',') )
            ts.get_kind('IDEN');
            stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
            ts.nextToken();
            N = N + 1;
        end
        if(ts.compare(')') == 0)
            disp_error(ts.spelling(), 'Expected: ")" or ","');
        end
        buildTree(nt_new_node(func, 0), N);
        ts.get('=');
        ts.get('(');
        callExpression();
        if(ts.compare(')') == 0)
            disp_error(ts.spelling(), 'Expected: ")"');
        end
        buildTree(nt_new_node('Domain', 0), 1);
        buildTree(nt_new_node('specifications', 0), 3);
        node = st_new_PSnode(0, name, 'Function', 'map', 0, 0, 0, 0, 0);
        st.add(node);
        ts.get('}');
    elseif(ts.compare('-'))
        ts.get('>');
        ts.get_kind('IDEN');
        stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', func)));%Push identifier on stack
        stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
        
        buildTree(nt_new_node('->', 0), 2); 
        buildTree(nt_new_node('specifications', 0), 1); 
    else
        disp_error(ts.spelling(), 'Expected: "(" or "-"');
    end
    buildTree(nt_new_node('map_dec', 0), 2); 
    ts.get(';');
%elseif(strcmp(type,'map'))
%    
%    name = ts.spelling();
%    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
%    ts.get('{');
%    ts.nextToken();
%    type = ts.spelling();
%    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', type)));%Push identifier on stack
%    node1 = nt_new_node('Type', 0);
%    buildTree(node1, 1); % One extra count for the range
%    
%    if(strcmp(type,'Scale'))
%        ts.get(',');
%        ts.nextToken();
%        value = ts.value();
%        stack = ntst_push(stack, new_stack_node(nt_new_node('numlit', value)));%Push identifier on stack
%        node1 = nt_new_node('Value', 0);
%        buildTree(node1, 1); % One extra count for the range
%        valuecount =1;
%    else
%        value = 0;
%        valuecount =0;
%    end
%    ts.get('}');
%    node1 = nt_new_node('specifications', 0);
%    buildTree(node1, 1+valuecount); % One extra count for the range
%    node = st_new_PSnode(0, name, type, 'map', value, 0, 0, 0, 0);
%    st.add(node);
%    node1 = nt_new_node('old_map_dec', 0);
%    buildTree(node1, 2);
%    ts.get(';');
elseif(strcmp(type, 'define') && ts.compare('valset'))%strcmp(token.spelling,'valset')==1)
    M = 1;
    valueset();
    while(ts.compare(','))%strcmp(token.kind,'COMMA'))
        valueset();
        M = M + 1;
    end
    buildTree(nt_new_node('valset_list', 0), M); 
elseif(strcmp(type, 'define') && ts.compare('variant'))%strcmp(ts.spelling(),'variant')==1)
    ts.get('template');
    ts.get_kind('IDEN');
    name = ts.spelling();
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', name)));%Push identifier on stack
    node = st_new_PSnode(0, name, 'int', 'vartpl', 0, 0, 0, 'NormalScan', 'Moore');
    st.add(node);
    ts.get(':');
    ts.get_kind('IDEN');
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
    ts.get('-');
    ts.get('>');
    ts.get('(');
    ts.get_kind('IDEN');
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
    ts.get('^');
    ts.get_kind('IDEN');
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
    ts.get(')');
    node1 = nt_new_node('^', ts.currentToken());
    buildTree(node1, 2);
    node1 = nt_new_node('->', ts.currentToken());
    buildTree(node1, 2);
    ts.get('s');
    ts.get('.');
    ts.get('t');
    ts.get('.');
    ts.get('{');
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    ts.get_kind('IDEN');
    name = ts.spelling();
    ts.get('(');
    ts.get_kind('IDEN');
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
    ts.get(')');
    ts.get('(');
    ts.get_kind('IDEN');
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
    ts.get(')');
    node1 = nt_new_node(name, 0);
    buildTree(node1,2);
    ts.get('=');
    ts.nextToken();
    %---------------------------------------------------------------------
    M = 2;
    Term();
    node1 = nt_new_node('function', 0);
    buildTree(node1,1);
    while(ts.compare(';'))%strcmp(token.kind,'SEMI'))
        ts.nextToken();
        Term();
        node1 = nt_new_node('function', 0);
        buildTree(node1,1);
        M = M + 1;
    end
    buildTree(nt_new_node('function_list', 0),  M); 
    if(ts.compare(':') == 0)%strcmp(token.spelling,'|')~=1)
        disp_error(ts.spelling(), 'Expected: ":"');
    end
    ts.get_kind('IDEN');
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
    ts.get('in');
    ts.get_kind('IDEN');
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
    node1 = nt_new_node('in', ts.spelling());
    buildTree(node1, 2);
    ts.get(',');
    ts.get_kind('IDEN');
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
    ts.get('in');
    ts.get_kind('IDEN');
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
    node1 = nt_new_node('in', ts.spelling());
    buildTree(node1, 2);
    node1 = nt_new_node('points', ts.spelling());
    buildTree(node1, 2);
    node1 = nt_new_node('specifications', ts.spelling());
    buildTree(node1, 3);
    node1 = nt_new_node('variant_template_dec', ts.spelling());
    buildTree(node1, 2);
    ts.get('}');
    ts.get(';');
else
    count = variable_dec_list(type, 1);
    node1 = nt_new_node('variable_dec_list', ts.spelling());
    buildTree(node1, count);
end

node2 = nt_new_node('var_dec' , 0);
buildTree(node2, 2);

while(ts.compare(';'))
    ts.nextToken();
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%% Function Name: variable_dec_list
%% Inputs: number of current declarations
%% variable)
%% Output: number of final amount of declarations
%% Side Effects: 
%% Description: Parses a list of declarations
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function count = variable_dec_list(type, count)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%<variable_dec_list> ::= <variable_init> | <variable_init>, <variable_dec_list>
global ts;

    variable_init(type);
    if(ts.compare(','))
        ts.nextToken();
        count = variable_dec_list(type, count + 1);
    elseif(ts.compare(';') == 0)
        disp_error(ts.spelling(), 'Expected: "," or ";", or ":="');
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%% Function Name: variable_init
%% Inputs: type of varialbe to be created
%% variable)
%% Output: none
%% Side Effects: 
%% Description: Parses a type of variable
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function variable_init(type)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%<variable_init> ::= <identifier> | <identifier>= <initial_value>
global stack;
global st;
global ts;
if(ts.compare_kind('IDEN') == 0)
    disp_error(ts.spelling(), 'Expected: IDEN');
end   
    name = ts.spelling();
   if(st.search(name) ~= 0)
        disp_error(name, 'Variable already declared');
   end
    node1 = nt_new_node('identifier', name);
    snode1 = new_stack_node(node1);
	stack = ntst_push(stack, snode1); 
    ts.nextToken();
    arraytype = 'nil';
	
    %check if variable has initial value
    
    if(ts.compare(':='))
       ts.nextToken();
       %check if its an initial value
       if(strcmp(type,'complex')==1 && ts.compare('('))
           ts.nextToken();
           value = ts.value();
           if(ts.compare('-'))
                ts.nextToken();
                value = -ts.value();
           end
           node2 = nt_new_node('numlit' , value);
           snode2 = new_stack_node(node2);
           stack = ntst_push(stack, snode2);
           cq = ntqu_new;
           cnode = coord_new_node(value);
           cq = ntqu_push(cq, cnode);
           ts.get(',');
           ts.nextToken();
           if(ts.compare('-'))
               ts.nextToken(); 
               value = -ts.value();
           else
               value = ts.value();
           end
           node2 = nt_new_node('numlit' , value);
           snode2 = new_stack_node(node2);
           stack = ntst_push(stack, snode2);
           cnode = coord_new_node(value);
           cq = ntqu_push(cq, cnode);
           

            
           node = st_new_node(0, name, type, 'nil', 0, 0, cq);
           st.add(node);
           node2 = nt_new_node('var_init',0); 
           buildTree(node2, 3);
           ts.get(')');
           ts.nextToken();
       elseif(ts.compare('-') || ts.compare_kind('NUMLIT') || ts.compare('('))
           if(ts.compare('-') )
               ts.nextToken();
               value= -ts.value();
           else
               value = ts.value();
           end
           node2 = nt_new_node('numlit' ,value);
           snode2 = new_stack_node(node2);
	       stack = ntst_push(stack, snode2);
	       node3 = nt_new_node('var_init',0); 
            if(st.search(name) ~= 0)
                disp_error(name, 'Variable already declared');
            end
            
            st_node = st_new_node(0, name, type, 'nil', value, 0, 0);
            st.add(st_node);
	        buildTree(node3, 2);
            ts.nextToken();
       else
            disp_error(ts.spelling(), 'Expected: NUMLIT, WEAK OP or "("');
       end  
    else
        if(st.search(name) ~= 0)
            disp_error(name, 'Variable already declared');               
        end
        st_node = st_new_node(0, name, type, arraytype, 0, 0, 0);
        st.add(st_node);

        node3 = nt_new_node('var_init',0); 
        buildTree(node3, 1);
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%% Function Name: template_dec_list
%% Inputs: number of current declarations
%% variable)
%% Output: number of final amount of declarations
%% Side Effects: 
%% Description: Parses a list of template declarations
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function nq = tpl_list(nq, type, count)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global stack;
global st;
global ts;

    ts.get_kind('IDEN');
    count = count + 1;
    node1 = nt_new_node('identifier', ts.spelling());
    snode1 = new_stack_node(node1);
    stack = ntst_push(stack, snode1);

    if(st.search(ts.spelling()) ~= 0)            
        disp_error(ts.spelling(), 'Variable already declared');
    end

    node = nameq_new_node(ts.spelling());
    nq = ntqu_push(nq, node);
    ts.nextToken();
    if(ts.compare(','))
         nq = tpl_list(nq, type, count);
    elseif(ts.compare('[') == 0)%strcmp(token.spelling, '[') == 0)
        disp_error(token.spelling, 'Expected: "["');
    else
        tpl_range_list(ntqu_new, nq, type, 'tpl', 0);
        node1 = nt_new_node('tpl_list', ts.spelling());
        buildTree(node1, count+1); % One extra count for the range
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%% Function Name: tpl_range_list
%% Output: an object that contains the completed range queue
%% Side Effects: 
%% Description: Parses the range of a list of templates
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function rq = tpl_range_list(rq, nq, type, array_type, count)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global ts;

        rq = range(rq);
        count = count + 1;
        node1 = nt_new_node('Range',0);
        buildTree(node1,2);
        ts.nextToken();
        if(ts.compare(','))
            rq = tpl_range_list(rq, nq, type, array_type, count);
        elseif(ts.compare(';'))
            ts.get('(');
            cq = coord_list(ntqu_new, 0);
            ts.spelling()
            
            if(ts.compare(']') == 0)

                disp_error(token.spelling, 'Expected: "]"');
            end
            
            node1= nt_new_node('Range_List',0);
            buildTree(node1, count + 1); % one for coord
            name_node = nq.firstElement;
            for i=1:nq.noElements
                node = st_new_PSnode(0, name_node.name, type, array_type, 0, rq, cq, 'NormalScan', 'Moore');

                st.add(node);
                name_node = name_node.next;
            end            
        else
            disp_error(token.spelling, 'Expected: "," or ";"');
        end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%% Function Name:  coord_list
%% Inputs: number of current coordinate declarations and the count
%% variable)
%% Output: number of final amount of coordinate declarations
%% Side Effects: 
%% Description: Parses a list of coordinate declarations
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function cq = coord_list(cq, count)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global stack;
global ts;
    ts.nextToken();

    if(ts.compare_kind('NUMLIT') == 0 && ts.compare('-') == 0)
        disp_error(ts.spelling(), 'Expected: numlit or "-"');
    end
    if(ts.compare('-'))
        ts.nextToken();
        value = -ts.value();
    else
        value = ts.value();
    end
    node1 = nt_new_node('numlit' , value);
    snode1 = new_stack_node(node1);
    stack = ntst_push(stack,snode1);
    count = count + 1;
    cnode = coord_new_node(value);
    cq = ntqu_push(cq, cnode);
    ts.nextToken();
    if(ts.compare(','))
        cq = coord_list(cq, count);
    elseif(ts.compare(')'))
        ts.nextToken();
        node1 = nt_new_node('coord_list',0);
        buildTree(node1, count);
     else
         disp_error(ts.spelling(), 'Expected: "," or ")"');
     end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%% Function Name:  array_list
%% Inputs: type of array declaration
%% variable)
%% Output: none
%% Side Effects: 
%% Description: Parses a list of array declarations
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

function array_list(type)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global stack;
global st;
global ts;

    
    

nq = array_dec(ntqu_new);
    count = nq.noElements+1;
    if(ts.compare('['))

        rq = range_list(ntqu_new, 0);
        name_node = nq.firstElement;
        for i=1:nq.noElements

            node = st_new_PSnode(0, name_node.name, type, 'image', 0, rq, 0, 'NormalScan', 'Moore');
            st.add(node);
            name_node = name_node.next;
        end 
    elseif(ts.compare('on') || ts.compare('in'))
        if(ts.compare('in'))
            hasvalset = 1;
            ts.nextToken();
            if(st.search(ts.spelling()) == 0)            
                disp_error(ts.spelling(), 'Valueset not declared' );
            end
            tempNode = new_stack_node(nt_new_node('identifier' , ts.spelling()));
            ts.nextToken();
            if(ts.compare('^') == 0 && ts.compare('on') )
                disp_error(ts.spelling(), 'Expected ^ or on');
            end
        else
            hasvalset = 0;
        end
        ts.nextToken();
        symbol = st.search(ts.spelling());
        if(symbol == 0)            
            disp_error(ts.spelling(), 'Domain not declared');
        end
        
        
        name_node = nq.firstElement;
        for i=1:nq.noElements
            node = st_new_PSnode(0, name_node.name, type, 'image', 0, symbol.ptr_range, 0, symbol.scan, symbol.connectivity);
            st.add(node);
            name_node = name_node.next;
        end            

        nodeR = symbol.ptr_range.firstElement;
        for i=1:symbol.ptr_range.noElements
            if(st.search(nodeR.start_range) == 0)
                node1 = nt_new_node('numlit' , nodeR.start_range);  
            else
                node1 = nt_new_node('identifier' , nodeR.start_range);
            end
            snode1 = new_stack_node(node1);
            stack = ntst_push(stack,snode1);
            
            if(st.search(nodeR.end_range) == 0)
                node1 = nt_new_node('numlit' , nodeR.end_range);  
            else
                node1 = nt_new_node('identifier' , nodeR.end_range);
            end
            snode1 = new_stack_node(node1);
            stack = ntst_push(stack,snode1);

            node1= nt_new_node('Range',0);
            buildTree(node1, 2);
             
            nodeR = nodeR.next;
        end
        buildTree(nt_new_node('Range_List',0), symbol.ptr_range.noElements);
        if(hasvalset)
            stack = ntst_push(stack,tempNode);
            node1= nt_new_node('ValSet',0);
            buildTree(node1, 1);
        end
        
    else
        disp_error(ts.spelling(), 'Expected: "[", "on" or "in"');
    end
    buildTree(nt_new_node('img_list', 0), count);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%% Function Name:  array_dec
%% Inputs: current list array declarations
%% variable)
%% Output: final list array declarations
%% Side Effects: 
%% Description: Parses an array
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function nq = array_dec(nq)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global stack;
global ts;
global st;

    %ts.nextToken();
    %if(ts.compare_kind('IDEN') == 0)
    %    disp_error(ts.spelling(), 'Expected: IDEN');
    %end
    ts.get_kind('IDEN');
    if(st.search(ts.spelling()) ~= 0)   
        disp_error(ts.spelling(), 'Variable already declared');
    end
    
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));

    node = nameq_new_node(ts.spelling());
    nq = ntqu_push(nq, node);

    ts.nextToken();
    if(ts.compare(','))
        %ts.nextToken();
        nq = array_dec(nq);
    elseif(ts.compare('[') == 0 && ts.compare('on') == 0 && ts.compare('in') == 0 )
        disp_error(ts.spelling(), 'Expected: ",", "[", "on, or "in"');
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%% Function Name:  range_list
%% Inputs: number of current range declarations and the count
%% variable)
%% Output: number of final amount of range declarations
%% Side Effects: 
%% Description: Parses a list of range declarations
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function rq = range_list(rq, count)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ts;
    rq = range(rq);
    node1 = nt_new_node('Range',0);
    buildTree(node1,2);
    ts.nextToken();
    if(ts.compare(','))
        rq = range_list(rq, count + 1);
    elseif(ts.compare(']'))
        node1= nt_new_node('Range_List',0);
        buildTree(node1, count+1);
    else
        disp_error(ts.spelling(), 'Expected: "," or "]"');
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%% Function Name:  valueset
%% Inputs: none
%% variable)
%% Output: none
%% Side Effects: 
%% Description: Parses a value set.  Currently, there is not use for
%% value sets but may have use in the future
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function valueset()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global stack;
global st;
global ts;
    N = 2;
    ts.nextToken();
    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
    
    node = st_new_PSnode(0, ts.spelling(), 'int', 'valset', 0, 0, 0, 0, 0);
    st.add(node);
    ts.get('=');
    ts.nextToken();
    if(ts.compare('{'))
        ts.get_kind('NUMLIT');
        stack = ntst_push(stack, new_stack_node(nt_new_node('numlit', ts.value())));%Push numlit on stack
        ts.nextToken();
        while(ts.compare(','))
            ts.get_kind('NUMLIT');
            stack = ntst_push(stack, new_stack_node(nt_new_node('numlit', token.value)));%Push numlit on stack
            N = N + 1 ;
            token=nextToken(input);
            ts.nextToken();
        end

        if(ts.compare('}'))
            disp_error(token.spelling, 'Expected: "}"');
        end
        ts.nextToken();
    elseif(ts.compare('Z_mod'))
        ts.get_kind('NUMLIT');
        stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', 'Z_mod')));
        stack = ntst_push(stack, new_stack_node(nt_new_node('numlit', ts.value())));%Push numlit on stack
        N = 3;
        ts.nextToken();
    else
        disp_error(ts.spelling(), 'Expected: "{" or "Z_mod"');
    end
    buildTree(nt_new_node('valset', 0), N);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%% Function Name:  range
%% Inputs: current range list
%% variable)
%% Output: final range list
%% Side Effects: 
%% Description: Parses a binary range set
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

function rq = range(rq)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ts;
    value1 =rangeValue();
    ts.get(':');
    value2 =rangeValue();
    node = range_new_node(value1, value2);
    rq = ntqu_push(rq, node);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%% Function Name:  range
%% Inputs: none
%% variable)
%% Output: a value for each side of a range set
%% Side Effects: 
%% Description: This function returns the value of a set from a range
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

function value =rangeValue()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global stack;
global ts;
global st;
sign = 0;
    ts.nextToken();
    if(ts.compare('-'))
        ts.nextToken();
        sign = 1;
    end
    
    if(ts.compare_kind('IDEN'))
        if(st.search(ts.spelling()) == 0)
            disp_error(ts.spelling(), 'Variable not declared');
        end
        if(sign == 0)
            node1 = nt_new_node('identifier' ,ts.spelling());
            value = ts.spelling();
        else
            node1 = nt_new_node('identifier' , sprintf('-%s',ts.spelling()));
            value = sprintf('-%s',ts.spelling());
        end
        snode1 = new_stack_node(node1);
        stack = ntst_push(stack, snode1);

    elseif(ts.compare_kind('NUMLIT'))
        if(sign == 0)
            node1 = nt_new_node('numlit' ,ts.value());
            value = ts.value();
        else
            node1 = nt_new_node('numlit' ,-ts.value());
            value = -ts.value();
        end
        snode1 = new_stack_node(node1);
        stack = ntst_push(stack, snode1);
    else
        disp_error(ts.spelling(), 'Expected: IDEN or NUMLIT');
    end
    
%function templatefunction() %Idea for variant templates.  Does not work.....yet
%global stack;
%global ts;
%    ts.get_kind('IDEN');
%    name = ts.spelling();
%    ts.get('(');
%    ts.get_kind('IDEN');
%    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
%    ts.get(')');
%    ts.get('(');
%    ts.get_kind('IDEN');
%    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
%    ts.get(')');
%    node1 = nt_new_node(name, 0);
%    buildTree(node1,2);
%    ts.get('=');
%    ts.nextToken();
%    Term();
%    node1 = nt_new_node('function', 0);
%    buildTree(node1,2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%% Function Name:  callExpression
%% Inputs: none
%% variable)
%% Output: a boolean 1 or 0
%% Side Effects: 
%% Description: This function is the head function for an expression
%% Each function below is called from this function
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
function ret=callExpression()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ts;
    ts.nextToken();
    ret = Term();
    node1 = nt_new_node('Expression', 0);
    buildTree(node1,1);

function ret=Term()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ts;
    ret = Equation();
    if(ts.compare(','))
        N = 1;
        while(ts.compare(','))
            ts.nextToken();
            ret = Equation();
            N = N + 1;
        end
        node1 = nt_new_node('vector',0);
        buildTree(node1, N); % expr op expr
    end
    
function ret=Equation()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ts;
    ret = Compare();
    while(ts.compare('&') || ts.compare('|'))
        name = ts.spelling();
        ts.nextToken();
        ret = Compare();
        buildTree(nt_new_node(name,0), 2); % expr op expr
    end
    
function ret=Compare()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ts;
    ret = Factor();
    if(ts.compare('=') || ts.compare('<') || ts.compare('>') || ts.compare('<=') || ts.compare('>=') )
        name = ts.spelling();
        ts.nextToken();
        ret = Factor();
        buildTree(nt_new_node(name,0), 2); % expr op expr
    end
    
function ret=Factor()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ts;
    ret = Secondary();
    while(ts.compare('+') || ts.compare('-'))
        name = ts.spelling();
        ts.nextToken();
        ret = Secondary();
        buildTree(nt_new_node(name,0), 2); % expr op expr
    end

function ret=Secondary()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ts;

    ret = Ternary();
    while(ts.compare('*') || ts.compare('/'))
        name = ts.spelling();
        ts.nextToken();
        ret = Ternary();
        buildTree(nt_new_node(name,0), 2);
    end

function ret=Ternary()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ts;

    ret = Primary();
    while(ts.compare('^'))
        name = ts.spelling();
        ts.nextToken();
        ret = Primary();
        buildTree(nt_new_node(name,0), 2);
    end

function ret=Primary()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global stack;
global ts;
    ret = 1;
    if(ts.compare('-'))
        name = ts.spelling();
        ts.nextToken();
        Primary();
        buildTree(nt_new_node(name,0), 1); 
    elseif(ts.compare('+'))
        ts.nextToken();
        Primary();
    elseif(ts.compare('('))
        ts.nextToken();
        Term();
        if(ts.compare(')'))
            disp_error(ts.spelling(), 'Expected: ")"');
        end
        ts.nextToken();
    elseif(ts.compare_kind('NUMLIT'))
        node1 = nt_new_node('numlit', ts.value());
        snode1 = new_stack_node(node1);
        stack = ntst_push(stack, snode1);
        ts.nextToken();
    elseif(ts.compare('cos') || ts.compare('sin'))
        type = ts.spelling();
        ts.get('(');
        ts.nextToken();
        Term();
        if(ts.compare(')') == 0)
            disp_error(ts.spelling(), 'Epected: ")"');
        end
        ts.nextToken();
        buildTree(nt_new_node(type, 0), 1);
    elseif(ts.compare_kind('IDEN'))
        
        spelling = ts.spelling();
        if(length(spelling) > 2 && strcmp(spelling(1:2), 'p_'))
            
            value = spelling(3:end);
            for i = 1:length(value)
                if(int8(value(i))>57 || int8(value(i))<48)
                    disp_error(spelling, 'Point must have a numeric value to define the dimension');
                end
            end
            ts.get('(');
            ts.get_kind('IDEN');
            stack = ntst_push(stack, new_stack_node(nt_new_node('numlit', str2double(value))));%Push identifier on stack
            stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));%Push identifier on stack
            ts.get(')');
            buildTree(nt_new_node('DIM', 0), 2);
        else
            node1 = nt_new_node('identifier', ts.spelling());
            snode1 = new_stack_node(node1);
            stack = ntst_push(stack, snode1);
        end
        ts.nextToken();

    else
        disp_error(ts.spelling(), 'Unknown Operation"');
    end
    
