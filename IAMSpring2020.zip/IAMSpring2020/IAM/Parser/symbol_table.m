
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: symbol_table
%% Inputs: none
%% Output: a MATLAB struct
%% Side Effects:
%% Description: This function builds an object that keeps track of all variables
%% inside the Image Algebra p-Code.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function listObject = symbol_table() 
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

 %global values;
  %values = reshape({},1,{}); 
  data = reshape({},1,{}); 
  listObject = struct('display',@display_list,...
                      'list',@get_list,...
                      'search',@search_list,...
                      'index',@get_index,...
                      'remove',@remove_node,...
                      'replace',@replace_node,...
                      'get',@get_node,...
                      'addAfter',@add_element,...
                      'size',@get_size,...
                      'add',@add_to_end,...
                      'delete',@delete_element); 
 
  function output = display_list
      % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
      
    output = 'Symbol table is :';
    output = strcat(output, '\n');
    for i=1:length(data)
       symbol = data{i};
       output = strcat(output,sprintf('Element no %d: Name: %s, Type: %s',i,symbol.name, symbol.type));

       if(symbol.arrayType ~= 0)
           output = strcat(output,sprintf(', ArrayType: %s', symbol.arrayType));
       end

       if(symbol.value == 0)
           output = strcat(output,sprintf(', Value: nil'));
       else
           output = strcat(output,sprintf(', Value: %d',symbol.value));
       end
       if(symbol.ptr_range ~= 0) % Is there a range..
           output = strcat(output, sprintf(',\n\tArray Range is : ('));
           nodeR = symbol.ptr_range.firstElement;
           for j=1:symbol.ptr_range.noElements

               if(search_list(nodeR.start_range) == 0)
                   output = strcat(output, sprintf('%d', nodeR.start_range));   
               else
                   output = strcat(output, sprintf('%s', nodeR.start_range));   
               end
               output = strcat(output, ' :');
               if(search_list(nodeR.end_range) == 0)
                   output = strcat(output, sprintf(' %d,', nodeR.end_range));   
               else
                   output = strcat(output, sprintf(' %s,', nodeR.end_range));   
               end

               nodeR = nodeR.next;
           end
           output = output(1 : length(output)-1);
           output = strcat(output, ')');
       end

       if(symbol.ptr_coord ~= 0) % Is there a coord
           output = strcat(output, sprintf(', Coordinate : ('));
           nodeR = symbol.ptr_coord.firstElement;
           for j=1:symbol.ptr_coord.noElements
               output = strcat(output, sprintf('%d, ', nodeR.coord));
               nodeR = nodeR.next;
           end
           output = output(1 : length(output)-1);
           output = strcat(output, ')');
       end

       if(symbol.scan ~= 0) % Is there a coord
           output = strcat(output, sprintf(', Scan: %s', symbol.scan));
       end
       if(symbol.scan ~= 0) % Is there a coord
           output = strcat(output, sprintf(', Connectivity: %s', symbol.connectivity));
       end

       output = strcat(output, '\n');
    end
    output = sprintf(output);
  end

  function list = get_list
      % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
      
      list = data;
  end

  function node = search_list(name)
      % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
      
      node = 0;
      for i = 1:length(data)
          symbol = data{i};
          if(strcmp(symbol.name,name))
              node = symbol;
              break;
          end
      end
  end


  function replace_node(name, node)
      % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
      
      if(name ~= 0)
          for i = 1:length(data)
              value = data{i};
              if(strcmp(value.name,name))
                  data{i} = node;
                  %values{i} = node.value;
                  return;
              end
          end
          add_to_end(node);
      end
  end

  function remove_node(name)
      % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
      
      for i = 1:length(data)
          value = data{i};
          if(strcmp(value.name,name))
              delete_element(i);
              break;
          end
      end
  end

  function data_size =  get_size() 
      % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
      
    data_size = length(data);
  end 
 
  function add_element(symbol,index)
      % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
      
    index = min(index,numel(data)); 
    %values = {values{1:index} reshape(symbol.value,1,{}) values{index+1:end}}; 
    data = {data{1:index} reshape(symbol,1,{}) data{index+1:end}}; 
  end 

   function node = get_node(index)
       % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
       
      node = data{index};
   end

  function add_to_end(symbol)
      % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
      
    add_element(symbol,numel(data));
  end 
 
  function delete_element(index) 
      % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
      
    %values = {values{1:index-1} values{index+1:end} }; 
    data = {data{1:index-1} data{index+1:end} }; 
  end

  function index = get_index(name)
      % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
      
      index = 0;
      for i = 1:length(data)
          symbol = data{i};
          if(strcmp(symbol.name,name))
              index = i;
              break;
          end
      end
  end
 
end