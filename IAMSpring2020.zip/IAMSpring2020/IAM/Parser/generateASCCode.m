
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: generateASCcode
%% Inputs: fileName: Name of the .obj file to be generated
%%         AST : The abstract syntax tree constructed from the parser
%% Output: None
%% Description:
%% This function generates the ASC code from the abstract syntax tree generated from the Image Algebra code.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [] = generateASCCode()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global output;
global AST;
    output = (' ' );
    %% If the Node is of the type program 
    
    reservePQSR();
    
    if(strcmp(AST.type, 'program') || strcmp(AST.type, 'function'))
        node = AST.firstChild;
        for i=1:AST.noChildren
            if(strcmp(node.type ,'All_Var_Dec') || strcmp(node.type ,'All_Parms'))%% Generate ASC code for the variable declarations
                printAllVarDec(node);
            elseif(strcmp(node.type ,'Command_Sequence'))%% Generate ASC code for the expression commands.
                output = strcat(output, '\n');
                printCommandSequence(node);
            end
            node = node.sibling;
        end
    end
  file = fopen('generatedCode.asc','w');
  fprintf(file,sprintf(output));
  fclose(file);
  sprintf(output)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printAllVarDec
%% Inputs: AST : The AST whose variable declarations are to be evaluated.
%% Output: None
%% Description:
%% This function generate ASC for a variable declaration types (i.e.
%% image, template or variable)
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
 function [] = printAllVarDec(AST)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

 global output;
 global st;
    node = AST.firstChild;
    for i=1:AST.noChildren
        node1 = node.firstChild;
        if(strcmp(node1.type,'type'))
            node1 = node1.sibling;
            if(strcmp(node1.sibling.type,'array_list'))
                %node1 = node.sibling;
                %printArrayList(node);
            elseif(strcmp(node1.type,'img_list') || strcmp(node1.type,'tpl_list') || strcmp(node1.type,'matrix_dec'))
                imagenode = node1.firstChild;
                for j=1:(node1.noChildren -1)
                    var = st.search(imagenode.value);
                    if(var ~= 0)
                        output = strcat(output, sprintf('%sXDCLX(', getArrayValue(var.arrayType)));
                        writeValues(var);
                        output = strcat(output, '-1,-1,-1,-1,-1,-1,-1,d2m,16);\n');
                        imagenode = imagenode.sibling;
                    end
                end
            elseif(strcmp(node1.type,'pointset_dec') == 0)
                firstChild = 0;
                varnode = node1.firstChild;
                for j=1:node1.noChildren
                    if((strcmp(varnode.type,'var_init') == 1) && (varnode.noChildren == 2) )
                        if(firstChild == 0)
                             firstChild =1;
                             output = strcat(output, sprintf ('MOCSET'));
                        else
                             output = strcat(output , sprintf(' ,' ));
                        end
                        idenNode = varnode.firstChild;
                        identifier = idenNode.value;
                        output = strcat(output, sprintf (' %s ', identifier));
                        if(varnode.noChildren == 2)
                            nodeInit = idenNode.sibling;
                            if((strcmp(nodeInit.type,'numlit') == 1) || (strcmp(nodeInit.type,'boollit') == 1))
                                output = strcat(output , sprintf(' = %d ' , nodeInit.value));
                            else
                                output = strcat(output , sprintf(' = %s ' , nodeInit.value));
                            end 
                        else

                        end
                    
                    end
                    varnode = varnode.sibling;
                end
                output = strcat(output, ' \n ');
                
            end
        end
        node = node.sibling;
    end
 return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: printCommandSequence
%% Inputs: AST : The abstract syntax tree constructed from the parser
%% Output: None
%% Description:
%% This function generates the ASC for the command sequences.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 function [] = printCommandSequence(AST)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*     
     
 global output; 
 global st;
 global tempCount;
 
    node = AST.firstChild;
    for i=1:AST.noChildren
        if(strcmp(node.type , 'procedure') == 1)
            evaluateProcedure(node);    
        elseif(strcmp(node.type , 'assign') == 1)
            LHS = node.firstChild;
            RHS = node.firstChild.sibling;
            tempCount = 0;

            var = evaluateExpression(RHS.firstChild);

            if(var ~= 0)
                if(LHS.noChildren == 0)
                    LHS = st.search(LHS.value);
                    if(LHS ~= 0)
                        output = strcat(output, sprintf( '%s%sASNX(',getArrayValue(var.arrayType),getArrayValue(var.arrayType)));
                        writeValues(st_new_node(0, LHS.name, var.type, var.arrayType, var.value, var.ptr_range, var.ptr_coord));
                    else
                        display('ERROR in the LHS search ');
                    end
                else  
                    display('Multiple Assignments on the Left... handled later ');
                end
                writeValues(var);
                output = strcat( output, '-1,-1,m2m,16);\n\n'); 
                for j=0:tempCount-1
                    value = sprintf('tmp%d',j);
                    st.remove(value);
                end
            end
          %% To generate ASC for the if statements  
         elseif(strcmp(node.type , 'if_statement') == 1)
             expr = node.firstChild;
             output= strcat(output, 'if(');
             statement = node.firstChild.sibling;

             if(strcmp(expr.type, 'expression'))
                 evaluateCondition(expr.firstChild);
             end
             output= strcat(output, ') \n');
             if(strcmp(statement.type, 'Command_Sequence'))
                 printCommandSequence(statement);
             end
             if(node.noChildren == 3)
                elsepart = node.firstChild.sibling.sibling;
                elsenode = elsepart.firstChild;
                for j=1:elsepart.noChildren

                    if(strcmp(elsenode.type , 'else_if'))
                        expr = elsenode.firstChild;
                        statement = elsenode.firstChild.sibling;
                        output= strcat(output, 'elseif(');
                        if(strcmp(expr.type, 'expression'))
                            evaluateCondition(expr.firstChild);
                        end
                        output= strcat(output, ') \n');
                    else
                        statement = elsenode.firstChild;
                        output= strcat(output, 'else\n');
                    end
                    if(strcmp(statement.type, 'Command_Sequence'))
                        printCommandSequence(statement);
                    end
                    elsenode = elsenode.sibling;
                end
             end
             output =  strcat(output, 'end');
             output= strcat(output, '\n');
         %% Generate the ASC for the for statement,
         elseif(strcmp(node.type , 'for_statement') == 1)
            output= strcat(output, '{ \n');
            expr = node.firstChild;
            range = ' ';
            if(strcmp(expr.type, 'Range') ==1)

                if(expr.noChildren == 3)
                    range1 = expr.firstChild.sibling; 
                    range2 = range1.sibling;
                    
                    if(strcmp(range2.type ,'identifier'))
                        range = strcat(range, sprintf(' %s ',range2.value));
                    else
                        range = strcat(range, sprintf(' %d ',range2.value));
                    end

                    range = strcat(range, ' - ');

                    if(strcmp(range1.type , 'identifier'))
                        range = strcat(range, sprintf(' %s ',range1.value));
                    else
                        range = strcat(range, sprintf(' %d ',range1.value));
                    end
                end         
            end
            statement = expr.sibling;

            if(strcmp(statement.type, 'Command_Sequence') ==1)
                printCommandSequence(statement);
            end

            output =  strcat(output, '}*');    
            output = strcat(output, sprintf(' %s + 1',range));
            output= strcat(output, '\n');     
        end
        node = node.sibling;
    end
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: evaluateCondition
%% Inputs: exprNode : The expression node whose MATLAB code is to be generated
%% Output: None
%% Description:
%% This function generates the MATLAB for the given expression operation.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [] = evaluateCondition(node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    
    
global output;
global st;
 if(strcmp(node.type, 'identifier'))
    var= st.search(node.value);
    if(var == 0)
        display(sprintf('ERROR: %s is not declared',  node.value));
    end
    
    if(node.noChildren > 0)
        range = var.ptr_range.firstElement;
        output = strcat(output, sprintf('%s.get(', node.value));
        dimension = node.firstChild;
        if(strcmp(dimension.type, 'identifier'))
            output = strcat(output, sprintf('[ %s', dimension.value));
        else
            output = strcat(output, sprintf('[ %d', dimension.value));
        end
        range = range.next;
        dimension = dimension.sibling;
        for i = 1:node.noChildren-1
            if(strcmp(dimension.type, 'identifier'))
                output = strcat(output, sprintf(', %s', dimension.value));
            else
                output = strcat(output, sprintf(', %d', dimension.value));
            end
            range = range.next;
            dimension = dimension.sibling;
        end
        output = strcat(output,' ])');
    else
        output = strcat(output, sprintf('%s',node.value));
    end
 elseif(strcmp(node.type, 'numlit'))
    output = strcat(output, sprintf('%d',node.value));
 elseif(strcmp(node.type, '()') == 1)
    output = strcat(output, '(');
    evaluateCondition(node.firstChild);
    output = strcat(output, ')');
 else
    if(node.noChildren > 1)
        evaluateCondition(node.firstChild);
        output = strcat(output, sprintf('%s', node.type));
        evaluateCondition(node.firstChild.sibling);
    else
        output = strcat(output, sprintf('%s', node.type));
        evaluateCondition(node.firstChild);
    end
 end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: evaluateExpression
%% Inputs: exprNode : The compound expression node whose ASC is to be generated
%% Output: None
%% Description:
%% This function generates the ASC for the given compound expression operation.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 function [var] = evaluateExpression(node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*     
     
 global output;
 global st;
 global tempCount;
 forwardslash = 92;
 
if(strcmp(node.type, 'identifier') || strcmp(node.type, 'numlit'))
    var = st.search(node.value);
    if(var == 0)
         var = st_new_node(0, node.value, 'int', 0, 0, 0, 0);
    end
elseif(strcmp(node.type, '()') == 1 || strcmp(node.type,'!stat') || strcmp(node.type,'!gray')|| strcmp(node.type,'!slice'))
    var = evaluateExpression(node.firstChild);
else
    value1 = evaluateExpression(node.firstChild);

    if(node.noChildren > 1)
        value2 = evaluateExpression(node.firstChild.sibling);
        output = strcat(output,  sprintf('%s%s', getArrayValue(value1.arrayType),getArrayValue(value2.arrayType)));
    else
        value2 = 0;
        output = strcat(output,  sprintf('%s', getArrayValue(value1.arrayType)));
    end
    %Generate a temp value
    temp = sprintf('tmp%d', tempCount);
    tempCount = tempCount + 1;
    if(value2 == 0 || strcmp(value1.arrayType, 'image') == 1 || strcmp(value2.arrayType, 'image') == 0)
        var = st_new_node(0, temp, value1.type, value1.arrayType, value1.value, value1.ptr_range, value1.ptr_coord);
    else
        var = st_new_node(0, temp, value2.type, value2.arrayType, value2.value, value2.ptr_range, value2.ptr_coord);
    end
    st.add(var);
    %Evaluate the nodes properties
    if(strcmp(node.type, '+'))
        output = strcat(output, 'ADDX(');ops = '-1,-1,+,16';
    elseif(strcmp(node.type, '-') && node.noChildren == 2)
        output = strcat(output, 'SUBX(');ops = '-1,-1,-,16';
    elseif(strcmp(node.type, '*'))
        output = strcat(output, 'MULX(');ops = '-1,-1,x,16';
    elseif(strcmp(node.type, '/'))
        output = strcat(output, 'DIVX(');ops = '-1,-1,/,16';
    elseif(strcmp(node.type, '!restrict') || strcmp(node.type, '|_'))
        output = strcat(output, 'RSTX(');ops = '-1,-1,I/O,16';
    elseif(strcmp(node.type, '!extend') || strcmp(node.type, '|^'))
        output = strcat(output, 'EXDX(');ops = '-1,-1,I/O,16';
    elseif(strcmp(node.type, '!union'))
        output = strcat(output, 'UNIX(');ops = '-1,-1,union,16';
    elseif(strcmp(node.type, '!intsct'))
        output = strcat(output, 'INPX(');ops = '-1,-1,intersect,16';
    elseif(strcmp(node.type, forwardslash))
        output = strcat(output, 'SSBX(');ops = '-1,-1,setsub,16';
    elseif( strcmp(node.type, '(+)') || strcmp(node.type,'!gcon'))
        output = strcat(output, 'GCNX(');ops = '+,16,x,16';
    elseif(strcmp(node.type, '[^]') || strcmp(node.type,'!amax'))
        output = strcat(output, 'AMXX(');ops = '+,16,^,16';
    elseif(strcmp(node.type, '[v]') || strcmp(node.type,'!amin'))
        output = strcat(output, 'AMNX(');ops = '+,16,v,16';
    elseif(strcmp(node.type, '(^)')|| strcmp(node.type,'!mmax'))
        output = strcat(output, 'MMNX(');ops = 'x,16,^,16';
    elseif(strcmp(node.type, '(v)')|| strcmp(node.type,'!mmin'))
        output = strcat(output, 'MMXX(');ops = 'x,16,v,16';
    elseif(strcmp(node.type,'!sum'))
        output = strcat(output, 'XSUMX(');ops = '-1,-1,+,16';var.arrayType = 0;
    elseif(strcmp(node.type,'!prod'))
        output = strcat(output, 'XPRDX(');ops = '-1,-1,x,16';var.arrayType = 0;
    elseif(strcmp(node.type,'!max'))
        output = strcat(output, 'XMAXX(');ops = '-1,-1,^,16';var.arrayType = 0;
    elseif(strcmp(node.type,'!min'))
        output = strcat(output, 'XMINX(');ops = '-1,-1,v,16';var.arrayType = 0;
    elseif(strcmp(node.type,'!mean'))
        output = strcat(output, 'XAVGX(');ops = '-1,-1,m,16';var.arrayType = 0;
    elseif(strcmp(node.type,'!stdev'))
        output = strcat(output, 'XSTDX(');ops = '-1,-1,s,16';var.arrayType = 0;
    elseif(strcmp(node.type, '-'))
        output = strcat(output, 'XNEGX(');ops = '-1,-1,-,16';
    elseif(strcmp(node.type,'chi'))
        output = strcat(output, 'CHIX(');ops = sprintf('-1,-1,%s,16,', node.firstChild.sibling.sibling.value);
    else
        output = strcat(output, 'ERROR(');ops = '-1,-1,-1, 16,';
    end
    writeValues(value1);
    writeValues(value2);
    output = strcat(output, sprintf('%s,"%s");', ops, var.name)); 
    output= strcat(output, '\n');
end
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: getArrayValue
%% Inputs: arrayType
%% Output: value
%% Description:
%% Gets the arrayType and returns the respective value
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [value] = getArrayValue(type)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    
    
    if(strcmp(type,'image'))
        value = 'I';
    elseif(strcmp(type,'tpl'))
        value = 'T';
    else
        value = 'A';
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: writeValues
%% Inputs: SymbolTableNode
%% Output: value
%% Description:
%% Gets the arrayType and returns the respective value
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function writeValues(node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    
    
global output;
global st;
global P;
global Q;
global R;
global S;

    if(node ~= 0)
        if(st.search(node.name) == 0)
            output = strcat( output, sprintf('"%d",', node.name));
        else
            output = strcat( output, sprintf('"%s",', node.name));
        end
        if(strcmp(node.arrayType , 'image') || strcmp(node.arrayType , 'tpl'))
            output = strcat( output,  sprintf('%d,',node.ptr_range.noElements)); 
            nodeR = node.ptr_range.firstElement ;
            for i=1:node.ptr_range.noElements     
                if(st.search(nodeR.end_range) == 0)
                    output = strcat(output, sprintf('%d', nodeR.end_range));   
                else
                    output = strcat( output,  nodeR.end_range); 
                end
                output = strcat(output, ',');
                nodeR = nodeR.next;
            end
        else
            output = strcat( output, '2,1,1,');
        end
        % Get the signal and noise
        if(strcmp(node.arrayType , 'image') == 1)
            if(P ~= 0)
                output = strcat( output, 'P,');
            else
                output = strcat( output, '8,');
            end
            if(Q ~= 0)
                output = strcat( output, 'Q,');
            else
                output = strcat( output, '2,');
            end
        elseif(strcmp(node.arrayType , 'tpl') == 1)
            if(R ~= 0)
                output = strcat( output, 'R,');
            else
                output = strcat( output, '8,');
            end
            if(S ~= 0)
                output = strcat( output, 'S,');
            else
                output = strcat( output, '2,');
            end
        else
            output = strcat( output, '8,2,');
        end
        %Get the coord list
        if(strcmp(node.arrayType , 'tpl'))
             nodeC = node.ptr_coord.firstElement;
             for i=1:node.ptr_coord.noElements
                 output = strcat(output, sprintf('%d,', nodeC.coord));   
                 nodeC = nodeC.next;
             end
        elseif(strcmp(node.arrayType , 'image'))
             for i=1:node.ptr_range.noElements
                 output = strcat(output, '0,');   
             end
        else
            output = strcat( output, sprintf( '0,0,'));
        end
    else
        output = strcat( output, '-1,-1,-1,-1,-1,');
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: reservePQSR()
%% Inputs: NONE
%% Output: NONE
%% Description:
%% Possible way to set the signal and noise bits by reserving the P Q S and
%% R
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function reservePQSR()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
    
global P;
global Q;
global S;
global R;
global st;
global output;
P = 0;
Q = 0;
S = 0;
R = 0;
%find = ntqu_search(st, 'P');
find = st.search('P');
if(find ~= 0)
    output = strcat( output, '## Set number of signal bits in image to P.\n');
    P = 'P';
end
%find = ntqu_search(st, 'Q');
find = st.search('Q');
if(find ~= 0)
    output = strcat( output, '## Set number of noise bits in image to Q.\n');
    Q = 'Q';
end
%find = ntqu_search(st, 'S');
find = st.search('S');
if(find ~= 0)
    output = strcat( output, '## Set number of signal bits in template to S.\n');
    S = 'S';
end
%find = ntqu_search(st, 'R');
find = st.search('R');
if(find ~= 0)
    output = strcat( output, '## Set number of noise bits in template to R.\n');
    R = 'R';
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% Function Name: evaluateProcedure
% %% Inputs: node : The procedure-statement that needs to be evaluated
% %% Output: None
% %% Description:
% %% This function evaluates a procedure
% %% expression)
% %% THIS PROGRAM NOW GENERATE ASC's
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
function [] = evaluateProcedure(node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
    
  global output;
  global st;
  
  procName = node.firstChild.value;
  if(strcmp(procName, 'display') ==1)
      value = st.search(node.firstChild.sibling.firstChild.value);
      if(value ~= 0)
          output = strcat( output, sprintf('%sXOUTX(',getArrayValue(value.arrayType)));
          writeValues(value);
          output = strcat( output, '-1,-1,-1,-1,-1,-1,-1,m2d,16);\n\n');
      end
  elseif(strcmp(procName, 'write') ==1)
      value = st.search(node.firstChild.sibling.firstChild.value);
      if(value ~= 0)
          output = strcat( output, sprintf('%sXWRTX(',getArrayValue(value.arrayType)));
          writeValues(value);
          output = strcat( output, sprintf('-1,-1,-1,-1,-1,-1,-1,m2d,16,"%s");', node.firstChild.sibling.firstChild.sibling.value));
        output = strcat( output, '\n\n');
      end
  elseif(strcmp(procName, 'readimage') ==1)
      
      name = sprintf('%s', node.firstChild.sibling.firstChild.value);

      value = st.search(node.firstChild.sibling.firstChild.sibling.value);

      if(value ~= 0)
          output = strcat( output, sprintf('%sXINPX(',getArrayValue(value.arrayType)));
          writeValues(value);
          output = strcat( output, sprintf('-1,-1,-1,-1,-1,-1,-1,d2m,16,"%s");', name));
          output = strcat( output, '\n\n');
      else
          display('Error: Invalid assignment');
      end
  end

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%% THE FOLLOWING COMMENTED FUNCTIONS DO NOT GENERATE THE ASC CODE. THEY
 %%% ARE SIMPLY COPY PASTED THAT GENERATES THE MATLAB CODE. THEY NEED
 %%% MODIFICATIONS TO GENERATE THE ASC CODE
 
%  
%  procName = node.firstChild.value;
%  
%  if(strcmp(procName, 'size') == 1)
%      output = strcat(output, ' size (');     
%      if(strcmp(node.firstChild.sibling.firstChild.type, 'expression') == 1)
%          evaluateExpression(node.firstChild.sibling.firstChild);
%          output = strcat(output, ' )');
%      else
%          display(' Illegal argument for function ');
%      end
%  elseif (strcmp(procName, 'domain') == 1)
%      nodeChild = node.firstChild.sibling.firstChild;
%      if(strcmp(nodeChild.type, 'expression') == 1)
%          if(strcmp(nodeChild.firstChild.type, 'identifier') == 1)
%              %output = strcat(output, sprintf('IAimgsiz(%s, ndims%s, npixels%s)',nodeChild.firstChild.value,nodeChild.firstChild.value,nodeChild.firstChild.value ));
%              output = strcat(output, sprintf(' %s ',nodeChild.firstChild.value));
%             %evaluateExpression(nodeChild);
%          else
%          end
%      else
%          display(' Illegal argument for function ');
%      end
% elseif(strcmp(procName, 'quit') ==1)
%     output = strcat( output, 'quit;\n'); 
%  end


 % output
 % pause;