
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: evaluate_command
%% Inputs: none (The input program string is present in a global variable)%% 
%% Output: None
%% Side Effects:
%% Description: Adds the nodes for the various commands in the abstract
%% syntax tree.
%% This function parses the command(i.e expression) sequences.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function evaluate_command()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%global token;
%global input;
global stack;
global st;
global ts;
%global pos;
global Analysis;
%global complexityAnalysis;
%global prettyPrint;
%global prettyPrintCounter;

%% RULES: <variable> = <expression> ; | ( <var_list> ) = <expression> ; | <procedure> (<actual_param_list>) ;
    if(ts.compare_kind('IDEN')) % for the procedures and assignment statement
        prevToken = ts.spelling();
        ts.nextToken();
        if(ts.compare('('))
            %% RULE: <procedure> (<actual_param_list>) ;
            node1 = nt_new_node('identifier', prevToken);
            snode1 = new_stack_node(node1);
            stack = ntst_push(stack, snode1);
            ts.nextToken();
            if(ts.compare(')'))
                %% Procedure with no parameters
                node2 = nt_new_node('null_param', 0);
                snode2 = new_stack_node(node2);
                stack = ntst_push(stack, snode2);
                node3 = nt_new_node('procedure',0);
                buildTree(node3,2);
                ts.nextToken();
            else
                %% Procedure with parameters. (CHECK THIS OUT)
                countParam = actual_param_list(0);
                if(countParam)
                    node2 = nt_new_node('actual_param_list',0);
                    buildTree(node2,countParam);
                end
                node3 = nt_new_node('procedure', 0);
                buildTree(node3, 2);
            end 
        elseif(ts.compare('['))
            %% RULES: <variable> = <expression>;
            %stvalue = ntqu_search(st, prevToken.spelling);
            symbol = st.search(prevToken);
            if(symbol == 0)
                disp_error(ts.spelling(), 'Variable not declared');
            end
            dimension = symbol.ptr_range.noElements;
            node1 = nt_new_node('identifier' , prevToken);
            snode1 = new_stack_node(node1);
            stack = ntst_push(stack, snode1);
            rangeValue();
            ts.nextToken();
            count = 0;
            while(ts.compare(','))%strcmp(token.kind, 'COMMA') == 1)
                rangeValue();
                ts.nextToken();
                count = count+1;
            end
            if(dimension ~= count+1)
                disp_error(token.spelling, sprintf('Dimension %s is %d != %d', prevToken, dimension, count+1));
            end
            if(ts.compare(']') == -1)%strcmp(token.kind, 'RSQUARE') == 0)
                disp_error(ts.spelling(), 'Expected" "]"');
            end
            ts.get(':=');
            ts.nextToken();
            compoundexpression();         
            node2 = nt_new_node('assignArray',0);
            buildTree(node2,3+count);

        elseif(ts.compare(':=')) %strcmp(token.kind, 'CE') == 1 || strcmp(token.kind, 'EQUALS') == 1)
                node1 = nt_new_node('identifier' , prevToken);
                snode1 = new_stack_node(node1);
                stack = ntst_push(stack, snode1);
                ts.nextToken();
                compoundexpression();
                if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'operand_size_bits') )
                    Analysis.assign(prevToken);
                end    
                node2 = nt_new_node('assign',0);
                buildTree(node2,2);
        else
            disp_error(ts.spelling(), 'Expected: ":=", "(", or "["');
        end
    elseif(ts.compare('do'))
            %% RULE: do { <command>* } while (<expression>) 
            %% Calls the funtion parse_while which parses the above rule.
            
            ret = parse_dowhile;
            if(ret > 0)
                node1 = nt_new_node('dowhile_statement',0);
                buildTree(node1, ret); 
            else
                disp_error('Empty:DoWhile');
            end   
    elseif(ts.compare('while'))
            %% RULE: while (<expression>) { <command>* } 
            %% Calls the funtion parse_while which parses the above rule.
            ret = parse_while;
            if(ret > 0)
                node1 = nt_new_node('while_statement',0);
                buildTree(node1, ret); 
            else
                disp_error('Empty:While');
            end
    elseif(ts.compare('if'))
            %% RULE: if (<expression>) { <command>* } <else_part>
            %% Calls the funtion parse_if which parses the above rule.
            
            ret = parse_if;
            if(ret > 0)
                node1 = nt_new_node('if_statement',0);
                buildTree(node1, ret); 
            else
                disp_error('Empty:IF');
            end 
    elseif(ts.compare('for'))
            %% RULE: for (<expression>) { <command>* } <else_part>
            %% Calls the funtion parse_for which parses the above rule.
           
            ret = parse_for;
            if(ret > 0)
                node1 = nt_new_node('for_statement',0);
                buildTree(node1, ret); 
            else
                disp_error('Empty:For');
            end 
    elseif(ts.compare('!ML'))
            %% RULE: matlab { <matlab command sequences>}
            ts.get('{');
            
            startpos = ts.pos();
            while(ts.compare('}') == 0)
                ts.nextToken();
            end
            input = ts.input();
            data = sprintf('%s',input(startpos : ts.pos()-2));
            stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', data)));%Push identifier on stack
            node2 = nt_new_node('matlab_sequence', 0);
            buildTree(node2, 1);
            ts.get(';');
    elseif(ts.compare('}') == 0 )
        disp_error(ts.spelling(), 'Expected identifier, "for", "if", "do", "while", or "!ML"');
    end

    while(ts.compare(';'))
        ts.nextToken();
    end
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: parse_if
%% Inputs: none (The input program string is present in a global variable)%% 
%% Output: None
%% Side Effects:
%% Description: Parses the rule "if (<expression>) { <command>* }
%% <else_part> ;"
%% This function parses the command(i.e expression) sequences.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
%% RULE : if (<expression>) { <command>* } <else_part> ;
function ret=parse_if
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ts;
    ts.get('(');
    ts.nextToken();
    %% Calls the function "expression" to check if an expression is
    %% present after the "if" keyword.
    compoundexpression();
    if(ts.compare(')')== 0)
        disp_error(token.spelling, 'Expected" ")"');
    end
    ts.get('then');
    ts.get('{');
    ts.nextToken();
    %% Calls the function "evaluate_command" to parse the
    %% command sequence after the "then" keyword.
     countCommand = 0;
     while(command_type)
        evaluate_command();
        countCommand = countCommand + 1;
     end
     ret = 1;
     if(countCommand ~= 0)
        node1 = nt_new_node('Command_Sequence',0);
        buildTree(node1, countCommand);
        ret=2;
     end

    if(ts.compare('}') == 0 )%strcmp(token.kind, 'RBRACE') == 0)
        disp_error(ts.spelling(), 'Expected" ")"');
    end
    
    %% then parse the else part of the expression
    retVal = parse_else_part(0);
    if(retVal)
        node1 = nt_new_node('else_part',0);
        buildTree(node1, retVal);
        ret = ret + 1;
    end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: parse_else_part
%% Inputs: none (The input program string is present in a global
%% variable)
%% Output: None
%% Side Effects:
%% Description: Parses the else part of the rule "if (<expression>) { <command>* }
%% <else_part> ;" The else part parses the following rule:
%% <else_part> ::= epsilon | <elseif_command>* <else_command>
%% This function parses the command(i.e expression) sequences.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ret = parse_else_part(ret)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ts;
    ts.nextToken();
    if(ts.compare('elseif'))
        ts.get('(');
        
        ts.nextToken();
        %Parse for the expression following the elseif command
        compoundexpression();
        
        if(ts.compare(')') == 0)%strcmp(token.kind, 'RPAREN') == 0)
            disp_error(ts.spelling(), 'Expected" ")"');
        end % Rparen
        ts.get('{');

        ts.nextToken();
        countCommand = 0;
        while(command_type)
            evaluate_command();
            countCommand = countCommand + 1;
        end
        if(countCommand ~= 0)
            node1 = nt_new_node('Command_Sequence',0);
            buildTree(node1, countCommand);
        end
        if(ts.compare('}') == 0)
            disp_error(token.spelling, 'Expected" "}"');
        end
        
        ret = ret + 1;
        node1 = nt_new_node('else_if',0);
        if(countCommand)
            buildTree(node1, 2);
        else
            buildTree(node1,1);
        end
        %ts.nextToken();
        
        ret = parse_else_part(ret);

	elseif(ts.compare('else'))
      % Parse the else part of an if command.
        ts.get('{');
        ts.nextToken();
        
        countCommand = 0;
        while(command_type)
        	evaluate_command();
            countCommand = countCommand + 1;
        end
        if(countCommand ~= 0)
            node1 = nt_new_node('Command_Sequence',0);
            buildTree(node1, countCommand);
        end
        if(ts.compare('}') == 0)
            disp_error(ts.spelling(), 'Expected" "}"');
        end %Rbrace
        ret = ret + 1;
        ts.nextToken();
        node1 = nt_new_node('else',0);
        if(countCommand == 0)
            buildTree(node1, 0);
        else
        	buildTree(node1, 1);
        end
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: parse_dowhile
%% Inputs: none (The input program string is present in a global
%% variable)
%% Output: None
%% Side Effects: 
%% Description: Parses the "do while statements" i.e. the following rule
%% do { <command>* } while (<expression>);
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
function ret=parse_dowhile
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ts;

    ts.get('{');
    ts.nextToken();
    %Parses the command statements following

     countCommand = 0;
     while(command_type)
        evaluate_command();
        countCommand = countCommand + 1;
     end
     ret = 1;
     if(countCommand ~= 0)
        node1 = nt_new_node('Command_Sequence',0);
        buildTree(node1, countCommand);
        ret=2;
     end
     
    if(ts.compare('}') == 0)
        disp_error(token.spelling, 'Expected" "}"');
    end
    ts.get('while');
    ts.get('(');
    ts.nextToken();
    %Parses for the expression part of the while statement 
    compoundexpression();

    if(ts.compare(')') == 0)
        disp_error(ts.spelling(), 'Expected" ")"');
    end
    ts.nextToken();

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: parse_while
%% Inputs: none (The input program string is present in a global
%% variable)
%% Output: None
%% Side Effects: 
%% Description: Parses the "while statements" i.e. the following rule
%% while (<expression>) { <command>* } ;
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
function ret=parse_while
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*


global ts;

    ts.get('(');
    ts.nextToken();
    %Parses for the expression part of the while statement
    compoundexpression();
    if(ts.compare(')') == 0)
        disp_error(token.spelling, 'Expected" ")"');
    end
    ts.get('{');
    ts.nextToken();

     countCommand = 0;
     while(command_type)
        evaluate_command();
        countCommand = countCommand + 1;
     end
     ret = 1;
     if(countCommand ~= 0)
        node1 = nt_new_node('Command_Sequence',0);
        buildTree(node1, countCommand);
        ret=2;
     end

    if(ts.compare('}') == 0)
        disp_error(ts.spelling(), 'Expected" "}"');
    end
    ts.nextToken();
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: parse_for
%% Inputs: none (The input program string is present in a global
%% variable)
%% Output: None
%% Side Effects: 
%% Description: Parses the "for statements" i.e. the following rule
%% or expression do {<command>*} endfor;
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ret=parse_for
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*


global ts;

        %Parses for the range staments of the for command
        %if(for_range)
        for_range();
        ts.get('do');
        ts.get('{');
        ts.nextToken();
        %Parses the command staments following the
        %expressions
         countCommand = 0;
         while(command_type)
            evaluate_command();
            countCommand = countCommand + 1;
         end
         ret = 1;
         if(countCommand ~= 0)
            node1 = nt_new_node('Command_Sequence',0);
            buildTree(node1, countCommand);
            ret=2;
         end

        if(ts.compare('}') == 0)
            disp_error(ts.spelling(), 'Expected: "}"');
        end
        ts.nextToken();

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: for_range
%% Inputs: none (The input program string is present in a global
%% variable)
%% Output: None
%% Side Effects: 
%% Description: Parses the range for execution of the statements of the for
%% variables. "Start:End" The start, increment and end can be a
%% number or a literal
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function for_range
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global stack;
global ts;

    ts.get_kind('IDEN');
    node1 = nt_new_node('identifier' ,ts.spelling());
    snode1 = new_stack_node(node1);
    stack = ntst_push(stack, snode1);
    
    ts.get('=');
    rangeValue();
    ts.get(':');
    rangeValue();
    node1 = nt_new_node('Range',0);
    buildTree(node1,3);
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: rangeValue
%% Inputs: None 
%% Output: None
%% Side Effects: 
%% Description: Parses the range value type for each range set
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function []=rangeValue()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global stack;
global st;
global ts;

    ts.nextToken();
    if(ts.compare('-'))%strcmp(token.kind ,'WEAK_OP'))
        ts.nextToken();
        sign = 1;
    else
        sign = 0;
    end
    
    if(ts.compare_kind('IDEN'))%strcmp(token.kind ,'IDEN'))
        if(sign == 0)
            node1 = nt_new_node('identifier' ,ts.spelling());
        else
            node1 = nt_new_node('identifier' , sprintf('-%s',ts.spelling()));
        end
        snode1 = new_stack_node(node1);
        stack = ntst_push(stack, snode1);
        if(st.search(ts.spelling()) == 0)%if(ntqu_search(st, token.spelling)  == 0)
            disp_error(ts.spelling(), 'Variable not declared');
        end
    elseif(ts.compare_kind('NUMLIT'))
        
        if(sign == 0)
            node1 = nt_new_node('numlit' ,ts.value());
        else
            node1 = nt_new_node('numlit' ,-ts.value());
        end
        snode1 = new_stack_node(node1);
        stack = ntst_push(stack, snode1);
    else
        disp_error(token.spelling, 'Expected: identifer or numlit');
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: var_list
%% Inputs: none (The input program string is present in a global
%% variable)
%% Output: None
%% Side Effects: 
%% Description: Parses the list of variables separated by commas.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function count = var_list(count)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global stack;
global st;
global ts;

    ts.get_kind('IDEN');
    
    if(st.search(ts.spelling()) == 0)
        disp_error(ts.spelling(), 'Variable not declared');
    end
    node1 = nt_new_node('identifier' , ts.spelling());
    snode1 = new_stack_node(node1);
    stack = ntst_push(stack, snode1);
    ts.nextToken();
    if(ts.compare(','))%strcmp(token.kind, 'COMMA') == 1)
        count = var_list(count + 1);
    elseif(ts.compare(')'))%strcmp(token.kind, 'RPAREN') == 0)
        disp_error(ts.spelling(), 'Expected: ")" or ","');
    else
        ts.nextToken();
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: actual_param_list
%% Inputs: none (The input program string is present in a global
%% variable)
%% Output: None
%% Side Effects: 
%% Description: Parses the arguments of the procedure.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function countParam=actual_param_list(countParam)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global stack;
global ts;

    if(ts.compare_kind('STRLIT'))%strcmp(token.kind, 'STRLIT')) 
        node1 = nt_new_node('strlit', ts.spelling());
    elseif(ts.compare_kind('IDEN'))
        node1 = nt_new_node('identifier', ts.spelling());
    elseif(ts.compare_kind('NUMLIT'))
        node1 = nt_new_node('numlit', ts.spelling());
    else
        disp_error(ts.spelling(), 'Expected: String, identifier, or number');
        countParam = 0;
    end
        
    snode1 = new_stack_node(node1);
    stack = ntst_push(stack, snode1);
    ts.nextToken();
    countParam = countParam + 1;     
    if(ts.compare(','))
        ts.nextToken();
        countParam = actual_param_list(countParam);
    elseif(ts.compare(')') )
        ts.nextToken();
    else
        disp_error(ts.spelling(), 'Expected: "," or ")"');
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: compoundexpression
%% Inputs: none (The input program string is present in a global
%% variable)
%% Output: None
%% Side Effects: 
%% Description: Grammar E -> TE' | T ; T is parsed by parse_term; E' is parsed by parse_exp 
%% Calls the function parse_exp which in turn parses the
%% expression
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function compoundexpression()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global Analysis;

    Logic();
    node1 = nt_new_node('expression', 0);
    buildTree(node1,1);
    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'operand_size_bits') )
        Analysis.expression(AST.firstChild);
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: Logic
%% Inputs: none (The input program string is present in a global
%% variable)
%% Output: None
%% Side Effects: 
%% Description: Build a binary tree for logic operatiors
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
function Logic()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ts;
    Equality();
    while(ts.compare('&&') || ts.compare('||') )
        name = ts.spelling();
        ts.nextToken();
        Equality();
        node1 = nt_new_node(name,0);
        buildTree(node1, 2); % expr op expr
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: Equality
%% Inputs: none (The input program string is present in a global
%% variable)
%% Output: None
%% Side Effects: 
%% Description: Build a binary tree for comparision operatiors
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
function Equality()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ts;
    Term();
    
    while(ts.compare('!=') || ts.compare('==') || ts.compare('>') || ts.compare('<') || ts.compare('<=') || ts.compare('>='))
        name = ts.spelling();
        ts.nextToken();
        Term();
        node1 = nt_new_node(name,0);
        buildTree(node1, 2); % expr op expr
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: Term
%% Inputs: none (The input program string is present in a global
%% variable)
%% Output: None
%% Side Effects: 
%% Description: Build a binary tree for plus and minus operatiors
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
function Term()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ts;
    Factor();
    while(ts.compare('+') || ts.compare('-') )
        name = ts.spelling();
        ts.nextToken();
        Factor();
        node1 = nt_new_node(name,0);
        buildTree(node1, 2); % expr op expr
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: Factor
%% Inputs: none (The input program string is present in a global
%% variable)
%% Output: None
%% Side Effects: 
%% Description: Build a binary tree for multiplication and division operatiors
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
function Factor()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ts;

    Ternary();
    while(ts.compare('*') || ts.compare('/') )
        name = ts.spelling();
        ts.nextToken();
        Ternary();
        node1 = nt_new_node(name,0);
        buildTree(node1, 2);
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: Ternary
%% Inputs: none (The input program string is present in a global
%% variable)
%% Output: None
%% Side Effects: 
%% Description: Build a binary tree for multiple custom binary operations
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
function Ternary()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global ts;

    Secondary();
    
    while(ts.compare('^') || ts.compare(sprintf('%c',92)) || ts.compare('!restrict') || ts.compare('!extend') || ts.compare('!extend') ||...
          ts.compare('!union') || ts.compare('!intsct') || ts.compare('|_') || ts.compare('|^') ||  ts.compare('@') || ...
          ts.compare('!max') || ts.compare('!min'))
        name = ts.spelling();
        ts.nextToken();
        Secondary();
        node1 = nt_new_node(name,0);
        buildTree(node1, 2);
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: Secondary
%% Inputs: none (The input program string is present in a global
%% variable)
%% Output: None
%% Side Effects: 
%% Description: Build a binary tree for convolution operations 
%% and characteristic operations
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
function Secondary()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global stack;
global st;
global ts;

Primary();
if(ts.compare('(+)') || ts.compare('(v)') || ts.compare('(^)') || ts.compare('[v]') || ts.compare('[^]') || ts.compare('!gcon') || ts.compare('!amax') || ts.compare('!amin') ||...
   ts.compare('!mmax') || ts.compare('!mmin') || ts.compare('(+)<') || ts.compare('(v)<') || ts.compare('(^)<') || ts.compare('[v]<') || ts.compare('[^]<'))
    name = ts.spelling();
    ts.get_kind('IDEN');
    symbol = st.search(ts.spelling());
    if(symbol == 0)
        disp_error(ts.spelling(), 'Variable not declared');
    end

    if(strcmp(symbol.arrayType, 'tpl') == 0 && strcmp(symbol.arrayType, 'tplrec') == 0 && strcmp(symbol.arrayType, 'vartpl') == 0)
        disp_error(token.spelling, 'Variable not a template');
    end

    stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling())));
    node1 = nt_new_node(name,0);
    buildTree(node1, 2);
    ts.nextToken();
elseif(ts.compare('||_') || ts.compare('!chi')  )%strcmp(token.spelling, '||_') || strcmp(token.spelling, '!chi'))
    name = ts.spelling();
    ts.nextToken();
    if(ts.compare('>=') == 0 && ts.compare('<=') == 0 && ts.compare('==') == 0 && ts.compare('>') == 0 && ts.compare('<') == 0)
        disp_error(token.spelling, 'Compare operator expected');
    end
    
    node2 = nt_new_node('strlit', ts.spelling());
    ts.nextToken();
    if(ts.compare_kind('NUMLIT') == 0 && ts.compare_kind('IDEN') == 0 )
        disp_error(token.spelling, 'Expected: NUMLIT or IDEN');
    end
    
    if(ts.compare_kind('NUMLIT'))
        node1 = nt_new_node('numlit', ts.value());
    else
        if(st.search(ts.spelling()) == 0)
            disp_error(token.spelling, 'Variable not declared');
        end
        node1 = nt_new_node('identifier', ts.spelling());
    end
    
    stack = ntst_push(stack, new_stack_node(node1));
    stack = ntst_push(stack, new_stack_node(node2));
    buildTree(nt_new_node(name,0), 3);
    ts.nextToken();
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: Primary
%% Inputs: none (The input program string is present in a global
%% variable)
%% Output: None
%% Side Effects: 
%% Description: Builds the unary operations and root objects
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

function Primary()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global stack;
global st;
global ts;
    if(ts.compare('-'))
        name = ts.spelling();
        ts.nextToken();
        Primary();
        node1 = nt_new_node(name,0);
        buildTree(node1, 1); 
    elseif(ts.compare('+'))
        ts.nextToken();
        Primary();
    elseif(ts.compare('('))
        ts.nextToken();
        Logic();
        if(ts.compare(')') == 0)%strcmp(token.kind, 'RPAREN' ~=0))
            disp_error(ts.spelling(), 'Expected: ")"');
        end
        node1 = nt_new_node('()',0);
        buildTree(node1, 1);
        ts.nextToken();
        

    elseif(ts.compare_kind('NUMLIT') )%strcmp(token.kind, 'NUMLIT'))
        stack = ntst_push(stack, new_stack_node(nt_new_node('numlit', ts.value())));
        ts.nextToken();
    elseif(ts.compare('domain'))
        ts.nextToken();
        if(ts.compare('('))
            ts.get_kind('IDEN');
            if( st.search(ts.spelling() ) == 0)
                disp_error(ts.spelling(), 'Variable not declared');
            end
            stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', ts.spelling() )));
            node1 = nt_new_node('domain',0);
            buildTree(node1, 1);
            ts.get(')');
            ts.nextToken();
        end
    elseif(ts.compare('!log'))
        %'log' '( '<integer>' , '<image>' ')'
        ts.get('(');

        ts.nextToken();
        if(ts.compare_kind('NUMLIT') == 0 && ts.compare_kind('IDEN') == 0 )
            disp_error(ts.spelling(), 'Expected: NUMLIT or IDEN');
        end
        if(ts.compare_kind('NUMLIT'))
            node1 = nt_new_node('numlit', ts.value());
        else
            if(st.search(ts.spelling()) == 0) %;ntqu_search(st, token.spelling) == 0)
                disp_error(ts.spelling(), 'Variable not declared');
            end
            node1 = nt_new_node('identifier', ts.spelling());
        end
        stack = ntst_push(stack,  new_stack_node(node1));
        
        ts.get(',');
        ts.nextToken();
        Logic();
        if(ts.compare(')') == 0)%strcmp(token.kind, 'RPAREN' ~=0))
            disp_error(ts.spelling(), 'Expected: ")"');
        end
        
        node1 = nt_new_node('!log',0);
        buildTree(node1, 2);
        ts.nextToken();
    elseif(ts.compare('chi') || ts.compare('!restrict'))
        %'chi' '(' '<string>' '<integer>' '<image>' ')'
        name = ts.spelling();
        ts.get('(');
        ts.get_kind('STRLIT');

        node2 = nt_new_node('strlit', ts.spelling());
        ts.get(',');
        ts.nextToken();
        if(ts.compare_kind('NUMLIT') == 0 && ts.compare_kind('IDEN') == 0 )
            disp_error(ts.spelling(), 'Expected: NUMLIT or IDEN');
        end
        if(ts.compare_kind('NUMLIT'))
            node1 = nt_new_node('numlit', ts.value());
        else
            if(st.search(ts.spelling()) == 0) %;ntqu_search(st, token.spelling) == 0)
                disp_error(ts.spelling(), 'Variable not declared');
            end
            node1 = nt_new_node('identifier', ts.spelling());
        end

        ts.get(',');
        ts.get_kind('IDEN');
        if(st.search(ts.spelling()) == 0)            
            disp_error(ts.spelling(), 'Variable not declared');
        end
        Logic();
        stack = ntst_push(stack, new_stack_node(node1));
        stack = ntst_push(stack, new_stack_node(node2));
        node1 = nt_new_node(name,0);
        buildTree(node1, 3);
        if(ts.compare(')') == 0)
            disp_error(ts.spelling(), 'Expected: ")"');
        end
        ts.nextToken();
    elseif(ts.compare('!sum') || ts.compare('!prod') || ts.compare('!max') || ts.compare('!min') || ts.compare('!mean') ||...
          ts.compare('!stdev') ||  ts.compare('!sin')    || ts.compare('!cos')    || ts.compare('!tan')    ...
        || ts.compare('!sinh')   || ts.compare('!cosh')   || ts.compare('!tanh')   ...
        || ts.compare('!asin') || ts.compare('!acos') || ts.compare('!atan') ...
        || ts.compare('!asinh')|| ts.compare('!acosh')|| ts.compare('!atanh')...
        || ts.compare('!abs') || ts.compare('!exp')  )
        
        name = ts.spelling();
        ts.nextToken();
        if(ts.compare('('))
            ts.nextToken(); 
            Logic();
        elseif(ts.compare_kind('IDEN'))
            node2 = nt_new_node('identifier', ts.spelling());
            stack = ntst_push(stack,  new_stack_node(node2));
        else
            node2 = nt_new_node('numlit', ts.value());
            stack = ntst_push(stack,  new_stack_node(node2));
        end
        
        node1 = nt_new_node(name,0);
        buildTree(node1, 1);
        ts.nextToken();
    elseif(ts.compare_kind('IDEN') )%strcmp(token.kind, 'IDEN'))
        if(st.search(ts.spelling()) == 0)            
            disp_error(ts.spelling(), 'Variable not declared');
        end
        node1 = nt_new_node('identifier', ts.spelling());
        ts.nextToken();
        if(ts.compare('[') )%strcmp(token.kind, 'LSQUARE'))
            ts.nextToken();
            if(ts.compare_kind('IDEN') )%strcmp(token.kind, 'IDEN'))
                node2 = nt_new_node('identifier', ts.spelling());
            else
                node2 = nt_new_node('numlit', ts.value());
            end
            stack = ntst_push(stack, new_stack_node(node2));
            ts.nextToken();
            count = 1;
            while(ts.compare(',') )
                ts.nextToken();
                if(ts.compare_kind('IDEN'))
                    node2 = nt_new_node('identifier', ts.spelling());
                else
                    node2 = nt_new_node('numlit', ts.value());
                end
                stack = ntst_push(stack,  new_stack_node(node2));
                ts.nextToken();
                count = count + 1;
            end
            if(ts.compare(']') == 0)
                disp_error(ts.spelling(),'Expected: "]"');
            end
            ts.nextToken();
            buildTree(node1, count);
        else
            stack = ntst_push(stack, new_stack_node(node1));
            if(ts.compare('!slice'))
                name = ts.spelling();
                ts.get_kind('NUMLIT');
                stack = ntst_push(stack, new_stack_node(nt_new_node('numlit', ts.value())));
                node1 = nt_new_node(name,0);
                buildTree(node1, 2);
                
            end
        end
    else
        disp_error(ts.spelling(), 'Unknows operation')
    end

    
