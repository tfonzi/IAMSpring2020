%{

IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS. ALL ERRORS ARE THE RESPONSIBILITY OF THE
USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

Function Name: dynamic_analysis Inputs: None Output: Analysis OBJECT set for dynamic complexity Description: This function is an object that is used to perform dynamic complexity analysis

NOTE: This file contains inline comment thus it needs to be cleaned up before final production.

%}

function listObject = dynamic_analysis() % *** No inputs bc it's an object. BUT, what's the theory behind the object...? ***


  count = 0;
  completed = 0;    % A counter to see how many steps (i.e. operation) it has completed? 
  %values = [0, 0, 0, 0, 0]; 
  %operations = {'DiskReads', 'DiskWrites', 'MemReads', 'MemWrites', 'DisplayOps'};
  %table = [0, 0, 0, 0, 0]; 
  values = [0];
  operations = {'DiskReads'};
  table = [0];
  equations = {};
  
  listObject = struct('type', 'dynamic_analysis',...
                      'display',@display_table,...
                      'table',@get_table,...
                      'values',@get_values,...
                      'operations',@get_operations,...
                      'index',@get_index,...
                      'count',@get_count,...
                      'size',@get_size,...
                      'length',@get_length,...
                      'max',@get_max,...
                      'equations',@get_equations,...
                      'increase',@increase_data,...
                      'add',@add_data, ...
                      'complete',@complete_data); 
 
  function info = display_table()
    % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
    % ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
    % OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    % ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
    % SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
  
      output = 'Operation\t';
      [M N] = size(table);
      for i = 1:N
          output = strcat(output, operations{i}, '\t\t');   % *** Is strcat just concatinating the output? *** 
      end
      output = strcat(output, '\n');
      for i = 1:M
          output = strcat(output, equations{i}, '\n\t\t\t');
          for j = 1:N
            output = strcat(output, sprintf('%d', table(i,j) ), '\t'); % Hmm... this has a relationship in outputting the table; "table(i, j)" -- Yes bc look @ the fnc name 
          end % *** END FOR INNER FOR ***
          output = strcat(output, '\n');
      end % *** END OF OUTTER FOR ***
      info = sprintf(output);
  end % *** END OF 'display_table()' FNC ***

    function matrix = get_table()
    % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
    % ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
    % OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    % ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
    % SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        matrix = table; % The table is outputted as a matrix 
    end % *** END FOR FNC *** 

    function matrix = get_values()
    % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
    % ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
    % OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    % ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
    % SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        matrix = values;    % Filling in the rows & cols of the matrix 
    end % *** END OF FNC *** 

    function array = get_operations()
    % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
    % ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
    % OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    % ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
    % SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        array = operations; % This array contains the list of steps (i.e. operations: + - + / * etc.)
    end % *** END OF FNC *** 

% Hmm... the name of the file is dynamic analysis --> Is it performing a hollistic collecting of information to perform a analysis? Just trying to make sense of the name and the fnc just returning a obj

    function number = get_count()  
    % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
    % ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
    % OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    % ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
    % SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        number = ceil(0.5:0.5:length(equations) + 1 + completed) ; % 0:length(equations); Gets the # of operators?
    end % *** END OF FNC *** 

    function number = get_size()
    % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
    % ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
    % OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    % ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
    % SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        number = length(equations); % Hmm.. so we use length in signals to return # of col 
    end % *** END OF FNC *** 

    function number = get_max()   
    % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
    % ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
    % OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    % ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
    % SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        number = max(max((values)));    % Gets the max value from the table; Nested 'max' call bc the first nest retrieves the max from each col or row 
    end % *** END OF FNC *** 

    function list = get_equations()        
    % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
    % ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
    % OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    % ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
    % SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        list =  equations;  % This allows to show the steps in rows in the table view 
    end % *** END OF FNC ***

    function number = get_length()        
    % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
    % ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
    % OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    % ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
    % SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        number =  length(operations); % THe # of operators 
    end % *** END OF FNC ***

    function found = get_index(name)   % Gets the index of the operator then set found to T      
    % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
    % ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
    % OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    % ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
    % SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        found = 0;  % Initialy, it's F 
        for i = 1:length(operations)
            if(strcmp(operations{i},name))
                found = i;
                break;
            end % END OF FIRST IF 
        end % *** END OF FOR ***
    end % *** END OF FNC ***

    function add_data(equation, varargin)   % This fnc is essentially adding data to the tbl shown to the usr    
    % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
    % ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
    % OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    % ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
    % SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        count = count + 1; % Keep a counter for each data addition        
        %increase_data(varargin);
        ops = size(varargin, 2);    % Size returns the dimension of the matrix; In this case, the col size is 2 
        for i = 1:2:ops % Step size of 2 
            index = get_index(varargin{i});
            if(index ~= 0)  % Conditional upon not being 0th index 
                values(count*2, index) = varargin{i+1} + values(count*2-1 , index);
                table(count, index) = varargin{i+1};
            else
                operations{end+1} = varargin{i};
                values(count*2 , length(operations)) = varargin{i+1};
                table(count , length(operations)) = varargin{i+1};
            end % *** END FOR IF ***
        end % *** END OF FOR *** 
        equations{count} = sprintf('%d : %s', count, equation);
        
        for i = 1:length(operations)
            values(count*2 + 1 , i) = values(count*2, i);
            values(count*2 + 2 , i) = values(count*2 + 1, i);
        end % *** END OF FOR ***
        
    end % *** END OF FNC *** 

    function increase_data(varargin)        % Hmm... maybe this gets called on after each step (i.e. operator)
    % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
    % ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
    % OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    % ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
    % SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        ops = size(varargin, 2);
        for i = 1:2:ops
            index = get_index(varargin{i});
            if(index ~= 0)
                values(count*2 + 2 , index) = values(count*2 + 1 , index) + varargin{i+1};
                values(count*2 + 2 , index) = values(count*2 + 1 , index) + varargin{i+1};
                table(count , index) = table(count , index) + varargin{i+1};
            else
                operations{end+1} = varargin{i};
                values(count*2 + 2 , length(operations)) = varargin{i+1};
                table(count , length(operations)) = varargin{i+1};
            end % *** END OF IF ***
        end % *** END OF FOR ***
    end % *** END OF FNC ***

    function complete_data()    % THIS IS THE FINAL TBL 
    % IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
    % ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
    % OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    % ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
    % SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
        completed = 0.5;
        for i = 1:length(operations)
            values(count*2 + 2 , i) = values(count*2 + 1, i);   % Observe the indexing 
            values(count*2 + 3 , i) = values(count*2 + 2, i);
        end % *** END OF FOR ***
    end % *** END OF FNC ***
end % *** END OF MAIN FNC ***