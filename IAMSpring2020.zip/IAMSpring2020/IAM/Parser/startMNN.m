% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global library;
global kernallibrary;
global path;
path = pwd;
d = strcat(path(1:length(pwd)-3), 'MNN');
cd(d);
if(isunix)
    addpath(strcat(d, '/General'));
    addpath(strcat(d, '/ImageArray'));
    addpath(strcat(d, '/Images/64x64/English'));
    addpath(strcat(d, '/Images/64x64/Negative'));
    addpath(strcat(d, '/Images/64x64/Number'));
    addpath(strcat(d, '/Images/64x64/Spanish'));
    addpath(strcat(d, '/Images/Picture'));
    addpath(strcat(d, '/Images/Pictures/50'));
    addpath(strcat(d, '/Images/Pictures/1600'));
    addpath(strcat(d, '/Images/Pictures/2560/A'));
    addpath(strcat(d, '/Images/Pictures/2560/B'));
    addpath(strcat(d, '/Images/Pictures/2560/C'));
    addpath(strcat(d, '/Images/Pictures/2560/D'));
    addpath(strcat(d, '/Images/Pictures/2560/E'));
    addpath(strcat(d, '/Images/SmallNegative'));
    addpath(strcat(d, '/Images/SmallNumber'));
    addpath(strcat(d, '/Images/testimage2'));
    addpath(strcat(d, '/Images/testimageG'));
    addpath(strcat(d, '/Images/testimages'));
    addpath(strcat(d, '/Mapping'));
    addpath(strcat(d, '/class'));
elseif(ispc)
    addpath(strcat(d, '\General'));
    addpath(strcat(d, '\ImageArray'));
    addpath(strcat(d, '\Images\64x64\English'));
    addpath(strcat(d, '\Images\64x64\Negative'));
    addpath(strcat(d, '\Images\64x64\Number'));
    addpath(strcat(d, '\Images\64x64\Spanish'));
    addpath(strcat(d, '\Images\Picture'));
    addpath(strcat(d, '\Images\Pictures\50'));
    addpath(strcat(d, '\Images\Pictures\1600\A'));
    addpath(strcat(d, '\Images\Pictures\2560\B'));
    addpath(strcat(d, '\Images\Pictures\2560\C'));
    addpath(strcat(d, '\Images\Pictures\2560\D'));
    addpath(strcat(d, '\Images\Pictures\2560\E'));
    addpath(strcat(d, '\Images\SmallNegative'));
    addpath(strcat(d, '\Images\SmallNumber'));
    addpath(strcat(d, '\Images\testimage2'));
    addpath(strcat(d, '\Images\testimageG'));
    addpath(strcat(d, '\Images\testimages'));
    addpath(strcat(d, '\Mapping'));
    addpath(strcat(d, '\class'));
else
    display('Cannot run on this operating system ');
    stop;
end

library = hashtable;
kernallibrary = hashtable;