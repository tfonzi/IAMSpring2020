
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: IAImgMult
%% Inputs: input object A, input name A, input object B, input name B, output name
%% Output: output object
%% Description:
%% Build and object that is an multiplication of A and B 
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function table = IAImgMult(a,atext,b,btext, assign)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global Analysis;
global tempCount;
JMED = 0;
BitMultSize = 16;
Bits = 0;
Noise = 0;
aBits = 0;
bBits = 0;
aNoise = 0;
bNoise = 0;
value1 = st.search(atext);
value2 = st.search(btext);
if(value1 ~= 0 && value2 ~= 0 && strcmp(value1.arrayType, 'nil') == 0 && strcmp(value2.arrayType, 'nil') == 0)
    table = matimage(value1.infimum, value1.supremum);
    %Compare dimensions
    if(value1.ptr_range.noElements ~= value2.ptr_range.noElements ||isempty(find(value1.infimum ~= value2.infimum, 1 )) == 0 || isempty(find(value1.supremum ~= value2.supremum, 1)) == 0)
        disp_error('Runtime', sprintf('Domains of "%s" and "%s" are incompatible', atext, btext ));
    end
    %Perform Images additions.
    if(value1.ptr_range.noElements < 5)
        coord = first(value1);
        lastcoord = last(value1);
        
        %if (isempty(Analysis) || strcmp(Analysis.type, 'worstcase') == 0 || strcmp(Analysis.type, 'nonparametric') == 0 )

        if(  isempty(Analysis) == 0 && strcmp(Analysis.type, 'classicalFD') ) %check if analysis type is classicalFD
            errorList = 0;%initialize error list
            count = 1;%loop counter
            deviation = 10;%used to generate error
            while(isempty(find(coord ~= lastcoord, 1)) == 0)%loops throught every value of image
                errorA = randi([-deviation,deviation]);%generates random error value
                errorB = randi([-deviation,deviation]);%generates random error value
                errorC = abs(a.get(coord) * abs(errorB) +  b.get(coord) * abs(errorA) + abs(errorA)*abs(errorB)); %performes error calculation for mult
                errorList(count) = errorC;%adds error value to errorList
                count = count +1;
                table.put(coord, a.get(coord) * b.get(coord));%adds value to table
                coord = next(value1,coord);
            end
            %errorA = randi(1,1,[-deviation,deviation]);
            %errorB = randi(1,1,[-deviation,deviation]);
            %errorC = abs(errorA) * abs(errorB);
            %errorList(count) = errorC;
            %table.put(coord, a.get(coord) * b.get(coord));
            Analysis.add(sprintf('%s = %s * %s', assign, atext, btext), errorList); %adds error list to global analysis object
            
        elseif( isempty(Analysis) == 0 &&  strcmp(Analysis.type, 'nonparametric') )
            JOMDhash = hashimage();
            while(isempty(find(coord ~= lastcoord, 1)) == 0)
                Avalue = round(a.get(coord));
                Bvalue = round(b.get(coord));
                Cvalue = Avalue * Bvalue;
                JOMDhash.put([Avalue, Bvalue],  JOMDhash.get([Avalue, Bvalue]) + 1);
                table.put(coord, Cvalue);
                coord = next(value1,coord);
            end
            Avalue = round(a.get(coord));
            Bvalue = round(b.get(coord));
            Cvalue = Avalue * Bvalue;
            JOMDhash.put([Avalue, Bvalue],  JOMDhash.get([Avalue, Bvalue]) + 1);
            table.put(coord, Cvalue);
            Amin = IAImgMin(a, atext, 0);
            Amax = IAImgMax(a, atext, 0);
            Bmin = IAImgMin(b, btext, 0);
            Bmax = IAImgMax(b, btext, 0);
            JOMDhash = normalizeHashImage(JOMDhash, Amin, Amax, 1, Bmin, Bmax, 1, 'JOMD');
            JOMDnew = new_JOMD(Amax, Amin, Bmax, Bmin, JOMDhash);
            figure('Name', 'JOMD Figure');
            imshow(uint8(JOMDimage(JOMDnew)-1));

            outputJOMD(JOMDnew, atext, btext);
            JMED = produceJMED_Mult(value1.JMED,value2.JMED, JOMDnew, Amin*Bmin, Amax*Bmax);
            figure('Name', 'JMED C Figure');
            imshow(uint8(JMEDimage(JMED)-1));
        else
            table.set(b.data() .* a.data());
            %while(isempty(find(coord ~= lastcoord, 1)) == 0)
            %    table.put(coord, a.get(coord) * b.get(coord));
            %    coord = next(value1,coord);
            %end
            %table.put(coord, a.get(coord) * b.get(coord));
        end
        if(isempty(Analysis) == 0)
            if(strcmp(Analysis.type, 'operand_size_bits')) 
                aBits = value1.Bits;
                bBits = value2.Bits;
                aNoise = value1.Noise;
                bNoise = value2.Noise;
            elseif(strcmp(Analysis.type, 'dynamic_analysis')) 
                Asize = prod(value1.supremum - value1.infimum + 1);
                Analysis.add(sprintf('%s = %s * %s', assign, atext, btext), 'MemReads', 2*Asize, 'MemWrites', Asize, 'Mult', Asize);
            end
        end

    else
        disp_error('Runtime', 'Cannot compute images greater than dimensions of 4');
    end
    node = st_new_PSnode(0, assign, value1.type, value1.arrayType, 0, value1.ptr_range, 0, value1.scan, value1.connectivity);
elseif((value1 ~= 0 && strcmp(value1.arrayType, 'nil') == 0) && (value2 == 0 || (value2 ~= 0 && strcmp(value2.arrayType, 'nil'))))
    table = matimage(value1.infimum, value1.supremum);
    coord = first(value1);
    lastcoord = last(value1);
    if( isempty(Analysis) == 0 && strcmp(Analysis.type, 'classicalFD') )
        count = 1;
        errorList = 0;
        deviation = Analysis.deviation;
        while(isempty(find(coord ~= lastcoord, 1)) == 0)
            errorC = randi(1,1,[-deviation,deviation]);
            errorList(count) = abs(errorC);
            count = count +1;
            table.put(coord, a.get(coord) * b);
            coord = next(value1,coord);
        end
        errorC = randi(1,1,[-deviation,deviation]);
        errorList(count) = errorC;
        table.put(coord, a.get(coord) * b);
        figure('Name',sprintf('%s * %s : Error Analysis', atext, btext));
        hist(errorList,deviation);
    else
        table.set(b .* a.data());
        %while(isempty(find(coord ~= lastcoord, 1)) == 0)
        %    table.put(coord, a.get(coord) * b);
        %    coord = next(value1,coord);
        %end
        %table.put(coord, a.get(coord) * b);
    end
    
    if(isempty(Analysis) == 0)
        if(strcmp(Analysis.type, 'operand_size_bits')) 
        aBits = value1.Bits;
        aNoise = value1.Noise;
        bBits = round(log2(b));
        elseif(strcmp(Analysis.type, 'dynamic_analysis')) 
            Asize = prod(value1.supremum - value1.infimum + 1);
            Analysis.add(sprintf('%s = %s * %s', assign, atext, btext), 'MemReads', Asize+1, 'MemWrites', Asize, 'Mult', Asize);
        end
    end
    node = st_new_PSnode(0, assign, value1.type, value1.arrayType, 0, value1.ptr_range, 0, value1.scan, value1.connectivity);
elseif((value1 == 0 && value2 == 0) || (value1 ~= 0 && strcmp(value1.arrayType, 'nil') && value2 ~= 0 && strcmp(value2.arrayType, 'nil')) || (value1 == 0 && value2 ~= 0 && strcmp(value2.arrayType, 'nil')) || (value2 == 0 && value1 ~= 0 && strcmp(value1.arrayType, 'nil')))
    table = a*b;
    
    if(isempty(Analysis) == 0)
        if(strcmp(Analysis.type, 'operand_size_bits')) 
            aBits = round(log2(a));
            bBits = round(log2(b));
        elseif(strcmp(Analysis.type, 'dynamic_analysis')) 
            Analysis.add(sprintf('%s = %s * %s', assign, atext, btext), 'MemReads', 2, 'MemWrites', 1, 'Mult', 1);
        end
    end
    
    node = st_new_PSnode(0, assign, 'int', 'nil', table, 0, 0, 0, 0);
elseif((value2 ~= 0 && strcmp(value2.arrayType, 'nil') == 0) && (value1 == 0 || (value1 ~= 0 && strcmp(value1.arrayType, 'nil'))))
    table = matimage(value2.infimum, value2.supremum);
    coord = first(value2);
    lastcoord = last(value2);

    if( isempty(Analysis) == 0 && strcmp(Analysis.type, 'classicalFD') )
        count = 1;
        errorList = 0;
        deviation = Analysis.deviation;
        while(isempty(find(coord ~= lastcoord, 1)) == 0)
            errorC = randi(1,1,[-deviation,deviation]);
            errorList(count) = abs(errorC);
            count = count +1;
            table.put(coord, b.get(coord) * a);
            coord = next(value2,coord);
        end
        errorC = randi(1,1,[-deviation,deviation]);
        errorList(count) = errorC;
        table.put(coord, b.get(coord) * a);
        figure('Name',sprintf('%s * %s : Error Analysis', atext, btext));
        hist(errorList,deviation);
    else
        table.set(a .* b.data());
        %while(isempty(find(coord ~= lastcoord, 1)) == 0)
        %    table.put(coord, b.get(coord) * a);
        %    coord = next(value2,coord);
        %end
        %table.put(coord, b.get(coord) * a);
    end
    
    if(isempty(Analysis) == 0)
        if(strcmp(Analysis.type, 'operand_size_bits')) 
            bBits = value2.Bits;
            bNoise = value2.Noise;
            aBits = round(log2(a));
        elseif(strcmp(Analysis.type, 'dynamic_analysis')) 
            Bsize = prod(value2.supremum - value2.infimum + 1);
            Analysis.add(sprintf('%s = %s + %s', assign, atext, btext), 'MemReads', Bsize+1, 'MemWrites', Bsize, 'Mult', Bsize);
        end
    end
    
    node = st_new_PSnode(0, assign, value2.type, value2.arrayType, 0, value2.ptr_range, 0, value2.scan, value2.connectivity);
else
    disp_error('Runtime', 'Major issue');
end
if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'operand_size_bits')) 
    Analysis.print();
    NeededSize = aBits + bBits;
    Bits = min (BitMultSize, NeededSize);
    display('  Complexity Analysis for Multiplication:');
    display(sprintf('     %c%s%c has %d bits and %c%s%c has %d bits. A size of %d bits is needed.', 39, atext, 39, aBits, 39, btext, 39, bBits, NeededSize));
    display(sprintf('     The size of the multiplier is %d bits', BitMultSize));
    display(sprintf('     The Output bit size = %d ', Bits));
    Noise = aNoise + bNoise;
    display('  Error/Noise Analysis for Multiplication:');
    display(sprintf('     %c%s%c has %d bits of noise and %c%s%c has %d bits of noise.' , 39, atext, 39, aNoise, 39, btext, 39, bNoise ));
    display(sprintf('     The output noise has %d bits of noise', Noise));
    display(sprintf('     The signal to noise ratio of %c%s%c is %d ', 39, atext, 39 , (aBits - aNoise) / aNoise ));
    display(sprintf('     The signal to noise ratio of %c%s%c is %d ', 39, btext, 39 , (bBits - bNoise) / bNoise ));
    display(sprintf('     The output signal to noise ratio is %d ', (Bits - Noise)/ Noise ));
end
%Add a temperary value to the symbol table for further computations.
node.Bits = Bits;
node.Noise = Noise;
node.JMED = JMED;
st.replace(assign, node);
tempCount = tempCount + 1;