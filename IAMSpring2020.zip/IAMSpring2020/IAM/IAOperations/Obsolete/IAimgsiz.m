

% Obsolete

function IAimgsiz(A,Ndimens,Npixels)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*


	   % IAimgsiz  finds the dimensionality of an image as an array
	   % IAimgsiz(A:array) finds 
	   %    Ndimens - the dimensionality of array A
	   %    Npixels - number of elements in array A

	   Ndimens   = ndims(A);
	   temp      = size(A);
	   Npixels   = 1;
	   for i  = 1:Ndimens
	    Npixels = Npixels .* temp(i);
	   end;