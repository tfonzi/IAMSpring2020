

% Obsolete program

function c = IAImgMultCmv(a, atext, t, ttext, coord, assign)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*


global st;
global tempCount;

c = a;
template = ntqu_search(st, ttext);
if(template == 0)
    display('Error: Template not found');
    return;
end

a1 = ntqu_search(st, atext);
if(template == 0)
    display('Error: Image not found');
    return;
end
if(a1.ptr_range.noElements ~= template.ptr_range.noElements)
    display('Incompatible dimensions');
    return;
end

if(a1.ptr_range.noElements == 1)
    [ M ] = size(a);
    [ K ] = size(t);
    coord(1) = round(K/2) + coord(1);
    for i = 1:M
        value = 0;
        for o = 1:K
            if ((i - coord(1)+o) > 0 && (i - coord(1)+o) <= M)
                tempval = a(i - coord(1)+o)*t(o);
                value = value * tempval;
            end
        end
        c(i) = value;
    end
elseif(a1.ptr_range.noElements == 2)
    [ M N ] = size(a);
    [ K L ] = size(t);
    coord(1) = round(K/2) + coord(1);
    coord(2) = round(L/2) + coord(2);
    for i = 1:M
        for j = 1:N
            value = 0;
            for o = 1:K
                for p = 1:L
                    if ((i - coord(1)+o) > 0 && (j - coord(2)+p) > 0 && (i - coord(1)+o) <= M && (j - coord(2)+p) <= N)
                        tempval = a(i - coord(1)+o,j - coord(2)+p)*t(o,p);
                        value = value * tempval;
                    end
                end
            end
            c(i,j) = value;
        end
    end
elseif(a1.ptr_range.noElements == 3)
    [ M N O ] = size(a);
    [ J K L ] = size(t);
    coord(1) = round(J/2) + coord(1);
    coord(2) = round(K/2) + coord(2);
    coord(3) = round(L/2) + coord(2);
    for g = 1:M
        for h = 1:N
            for i = 1:O
                value = 0;
                for p = 1:J
                    for q = 1:K
                        for r = 1:L
                            if ((g - coord(1)+p) > 0 && (h - coord(2)+q) > 0 && (i - coord(2)+r) > 0 && (g - coord(1)+p) <= M && (h - coord(2)+q) <= M && (i - coord(3)+r) <= O)
                                tempval = a(g - coord(1)+p,h - coord(2)+q,i - coord(3)+r)*t(p,q,r);
                                value = value * tempval;
                            end
                        end
                    end
                end
                c(g,h,i) = value;
            end
        end
    end
elseif(a1.ptr_range.noElements == 4)
    [ K L M N ] = size(a);
    [ G H I J ] = size(t);
    coord(1) = round(J/2) + coord(1);
    coord(2) = round(K/2) + coord(2);
    coord(3) = round(L/2) + coord(2);
    for b = 1:K
        for u = 1:L
            for d = 1:M
                for e = 1:N
                    value = 0;
                    for o = 1:G
                        for p = 1:H
                            for q = 1:I
                                for r = 1:J
                                    if ((b - coord(1)+o) > 0 && (u - coord(2)+p) > 0 && (d - coord(3)+q) > 0 && (e - coord(4)+r) > 0 && (b - coord(1)+o) <= K && (u - coord(2)+p) <= L && (d - coord(3)+q) <= M & (e - coord(4)+r) <= N)
                                        tempval = a( a - coord(1)+o, b - coord(2)+p,u - coord(3)+q,d - coord(4)+r)*t(o,p,q,r);
                                        value = value * tempval;
                                    end
                                end
                            end
                        end
                    end
                    c(b,u,d,e) = value;
                end
            end
        end
    end
else
    display('Cannont compute dimensions larger than 4');
    return;
end
%Add a temperary value to the symbol table for further computations.
node = ntqu_search(st, assign);
if(node ~= 0)
    st = ntst_remove(st, node);
end
node = st_new_PSnode(0, assign, a1.type, a1.arrayType, 0, a1.ptr_range, 0, a1.scan, a1.neighbor);
st = ntqu_push(st, node);
tempCount = tempCount + 1;