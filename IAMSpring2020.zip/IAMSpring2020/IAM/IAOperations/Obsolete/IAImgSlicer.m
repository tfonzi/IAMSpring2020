

function d = IAImgSlicer(a, atext, number, assign)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global tempCount;
c = a;
if(number <= 0)
    display('Error: cannot cut image into zero RETARD!!');
    return;
end
b = Grayscale(a, '0');
Red(number) = 0;
Blue(number) = 0;
Green(number) = 0;
count(number) = 0;
[ M N ] = size(b);
value = round(256/number);
%Separate the image into sections using the grayscale values.
for i = 1:M
    for j = 1:N
        section = value;
        for z = 1:number
            if (b(i,j) <= section)
                break;
            end
            section = section + value;
        end
        Red(min(section/value,number)) = Red(min(section/value,number)) + a(i,j);
        Blue(min(section/value,number)) = Blue(min(section/value,number)) + a(i,j + N);
        Green(min(section/value,number)) = Green(min(section/value,number)) + a(i,j + 2*N);
        count(min(section/value,number)) = count(min(section/value,number)) + 1;
    end
end
%Make sure your not dviding my zero
for t = 1:number
    if(count(t) == 0)
        count(t) = 1;
    end
end
Red = round(Red ./ count);
Blue = round(Blue ./ count);
Green = round(Green ./ count);
%Make the Image
for i = 1:M
    for j = 1:N
        section = value;
        for m = 1:number
            if (b(i,j) <= section)
                c(i,j) = Red(m);
                c(i,j + N) = Blue(m);
                c(i,j + 2*N) = Green(m);
                %c(i,j) = Blue(m);
                %c(i,j + N) = Green(m);
                %c(i,j + 2*N) = Red(m);
                %c(i,j) = Green(m);
                %c(i,j + N) = Red(m);
                %c(i,j + 2*N) = Blue(m);
                break;
            end
            section = section + value;
        end
    end
end
%Then I make a black space between the difference of colors.
d = c;
t = [1 1;1 1];
[ K L ] = size(t);
for i = 1:M
    for j = 1:N
        center = c(i,j);
        for o = 1:K
            for p = 1:L
                if ((i - 1+o) > 0 & (j - 1+p) > 0 & (i - 1+o) <= M & (j - 1+p) <= N)
                    if(c(i-1+o,j-1+p) ~= center)
                        d(i,j) = 0;
                        d(i,j + N) = 0;
                        d(i,j + 2*N) = 0;
                    end
                end
            end
        end
    end
end
%Add a temperary value to the symbol table for further computations.
value1 = ntqu_search(st, atext);
node = ntqu_search(st, assign);
if(node ~= 0)
    st = ntst_remove(st, node);
end
node = st_new_PSnode(0, assign, value1.type, value1.arrayType, 0, value1.ptr_range, 0, value1.scan, value1.neighbor);
st = ntqu_push(st, node);
tempCount = tempCount + 1;
