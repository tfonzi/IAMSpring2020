

function c = IAImgMDCnv(a, t, coord)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

[ M N O P ] = size(a);
[ J K L ] = size(t);
c = a;
coord(1) = round(J/2) + coord(1);
coord(2) = round(K/2) + coord(2);
coord(3) = round(L/2) + coord(3);
for i = 1:M
    for j = 1:N
        for k = 1:O
            for l = 1:P
                sum = 0;
                for o = 1:J
                    for p = 1:K
                        for q = 1:L
                            if ((i - coord(1)+o) > 0 & (j - coord(2)+p) > 0 & (k - coord(3)+q) > 0
                              & (i - coord(1)+o) <= M & (j - coord(2)+p) <= N) & (k - coord(3)+q) <= O)
                                tempval = a(i - coord(1)+o,j - coord(2)+p,k - coord(3)+q,l)*t(o,p,q);
                                sum = sum + tempval;
                            end
                        end
                    end
                end
                c(i,j,k,l) = sum;
            end
        end
    end
end