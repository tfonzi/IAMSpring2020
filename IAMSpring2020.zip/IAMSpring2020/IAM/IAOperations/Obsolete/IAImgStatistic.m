

% Obsolete

function c = IAImgStatistic(a, atext, assign)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global tempCount;
c= a;
mean = IAImgMean(a, 0);
stdev = IAImgStdev(a, 0);


c = IAImgCHI('>=', mean - stdev, a, 'a', 0) .* IAImgCHI('<=', mean + stdev, a, 'a', 0) ;

%Add a temperary value to the symbol table for further computations.
value1 = ntqu_search(st, atext);
node = ntqu_search(st, assign);
if(node ~= 0)
    st = ntst_remove(st, node);
end
node = st_new_PSnode(0, assign, value1.type, value1.arrayType, 0, value1.ptr_range, 0, value1.scan, value1.neighbor);
st = ntqu_push(st, node);
tempCount = tempCount + 1;
