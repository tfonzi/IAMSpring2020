

function table = IAImgMap(a,atext,b,btext, assign)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global stack;
global tempCount;
global Analysis;
value1 = st.search(atext);
value2 = st.search(btext);

if(value2 == 0 || strcmp(value2.arrayType, 'nil'))
    disp_error('Runtime', sprintf('%c%c%s is not an image', 39,atext, 39) );
end
    
if(value2 == 0 || strcmp(value2.arrayType, 'map') == 0)
    disp_error('Runtime', sprintf(' %c%s%c is not a map', 39,btext,39) );
end
    
    if(strcmp(value1.arrayType, 'map'))
        stack = ntst_new;
        domainconnect1 = st.search( b.firstChild.firstChild.sibling.value);
        domainconnect2 = st.search( a.firstChild.firstChild.value);
        if(strcmp(domainconnect1.name, domainconnect2.name) == 0)
            disp_error('Runtime', sprintf('Cannot compose map %c%s%c onto map %c%s%c', 39, atext, 39, 39, btext, 39 ) );
        end
        
        if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis')) 
            Analysis.add(sprintf('%s = %s @ %s', assign, atext, btext), 'MemReads', 2, 'MemWrites', 1);
        end

        newDomain = st.search(b.firstChild.firstChild.value);
        stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', newDomain.name)));%Push identifier on stack
        infimum = newDomain.infimum;
        supremum = newDomain.supremum;
        
        oldDomain = st.search(a.firstChild.firstChild.sibling.value);
        stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', oldDomain.name)));%Push identifier on stack

        node1 = nt_new_node('->', 0); % Z -> X
        buildTree(node1, 2); % One extra count for the range
        
        map1 = a.firstChild.sibling.sibling.firstChild.firstChild.firstChild;%Maps
        map2 = b.firstChild.sibling.sibling.firstChild.firstChild.firstChild;

        dimvalue1 = a.firstChild.sibling.firstChild;
        dimvalue2 = b.firstChild.sibling.firstChild;
        dimtable1 = ntqu_new;
        dimtable2 = ntqu_new;
        for i= 1:a.firstChild.sibling.noChildren
            
            node = st_new_PSnode(i, dimvalue1.value, '', 'image', 0, 0, 0, 0, 0);
            node.maptree = map1;
            
            dimtable1 = ntqu_push(dimtable1, node);
            node = st_new_PSnode(i, dimvalue2.value, '', 'image', 0, 0, 0, 0, 0);
            node.maptree = map2;
            dimtable2 = ntqu_push(dimtable2, node);
            dimvalue1 = dimvalue1.sibling;
            dimvalue2 = dimvalue2.sibling;
            map1 = map1.sibling;
            map2 = map2.sibling;
            
            stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', node.name)));%Push identifier on stack
        end

        node1 = nt_new_node(b.firstChild.sibling.type, 0);
        buildTree(node1, b.firstChild.sibling.noChildren); % One extra count for the range
        
        %display('Created dimension table for value1 and value2');  NEED TO
        %FIX BECAUSE OF VECTOR ISSUES!

        map = a.firstChild.sibling.sibling.firstChild;
        mapChild = map.firstChild.firstChild;
        %display_tree(mapChild);
        for i= 1:map.firstChild.noChildren
            
            AST = combineMapTree(mapChild, dimtable1, dimtable2);
            %display_tree(mapChild);
            %display_tree(AST);
            mapChild = mapChild.sibling;
            %display_tree(mapChild);
        end
        
        node1 = nt_new_node('vector', 0);
        buildTree(node1, map.firstChild.noChildren); % One extra count for the range
        
        node1 = nt_new_node('expression', 0);
        buildTree(node1, 1); % One extra count for the range
        node1 = nt_new_node('domain', 0);
        buildTree(node1, map.noChildren); % One extra count for the range
        
        node1 = nt_new_node('specifications', 0);
        AST = buildTree(node1, 3); % One extra count for the range
        table = AST;
    else
        newDomain = st.search( b.firstChild.firstChild.value);
        oldDomain = st.search( b.firstChild.firstChild.sibling.value);

        if(isempty(find(oldDomain.infimum ~= value1.infimum, 1)) == 0 || isempty(find(oldDomain.supremum ~= value1.supremum, 1)) == 0)
            disp_error('Runtime', 'Incompatible Map for Image' );
        end


        
        infimum = newDomain.infimum;
        supremum = newDomain.supremum;

        temp.scan = value1.scan;
        temp.infimum = infimum;
        temp.supremum = supremum; 
        table = matimage(temp.infimum, temp.supremum);

        dimvalue = b.firstChild.sibling.firstChild;
        dimtable = ntqu_new;
        for i= 1:b.firstChild.sibling.noChildren
            node = st_new_PSnode(i, dimvalue.value, '', 'image', 0, 0, 0, 0, 0);
            dimtable = ntqu_push(dimtable, node);
            dimvalue = dimvalue.sibling;
        end
        MAPPING = b.firstChild.sibling.sibling;
        
        coord = first(temp);
        lastcoord = last(temp);
        while(isempty(find(coord ~= lastcoord, 1)) == 0)
            table.put(coord, a.get(round(coordMap( coord, MAPPING, dimtable)) ) );
            coord = next(temp,coord);
        end
        table.put(coord, a.get(round(coordMap( coord, MAPPING, dimtable)) ) );
        
        if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis')) 
            Isize = prod(oldDomain.supremum - oldDomain.infimum + 1);
            Osize = prod(newDomain.supremum - newDomain.infimum + 1);
            Analysis.add(sprintf('%s = %s @ %s', assign, atext, btext), 'MemReads', Isize, 'MemWrites', Osize);
            DAmap(MAPPING, Osize);
        end
    end
    
    rq = ntqu_new;
    for i = 1:length(supremum)
        rq = ntqu_push(rq, range_new_node(infimum(i), supremum(i)));
    end

    st.replace(assign, st_new_PSnode(0, assign, value1.type, value1.arrayType, 0, rq, 0, value1.scan, value1.connectivity) );
    tempCount = tempCount + 1;

function newcoord = coordMap( coord, MAPPING, dimtable)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    


    dimension = MAPPING.firstChild.firstChild.firstChild;
    newcoord(MAPPING.firstChild.firstChild.noChildren) = 0;
    for i= 1:MAPPING.firstChild.firstChild.noChildren
        newcoord(i) = evaluateMap(coord, dimension, dimtable);
        dimension = dimension.sibling;
    end


function value = evaluateMap(coord, map, dimtable)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
if(strcmp(map.type, '-') && map.noChildren == 1)
    value = - evaluateMap(coord, map.firstChild, dimtable);
   
elseif(strcmp(map.type, '+'))
    value = evaluateMap(coord, map.firstChild, dimtable) + evaluateMap(coord, map.firstChild.sibling, dimtable);
elseif(strcmp(map.type, '-'))
    value = evaluateMap(coord, map.firstChild, dimtable) - evaluateMap(coord, map.firstChild.sibling, dimtable);
elseif(strcmp(map.type, '*'))
    value = evaluateMap(coord, map.firstChild, dimtable) * evaluateMap(coord, map.firstChild.sibling, dimtable);
elseif(strcmp(map.type, '^'))
    value = evaluateMap(coord, map.firstChild, dimtable) ^ evaluateMap(coord, map.firstChild.sibling, dimtable);
elseif(strcmp(map.type, '/'))
    value = evaluateMap(coord, map.firstChild, dimtable) / evaluateMap(coord, map.firstChild.sibling, dimtable);
elseif(strcmp(map.type, 'cos'))
    value = cos(evaluateMap(coord, map.firstChild, dimtable)*pi/180);
elseif(strcmp(map.type, 'sin'))
    value = sin(evaluateMap(coord, map.firstChild, dimtable)*pi/180);
else
    dimvalue = ntqu_search(dimtable, map.value);
    if(dimvalue ~= 0)
        value = coord(dimvalue.level);
    else
        stvalue = st.search(map.value);
        if(stvalue ~= 0)
            value = stvalue.value;
        else
            value = map.value;
        end
    end
end

function newcoord = DAmap(MAPPING, Osize)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*    


    dimension = MAPPING.firstChild.firstChild.firstChild;
    newcoord(MAPPING.firstChild.firstChild.noChildren) = 0;
    for i= 1:MAPPING.firstChild.firstChild.noChildren
        analysisMap(dimension, Osize);
        dimension = dimension.sibling;
    end


function analysisMap(map, Osize)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*


global Analysis;
if(strcmp(map.type, '-') && map.noChildren == 1)
    Analysis.increase('Sub', Osize);
    analysisMap(map.firstChild, Osize);
elseif(strcmp(map.type, '+'))
    Analysis.increase('Add', Osize);
    analysisMap(map.firstChild, Osize)
    analysisMap(map.firstChild.sibling, Osize);
elseif(strcmp(map.type, '-'))
    Analysis.increase('Sub', Osize);
    analysisMap(map.firstChild, Osize)
    analysisMap(map.firstChild.sibling, Osize);
elseif(strcmp(map.type, '*'))
    Analysis.increase('Mult', Osize);
    analysisMap(map.firstChild, Osize)
    analysisMap(map.firstChild.sibling, Osize);
elseif(strcmp(map.type, '^'))
    Analysis.increase('Pwr', Osize);
    analysisMap(map.firstChild, Osize)
    analysisMap(map.firstChild.sibling, Osize);
elseif(strcmp(map.type, '/'))
    Analysis.increase('Div', Osize);
    analysisMap(map.firstChild, Osize)
    analysisMap(map.firstChild.sibling, Osize);
end


function AST = combineMapTree(map, dimtable1, dimtable2)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global stack;

if((strcmp(map.type, '-') && map.noChildren == 1) || strcmp(map.type, 'cos') || strcmp(map.type, 'sin'))
    combineMapTree(map.firstChild, dimtable1, dimtable2);
    node1 = nt_new_node(map.type, 0);
    AST = buildTree(node1, 1);
elseif(strcmp(map.type, '+') || strcmp(map.type, '-') || strcmp(map.type, '*') || strcmp(map.type, '^') || strcmp(map.type, '/'))

    combineMapTree(map.firstChild, dimtable1, dimtable2);
    combineMapTree(map.firstChild.sibling, dimtable1, dimtable2);
    node1 = nt_new_node(map.type, 0);
    AST = buildTree(node1, 2);
else
    dimvalue1 = ntqu_search(dimtable1, map.value);
    if(dimvalue1 ~= 0)
        dimvalue2 = ntqu_search(dimtable2, dimvalue1.name);
        if(dimvalue2 ~= 0)
            combineMapTree(dimvalue2.maptree, dimtable2, ntst_new);
        else
            stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', dimvalue1.name)));%Push identifier on stack
        end
    else
        stvalue = st.search(map.value);
        if(stvalue ~= 0)
            stack = ntst_push(stack, new_stack_node(nt_new_node('identifier', stvalue.name)));%Push identifier on stack
        else
            stack = ntst_push(stack, new_stack_node(nt_new_node('numlit', map.value)));%Push identifier on stack
        end
    end
    AST = 0;
end
