
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: update
%% Inputs: input name, input file
%% Output: none
%% Description:
%% Populates an object with data from a file, and builds a starting JMED
%% if the analysis type is set.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function hash = update(a, Name)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global Analysis;

node = st.search(a);
if(node == 0)
    disp_error('Runtime', sprintf('Variable "%s" does not ezist in symbol table', a));
end
    
if(ischar(Name))

    temp = imread(Name);
    temp = double(temp) + 1;
    dim = ndims(temp);
    
    [ M N ] = size(temp);
    


    infimum = node.infimum;
    supremum = node.supremum;
    hash = matimage(infimum, supremum);
    
    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis'))
            Analysis.add(sprintf('readimage(%s, %s )', Name, a), 'DiskReads', prod(supremum - infimum + 1));
    end
    if(dim == 3)
        N = round(N/3);
        for j = 1:N
            for i = 1:M
                %if(i <= M && 2*N+j <= N*3)
                    hash.put([i+infimum(1)-1,j+infimum(2)-1], (temp(i,j)+temp(i,N+j)+temp(i,2*N+j)  )/3);
                %end

            end
        end
    else
        for j = 1:N
            for i = 1:M
                %if(i <= M && 2*N+j <= N*3)
                    hash.put([i+infimum(1)-1,j+infimum(2)-1], temp(i,j)   );
                %end

            end
        end
    end

    rq = ntqu_new;
    rq = ntqu_push(rq, range_new_node(infimum(1), supremum(1)));
    rq = ntqu_push(rq, range_new_node(infimum(2), supremum(2)));
    
    
    node = st_new_PSnode(0, node.name, 'int', 'image', 0, rq, 0, node.scan, node.connectivity);
  %%%%%%%%%%%%%%%%%%%%%%%%%Produce JMED%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if( isempty(Analysis) == 0 &&  strcmp(Analysis.type, 'nonparametric')  )
        %matrix = randint(256,251, [0, 255]);
        matrix = round(rand(256,252)*255);
        minimum = min(min(matrix));
        maximum = min(max(matrix));

        martix2 = (matrix-minimum)./(maximum - minimum);
        matrix3 = martix2./sum(sum(martix2));
        errorhash = hashimage();
        %for i = 0:250
        %    x = -1;
        %    y = 1;
        %    while( x <= 1)
        %        errorhash.put( [i, x] , matrix3(i+1,y));
        %        x = x + 0.008;
        %        y = y + 1;
        %    end
        %    clc;
        %    display(sprintf('Generating JMED "%s"...', a));
        %    display(sprintf('   %d%% Completed', round(100*(i)/(255))));
        %end
        for i = 1:256
            %x = -1;
            %y = 1;dim = numel(magnitude);
            for x = -125:125
                errorhash.put( [i-1, x] , matrix3(i,x+126));
                %x = x + 0.008;
                %y = y + 1;
            end
            clc;
            display(sprintf('Generating JMED "%s"...', a));
            display(sprintf('   %d%% Completed', round(100*i/256)));
        end
        
        node.JMED = JMED(0.008, -1, 1, 0, 255, errorhash);
        outputJMED(node.JMED,  a);
        figure('Name', sprintf('JMED "%s"', a));
        colormap(gray);
        imagesc(uint8(JMEDimage(node.JMED)-1));
    else
        node.JMED = 0;
    end
    %%%%%%%%%%%%%%%%%%%%%%%%% End of Producing JMED%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    
    
else
    %node = ntqu_search(st, a);
    %node = st.search(a);
    %if(node ~= 0)
    %    st.remove(node.name);
    %end
    [ M N ] = size(Name);
    
    hash = matimage([0 0], [ M-1, N-1]);
    for j = 1:N
        for i = 1:M
            hash.put([i-1, j-1], Name(i,j));
        end
    end

    node = st_new_PSnode(0, node.name, 'int', node.arrayType, 0, node.ptr_range, node.ptr_coord, 0, 0);
    %%%%%%%%%%%%%%%%%%%%%%%%TESTING JMED%%%%%%%%%%%%%%%%%%%%%%%%
    if( isempty(Analysis) == 0 &&  strcmp(Analysis.type, 'nonparametric')  )
            %matrix = randint(256,251, [0, 255]);
            
            %minimum = min(min(matrix));
            %maximum = min(max(matrix));
            %martix2 = (matrix-minimum)./(maximum - minimum);
            %matrix3 = martix2./sum(sum(martix2));
            matrix3(25, 10) = 0;
            [ K L ] = size(Name);
            
            for i = 1:K
                for j = 1:L
                    for k = 1:10
                        matrix3(Name(i,j), k) = k*0.01;
                    end
                end
            end
            
            
            
            errorhash = hashtable;
            for i = 1:25 %0:255
                x = 0.01;%-1;
                y = 1;
                while( x <= 0.1) %1)
                    errorhash.put([i, x] , matrix3(i,y));%1+1
                    x = x + 0.01; %0.008;
                    y = y + 1;
                end
                clc;
                display(sprintf('Generating JMED "%s"...', a));
                display(sprintf('   %d%% Completed', round(100*(i)/(255))));
            end
            node.JMED = JMED(0.01, 0.01, 0.1, 1, 25, errorhash);
            %node.JMED = JMED(0.008, -1, 1, 0, 255, errorhash);
            outputJMED(node.JMED,  a);
        %%%%%%%%%%%%%%%%%%%%%%%%TESTING JMED%%%%%%%%%%%%%%%%%%%%%%%%
        else
            node.JMED = 0;
        end
end
%st = ntqu_push(st, node);
st.replace(a, node);
