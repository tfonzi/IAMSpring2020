

function stdev = IAImgStdev(table, atext, assign)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global tempCount;
global Analysis;

value1 = st.search(atext);
mean = IAImgMean(table, atext, 0);
if(value1 == 0 || (value1 ~= 0 && strcmp(value1.arrayType, 'nil')))
    disp_error('Runetime', sprintf('%s is not an image to compute the Standard Deviation', atext ));
end

    data = power(table.data() - mean, 2);
    dim = ndims(data);
    Dsize = numel(data);
    for i = 1:dim
       data = sum(data);
    end
    stdev = sqrt(data/Dsize);
    
    %stdev = 0;
    %coord = first(value1);
    %lastcoord = last(value1);
    %while(isempty(find(coord ~= lastcoord, 1)) == 0)
    %    stdev = stdev + power(table.get(coord)-mean,2);
    %    coord = next(value1,coord);
    %end
    %stdev = stdev + power(table.get(coord)-mean,2);
    %stdev = sqrt(stdev/prod(value1.supremum - value1.infimum + 1));
    %stdev
    if(ischar(assign) )
        if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis')) 
            Isize = prod(value1.supremum - value1.infimum + 1);
            Analysis.add(sprintf('%s = stdev( %s )', assign, atext), 'MemReads', 2*Isize, 'MemWrites', 2, 'Max', 2*Isize);
        end
        st.replace(assign, st_new_PSnode(0, assign, 'int', 'nil', stdev, 0, 0, 0, 0) );
        tempCount = tempCount + 1;
    end