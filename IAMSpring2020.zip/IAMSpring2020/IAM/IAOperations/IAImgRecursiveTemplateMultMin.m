

function table = IAImgRecursiveTemplateMultMin(a, atext, t, ttext, targetcoord, assign)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global tempCount;
global Analysis;

template = st.search(ttext);
if(template == 0)
    disp_error('Runetime', sprintf('Template "%s" not found', ttext) );
end

if(strcmp(template.arrayType, 'tplrec') == 0)
    disp_error('Runetime', 'Recursive Convolution requires a recursive template' );
end

value = st.search(atext);
if(value == 0)
    disp_error('Runetime', sprintf('Image "%s" not found', atext) );
end

if(value.ptr_range.noElements ~= template.ptr_range.noElements)
        disp_error('Runtime', sprintf('Dimensionality of "%s" and "%s" are incompatible', atext, ttext ));
end

if(value.ptr_range.noElements > 4)
    disp_error('Runtime', 'Cannot compute images greater than dimensions of 4');
end

table = a.clone();
    
    if(isempty(Analysis) == 0 && strcmp(Analysis.type, 'dynamic_analysis')) 
        Isize = prod(value.supremum - value.infimum + 1);
        Tsize = prod(template.supremum - template.infimum + 1);
        Analysis.add(sprintf('%s = %s (^)< %s', assign, atext, ttext), 'MemReads', Isize+Tsize, 'MemWrites', Isize, 'Mult', Isize*Tsize, 'Min', Isize*(Tsize-1) );
    end
    
    coord = first(value);
    lastcoord = last(value);
    while(isempty(find(coord ~= lastcoord, 1)) == 0)
        min = Inf;
        templatecoord = first(template);
        templatelastcoord = last(template);
        while(isempty(find(templatecoord ~= templatelastcoord, 1)) == 0)
            temp = table.get(coord - targetcoord + templatecoord) * t.get(templatecoord);
            if(temp < min)
                min = temp;
            end
            templatecoord = next(template,templatecoord);
        end
        temp = table.get(coord - targetcoord + templatecoord) * t.get(templatecoord);
        if(temp < min)
            min = temp;
        end
        table.put(coord, min);
        
        coord = next(value,coord);
    end
    min = Inf;
    templatecoord = first(template);
    templatelastcoord = last(template);
    while(isempty(find(templatecoord ~= templatelastcoord, 1)) == 0)
        temp = table.get(coord - targetcoord + templatecoord) * t.get(templatecoord);
        if(temp < min)
            min = temp;
        end
        templatecoord = next(template,templatecoord);
    end
    temp = table.get(coord - targetcoord + templatecoord) * t.get(templatecoord);
    if(temp < min)
        min = temp;
    end
    table.put(coord, min);
    st.replace(assign, st_new_PSnode(0, assign, value.type, value.arrayType, 0, value.ptr_range, 0, value.scan, value.connectivity) );
    tempCount = tempCount + 1;