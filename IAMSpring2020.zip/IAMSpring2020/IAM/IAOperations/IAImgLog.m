

function table = IAImgLog(a,atext,b,btext, assign)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global Analysis;
global tempCount;

value1 = st.search(atext);
value2 = st.search(btext);

if((value1 == 0 && value2 == 0) || (value1 ~= 0 && strcmp(value1.arrayType, 'nil') && value2 ~= 0 && strcmp(value2.arrayType, 'nil')) || (value1 == 0 && value2 ~= 0 && strcmp(value2.arrayType, 'nil')) || (value2 == 0 && value1 ~= 0 && strcmp(value1.arrayType, 'nil')))
    table = log(b)/log(a);
    JMED = 0;
    if(isempty(Analysis) == 0)
        if(strcmp(Analysis.type, 'dynamic_analysis')) 
            Analysis.add(sprintf('%s = log(%s,%s)', assign, atext, btext), 'MemReads', 2, 'MemWrites', 1, 'Log', 1);
        end
    end
    
    node = st_new_PSnode(0, assign, 'int', 'nil', table, 0, 0, 0, 0);
elseif( (value1 == 0 || (value1 ~= 0 && strcmp(value1.arrayType, 'nil'))) &&(value2 ~= 0 && strcmp(value2.arrayType, 'nil') == 0) )
    table = matimage(value2.infimum, value2.supremum);
    table.set(log(b.data())/log(a) );
    %coord = first(value2);
    %lastcoord = last(value2);
    %while(isempty(find(coord ~= lastcoord, 1)) == 0)
    %    table.put(coord, log(b.get(coord))/log(a) );
    %    coord = next(value2,coord);
    %end
    %table.put(coord, log(b.get(coord))/log(a) );
    
    if(isempty(Analysis) == 0)
        if(strcmp(Analysis.type, 'dynamic_analysis')) 
            Bsize = prod(value2.supremum - value2.infimum + 1);
            Analysis.add(sprintf('%s = log(%s,%s)', assign, atext, btext), 'MemReads', Bsize+1, 'MemWrites', Bsize, 'Log', Bsize);
        end
    end
    JMED = value2.JMED;
    node = st_new_PSnode(0, assign, value2.type, value2.arrayType, 0, value2.ptr_range, 0, value2.scan, value2.connectivity);
else
    disp_error('Runtime', 'Invalid inputs for logarithmic functions.  Expected: log(integer, intenger|image) ');
end
%Add a temperary value to the symbol table for further computations.
node.Bits = 0;
node.Noise = 0;
node.JMED = JMED;
st.replace(assign, node);
tempCount = tempCount + 1;