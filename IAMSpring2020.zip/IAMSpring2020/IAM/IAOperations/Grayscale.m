
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: Grayscale
%% Inputs: input image, input name
%% Output: output matrix
%% Description:
%% Converts an image format into a gray matrix
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function c = Grayscale(a, atext)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global st;
global tempCount;

[ M N ] = size(a);
N = round(N/3);

if(atext ~= 0)
    node = st.search(atext);

    if(node ~= 0)
        st.remove(node);
        rq = ntqu_new;
        rq = ntqu_push(rq, range_new_node(node.ptr_range.firstElement.start_range, M + node.ptr_range.firstElement.start_range-1));
        rq = ntqu_push(rq, range_new_node(node.ptr_range.firstElement.next.start_range, N + node.ptr_range.firstElement.next.start_range-1));
        node = st_new_PSnode(0, node.name, 'int', 'image', 0, rq, 0, node.scan, node.connectivity);
        st.add(node);
        assign = sprintf('tmp%d',tempCount);
        node = st_new_PSnode(0, assign, 'int', 'image', 0, rq, 0, node.scan, node.connectivity);
        st.add(node);
        tempCount = tempCount + 1;
    end
end
c(M,N) = 0;
for i = 1:M
    for j = 1:N
        c(i,j) = (double(a(i,j))+double(a(i,N+j))+double(a(i,2*N+j)))/3;
    end
end