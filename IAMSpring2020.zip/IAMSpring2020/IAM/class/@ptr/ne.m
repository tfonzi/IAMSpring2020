

function [ret] =  ne(a,b)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%display(' in eq');
if((isobject(a)) && (isobject(b)))
    if(a.n ~= b.n)
        ret = 1;
    else
        ret = 0;
    end
else
    ret = 1;
end