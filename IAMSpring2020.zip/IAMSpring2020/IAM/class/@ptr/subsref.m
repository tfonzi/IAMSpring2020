

function b=subsref(obj,s)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%b=mt_ref1(obj,s);
global ptr_g;
%display('in sub ref');
if(s(1).type == '.')
     field = s(1).subs;
     index  = obj.n;
     b = ptr_g{1,index}.(field);    
else
       display('Illegal reference');
end
b;
if length(s)>1
  %b=mt_ref2(b,s(2:end));
  for i=2:length(s)
      if(s(i).type == '.')
          field = s(i).subs;
          index = b.n;
          b = ptr_g{1,index}.(field);          
      end
  end
%   if(s.type == '.')
%      field = s.subs;
%      b = obj.n.field;
%   else
%       display('Illegal reference');
%   end
end

