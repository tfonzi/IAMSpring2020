
function obj=subsasgn(obj,s,b)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%mt_asgn1(obj,s,b);
global ptr_g;
%display('sub asgn');
% s.type
% size(s)
if(length(s) == 1)
    field = s.subs;  
    index = obj.n;
    if(isstruct(ptr_g{1,index}))
        ptr_g{1,index}.(field) = b;
    else
        str.(field) = b;
        ptr_g{1,index} = str;
    end
else
    if(s(1).type == '.')     
        field = s(1).subs;
        index  = obj.n;
        if(isstruct(ptr_g{1,index}))
            temp = ptr_g{1,index}.(field); 
        else
            temp = obj.(field);
        end
    end
   for i=2:(length(s)-1)
      if(s(i).type == '.')
          field = s(i).subs;
          if(isa(temp, 'ptr'))
              index = temp.n;              
              temp = ptr_g{1,index}.(field);              
          else
              temp = temp.(field)
          end                 
      end
   end  
   if(s(length(s)).type == '.')
       field = s(length(s)).subs;  
       if(isa(temp, 'ptr'))
              index = temp.n;              
              ptr_g{1,index}.(field) = b;              
       else
              temp.(field) = b;
       end 
   end
   
end
