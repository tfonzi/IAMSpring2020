

function hash = vectorPut(hash,vector,data)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

hash = vectorPutHelper(hash,vector,1,data);

function hash = vectorPutHelper(hash,vector,count,data)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

[M N] = size(vector);
if(count >= N)
    hash = put(hash, vector(count),data);
else
    if(iskey(hash,vector(count)))
        subhash = get(hash,vector(count));
    else
        subhash = hashtable;
    end
    subhash = vectorPutHelper(subhash,vector,count+1,data);
    hash = put(hash, vector(count), subhash);    
end
