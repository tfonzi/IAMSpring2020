%{
    Filename: lnTaylor.m
    Developer: KR
    Purpose: Compute the error of ln(x) from .001x to .5x where x goes from 10^-2:10^4 (To match the expected plot domain)
    Created On: 04/05/2019
    Last Modified: 04/08/2019

    IMPORTANT DISCLAIMER: THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
%}

%{
    FUNCTION: lnTaylor()

    USAGE:
        This is the main driver fnc to plot ln(x) with assistance from lnTaylor_helper.m
%}

%{
    NOTE:
         Expected output verified on 04/08/2019 @ 7:55AM
%}

x = linspace(10^-2, 10^4, 1000000); % The step size must be 1 million. If not then the interval won't increase by .01
fracOfX = [.001, .002, .005, .01, .02, .05, .1, .2, .5]; % Note: You can edit the partition (step size) to your desire then re-run the alg
deltaXVect = [fracOfX(1)*x, fracOfX(2)*x, fracOfX(3)*x, fracOfX(4)*x, fracOfX(5)*x, fracOfX(6)*x, fracOfX(7)*x, fracOfX(8)*x, fracOfX(9)*x]; % Concatinating a vector which contains all of the above def parition

% The below isn't being used for the ln() graph output. But, it's included to stay consistent with the other fnc
z = 0;
for index = 1:5
    check = mod(index, 2); % This will either result in 0 or 1
    if (check == 0) % If 0 then it's a minu 
        z = z - ( (1/index)*(x - 1).^index );
    else % If 1 then it's a plus 
        z = z + ( (1/index)*(x - 1).^index );
    end
end

% ------------------------------------------------------------------------
% Below, we match the interval size of deltaXVect with X (being 1,000,000) then plot it 9 times since we have 9 partition size
deltaZ = lnTaylor_helper(x, deltaXVect(1:1000000));
loglog(x, deltaZ);
hold on;
deltaZ = lnTaylor_helper(x, deltaXVect(1000001:2000000));
loglog(x, deltaZ);
deltaZ = lnTaylor_helper(x, deltaXVect(2000001:3000000));
loglog(x, deltaZ);
deltaZ = lnTaylor_helper(x, deltaXVect(3000001:4000000));
loglog(x, deltaZ);
deltaZ = lnTaylor_helper(x, deltaXVect(4000001:5000000));
loglog(x, deltaZ);
deltaZ = lnTaylor_helper(x, deltaXVect(5000001:6000000));
loglog(x, deltaZ);

deltaZ = lnTaylor_helper(x, deltaXVect(6000001:7000000));
loglog(x, deltaZ, '--b');
deltaZ = lnTaylor_helper(x, deltaXVect(7000001:8000000));
loglog(x, deltaZ, '--g');
deltaZ = lnTaylor_helper(x, deltaXVect(8000001:9000000));
loglog(x, deltaZ, '--r');

% Plot labels  
figure(1);
title('\color{darkgreen} Error {\delta_x} as Fraction Of x');
ylabel('\color{blue} Error In ln(x)');
xlabel('\color{orange} x');
legend({'.001x', '.002x', '.005x', '.01x', '.02x', '.05x', '.1x', '.2x', '.5x'}, 'Location', 'northwest', 'NumColumns', 2);

hold off;
% ------------------------------------------------------------------------