%{
    Filename: sinhTaylor_helper.m
    Developer: KR
    Purpose: Compute the deltaZ vector for a given deltaX vector
    Created On: 04/05/2019
    Last Modified: 04/08/2019

    IMPORTANT DISCLAIMER: THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
%}

%{
    FUNCTION: sinhTaylor_helper()

    USAGE:

       INPUTS:
            vect: The current deltaX vector we are focused on. 
            x: Represents a partition with a specified stepSize 

       OUTPUT:
            deltaZ: The error vector of size 100 in the fnc sinh(x).
%}

function deltaZ = sinhTaylor_helper(x, vect)
%{
IMPORTANT DISCLAIMER: THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS. ALL ERRORS ARE THE RESPONSIBILITY OF THE
USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES
%}
deltaX = vect;

% Since the err eq for 9 terms is large, I'll break it down into pieces 
z1 = ( (deltaX) + (1/6)*(deltaX.^3) + (1/120)*(deltaX.^5) + (1/5040)*(deltaX.^7) + (1/factorial(9))*(deltaX.^9) );
z2 = ( (1/2)*(deltaX.^2) + (1/24)*(deltaX.^4) + (1/720)*(deltaX.^6) + (1/40320)*(deltaX.^8) ) .* x;
z3 = ( (1/2)*(deltaX) + (1/12)*(deltaX.^3) + (1/240)*(deltaX.^5) + (1/10080)*(deltaX.^7) ) .* (x.^2);
z4 = ( (1/12)*(deltaX.^2) + (1/144)*(deltaX.^4) + (1/4320)*(deltaX.^6) ) .* (x.^3);
z5 = ( (1/24)*(deltaX) + (1/144)*(deltaX.^3) + (1/2880)*(deltaX.^5) ) .* (x.^4);
z6 = ( (1/240)*(deltaX.^2) + (1/2880)*(deltaX.^4) ) .* (x.^5);
z7 = ( (1/720)*(deltaX) + (1/4320)*(deltaX.^3) ) .* (x.^6);
z8 = ( (1/10080)*(deltaX.^2) ) .* (x.^7);
z9 = ( (1/40320)*(deltaX) ) .* (x.^8);

deltaZ = (z1 + z2 + z3 + z4 + z5 + z6 + z7 + z8 + z9); 

end