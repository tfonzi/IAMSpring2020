%{
    Filename: cosErr.m
    Developer: Felipe P
    Purpose: To compute the error in cos operation
    Created On: 01/26/2018
    Last Modified: 03/16/2018

    IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%}

function [deltaZ, z] = cosErr(x, deltaX) 
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
    z = 0;

    %calculate z for first 5 terms
    for i = 0:5
        temp = ((-1)^(i))*((x.^(2*i))/(factorial(2*i)));
        z = z + temp;
    end

    %calculate error
    deltaZ = (-(1/2)*deltaX.^2 + (1/24)*deltaX.^4 - (1/720)*deltaX.^6 + (1/40320)*deltaX.^8);
    deltaZ = deltaZ + (-deltaX + (1/6)*deltaX.^3 - (1/120)*deltaX.^5 + (1/5040)*deltaX.^7).*x; 
    deltaZ = deltaZ + ((1/4)*deltaX.^2 - (1/48)*deltaX.^4 + (1/1440)*deltaX.^6).*x.^2;
    deltaZ = deltaZ + ((1/6)*deltaX - (1/36)*deltaX.^3 + (1/720)*deltaX.^5).*x.^3;
    deltaZ = deltaZ + (-(1/48)*deltaX.^2 + (1/576)*deltaX.^4).*x.^4 + (-(1/120)*deltaX + (1/720)*deltaX.^3).*x.^5;
    deltaZ = deltaZ + ((1/1440)*deltaX.^2).*x.^6 + ((1/5040)*deltaX).*x.^7;    
    
end