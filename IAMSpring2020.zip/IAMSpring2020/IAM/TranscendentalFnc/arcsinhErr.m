%{
    Filename: arcsinhErr.m
    Developer: Felipe P
    Purpose: To compute the error in sine operation
    Created On: 01/26/2018
    Last Modified: 03/16/2018

    IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%}

function [deltaZ, z] = arcsinhErr(x, deltaX) 
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

    %calculate z for first 5 terms
    z = x - (x.^3)*(1/6) + (3/40)*(x.^5)-(5/112)*(x.^7)+(35/1152)*(x.^9);
    
    %calculate error
    deltaZ = deltaX - (deltaX.^3)*(1/6) + (3/40)*(deltaX.^5)-(5/112)*(deltaX.^7)+(35/1152)*(deltaX.^9);
    deltaZ = deltaZ + ((deltaX.^2)*(-1/2) + (3/8)*(deltaX.^4)+(-5/16)*(deltaX.^6)+(35/128)*(deltaX.^8)).*x;
    deltaZ = deltaZ + ((-1/2)*deltaX + (3/4)*deltaX.^3 + (-15/16)*deltaX.^5 + (35/32)*deltaX.^7).*x.^2; 
    deltaZ = deltaZ + ((3/4)*deltaX.^2 + (-25/16)*deltaX.^4 + (245/96)*deltaX.^6).*x.^3;
    deltaZ = deltaZ + ((3/8)*deltaX + (-25/16)*deltaX.^3 + (245/64)*deltaX.^5).*x.^4;
    deltaZ = deltaZ + ((-15/16).*deltaX.^2 + (245/64)*deltaX.^4).*x.^5 + ((-5/16)*deltaX + (245/96)*deltaX.^3).*x.^6;
    deltaZ = deltaZ + ((35/32)*deltaX.^2).*x.^7 + ((35/128)*deltaX).*x.^8;
   
end