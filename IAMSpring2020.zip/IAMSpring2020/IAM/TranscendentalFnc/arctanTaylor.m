%{
    Filename: arctanTaylor.m
    Developer: KR
    Purpose: Compute the error of arctan(x) from .001x to .5x where x goes from -(pi/2):(pi/2)
    Created On: 04/07/2019
    Last Modified: 04/08/2019

    IMPORTANT DISCLAIMER: THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
    ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
%}

%{
    FUNCTION: arctanTaylor()

    USAGE:
        This is the main driver fnc to plot arctan(x) with assistance from arctanTaylor_helper.m
%}

%{
    NOTE:
         Expected output verified on 04/08/2019 @ 8:17AM   
%}

%{
    diff expectedResult actualResult
    < The range is from -150:200
    > The range is from -200:200
%}

x = linspace(-pi/2, pi/2); % 1 pi 
fracOfX = [.001, .002, .005, .01, .02, .05, .1, .2, .5]; % Note: You can edit the partition (step size) to your desire then re-run the alg
deltaXVect = [fracOfX(1)*x, fracOfX(2)*x, fracOfX(3)*x, fracOfX(4)*x, fracOfX(5)*x, fracOfX(6)*x, fracOfX(7)*x, fracOfX(8)*x, fracOfX(9)*x]; % Concatinating a vector which contains all of the above def parition

% Below is the closed formula for arctan(x)
z = 0;
count = 1; % This will handle the plus or minus sign ( i.e. -(x^3/3) versus +(x^5/5) ) 
for index = 1:9
    check = mod(index, 2); % This will handle the exponent (i.e. x^exponent)
    if (check == 1)
        if (mod(count, 2) == 1)
            z = z + ( (z.^index)/(index) );
        else 
           z = z - ( (z.^index)/(index) );
        end
    end
end
% ------------------------------------------------------------------------
% Below, we match the interval size of deltaXVect with X (being 100) then plot it 9 times since we have 9 partition size
deltaZ = arctanTaylor_helper(x, deltaXVect(1:100));
plot(x, deltaZ);
hold on;
deltaZ = arctanTaylor_helper(x, deltaXVect(101:200));
plot(x, deltaZ);
deltaZ = arctanTaylor_helper(x, deltaXVect(201:300));
plot(x, deltaZ);
deltaZ = arctanTaylor_helper(x, deltaXVect(301:400));
plot(x, deltaZ);
deltaZ = arctanTaylor_helper(x, deltaXVect(401:500));
plot(x, deltaZ);
deltaZ = arctanTaylor_helper(x, deltaXVect(501:600));
plot(x, deltaZ);

deltaZ = arctanTaylor_helper(x, deltaXVect(601:700));
plot(x, deltaZ, '--b');
deltaZ = arctanTaylor_helper(x, deltaXVect(701:800));
plot(x, deltaZ, '--g');
deltaZ = arctanTaylor_helper(x, deltaXVect(801:900));
plot(x, deltaZ, '--r');

% Plot labels  
figure(1);
title('\color{darkgreen} Error {\delta_x} as Fraction Of x');
ylabel('\color{blue} Error In arctan(x)');
xlabel('\color{orange} x');
legend({'.001x', '.002x', '.005x', '.01x', '.02x', '.05x', '.1x', '.2x', '.5x'}, 'Location', 'northwest', 'NumColumns', 2);

hold off;
% ------------------------------------------------------------------------