

function ntst = ntst_push(ntst, node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

if nargin<2
  error('three input arguments required.');
end
if nargout<1
  error('one output argument required.');
end
%ntst.noElements
ntst.noElements = ntst.noElements + 1;
if(ntst.noElements ==1)
	ntst.firstElement=node;
	node.next = 0;
else
	node.next = ntst.firstElement;
	ntst.firstElement = node;
    node2 = node.next;
    %node2.ntNode.type
end