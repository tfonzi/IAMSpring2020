

function nt=nt_put(nt,nt_node,child_node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% BT_PUT
%
%  bt=BT_PUT(bt,data,key) inserts data in the binary tree bt.
%  The binary tree is sorted according to a key.

% Copyright (c) MathWorks Inc. 1998-2001. All rights reserved.

global nt_nil

if(nt_node == nt_nil)
    nt = child_node;
else
%     prevSibling = nt_nil;
%     node = nt_node.firstChild;
%     while(node~=nt_nil)
% 	prevSibling = node;
% 	node=node.sibling;
%     end
% 
%     nt_node.noChildren = nt_node.noChildren + 1;
%     %nt_node.children(noChildren) = child_node;
%     if(prevSibling == nt_nil)
% 	nt_node.firstChild = child_node;
%     else
% 	prevSibling.sibling = child_node;
%     end
%    child_node.parent = nt_node;
    if(nt_node.firstChild ~= nt_nil)
        child_node.sibling = nt_node.firstChild;
    end
    nt_node.firstChild = child_node;
    %nt_node.firstChild.type
    child_node.parent = nt_node;
    nt_node.noChildren = nt_node.noChildren + 1;
end
