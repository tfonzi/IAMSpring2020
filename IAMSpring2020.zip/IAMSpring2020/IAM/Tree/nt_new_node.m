
function node = nt_new_node(type, value)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

  global nt_nil;
 %global JOMDcount;
  %global JOMD;

  node=ptr;
  node.parent=0;
  node.noChildren=0;
  node.firstChild=nt_nil;
  node.sibling = nt_nil;
  node.type= type;
  node.value = value;
 % if(strcmp(type, '+') || strcmp(type, '-') || strcmp(type, '*') || strcmp(type, '/') || strcmp(type, '^') || strcmp(type, 'cos') || strcmp(type, 'sin') || strcmp(type, '>=') || strcmp(type, '<=') || strcmp(type, '==') || strcmp(type, '>') || strcmp(type, '<') || strcmp(type, '(+)') || strcmp(type, '(v)') || strcmp(type, '(^)') || strcmp(type, '[v]') || strcmp(type, '[^]') || strcmp(type, '!gcon') || strcmp(type, '!amax') || strcmp(type, '!amin') || strcmp(type, '!mmax') || strcmp(type, '!mmin') || strcmp(type, '(+)<') || strcmp(type, '(v)<') || strcmp(type, '(^)<') || strcmp(type, '[v]<') || strcmp(type, '[^]<'))
      %node.JOMD = JOMDcount;
      
      %JOMD = ntqu_push(JOMD, JOMDnode(sprintf('%d', JOMDcount)));%Push identifier on stack
      %JOMDcount = JOMDcount + 1;
 % else
 %     node.JOMD = 0;
 % end
