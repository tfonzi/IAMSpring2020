

function ntst = ntst_remove(ntst, node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

STnode = ntst.firstElement;
previous = ntst.firstElement;
for i=1:ntst.noElements
    if(strcmp(node.name, STnode.name))
        if(i == 1)
            ntst.firstElement = ntst.firstElement.next;
        elseif(i == ntst.noElements)
            ntst.lastElement = previous;
        else
            previous.next = STnode.next;
        end
        ntst.noElements = ntst.noElements-1;
        break;
    end
    previous = STnode;
    STnode = STnode.next;
end
%function ntst2 = ntst_remove(ntst, node)
%ntst2 = ntqu_new;
%STnode = ntst.firstElement;
%for i=1:ntst.noElements
%    if(strcmp(node.name, STnode.name) == 0)
%        ntst2 = ntqu_push(ntst2, st_new_PSnode(STnode.level, STnode.name, STnode.type, STnode.arrayType, STnode.value, STnode.ptr_range, STnode.ptr_coord, STnode.scan, STnode.connectivity));
%    end
%    STnode = STnode.next;
%end

%function ntst = ntst_remove(ntst, node)
%queue = ntqu_new;

%STnode = ntst.firstElement;
%value = ntst.noElements-1;
%for i=1:ntst.noElements
%    if(strcmp(node.name, STnode.name) == 0)
%        
%        qnode = new_queue_node(STnode);
%        stack = ntqu_push(queue, qnode);
%    end
%    STnode = STnode.next;
%end
%ntst = ntqu_new;
%for i=1:value
%    qnode = ntqu_remove(queue);
%    ntst = ntqu_push(ntst, qnode.ntNode);
%end