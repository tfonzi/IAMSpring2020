

function nt=nt_new
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% Copyright (c) MathWorks Inc. 1998-2001. All rights reserved.

global nt_nil;
%display('in nt_new');
if isempty(nt_nil)
  nt_nil=ptr;
  nt_nil.parent=0;
  nt_nil.noChildren = 0;
  nt_nil.firstChild=nt_nil;
  nt_nil.sibling=nt_nil;
  nt_nil.type=[];
  nt_nil.value = 0;
end

nt=nt_nil;


