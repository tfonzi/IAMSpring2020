% Program:  Simple_error
% Date Generated:  17-Feb-2014
% Developed by: Eric Hayden

% Start of Symbol Table Generation
global st;
st = symbol_table();
node = st_new_PSnode(0, 'M', 'int', 'nil', 71, 0, 0, 0, 0);
st.add(node);
node = st_new_PSnode(0, 'N', 'int', 'nil', 95, 0, 0, 0, 0);
st.add(node);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(0, 'M'));
rq = ntqu_push(rq, range_new_node(0, 'N'));
node = st_new_PSnode(0, 'X', 'Rectangular', 'domain', 0, rq, 0, 'NormalScan', 'Moore');
st.add(node);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(0, 'M'));
rq = ntqu_push(rq, range_new_node(0, 'N'));
node = st_new_PSnode(0, 'a', 'int', 'image', 0, rq, 0, 'NormalScan', 'Moore');
st.add(node);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(0, 'M'));
rq = ntqu_push(rq, range_new_node(0, 'N'));
node = st_new_PSnode(0, 'b', 'int', 'image', 0, rq, 0, 'NormalScan', 'Moore');
st.add(node);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(0, 'M'));
rq = ntqu_push(rq, range_new_node(0, 'N'));
node = st_new_PSnode(0, 'c', 'int', 'image', 0, rq, 0, 'NormalScan', 'Moore');
st.add(node);
% End of Symbol Table Generation

% Start of MATLAB Image Algebra Code
global tempCount;
global stack;
stack = ntst_new;
tempCount = 0;
M = 71; 
N = 95; 
infimum = [ 0, 0 ];
supremum = [ 71, 95 ];
a = matimage(infimum, supremum);
infimum = [ 0, 0 ];
supremum = [ 71, 95 ];
b = matimage(infimum, supremum);
infimum = [ 0, 0 ];
supremum = [ 71, 95 ];
c = matimage(infimum, supremum);

a = update('a', 'One_dot.jpg');
b = update('b', 'One_dot.jpg');
  figure('Name', 'Image a');
  colormap(gray);
  imagesc(uint8(hashmatrix(a, 'a')-1));

tmp0 = IAImgAdd(a, 'a', b, 'b', 'tmp0');
c = assign(tmp0, 'tmp0', 'c'); 

  figure('Name', 'a + b');
  colormap(gray);
  imagesc(uint8(hashmatrix(c, 'c')-1));

% End of MATLAB Image Algebra Code
