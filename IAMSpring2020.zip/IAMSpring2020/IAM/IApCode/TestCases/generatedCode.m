% Program:  testEA
% Date Generated:  14-Apr-2010
% Developed by: Eric Hayden

% Start of Symbol Table Generation
global st;
st = ntqu_new;
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(0, 2));
rq = ntqu_push(rq, range_new_node(0, 2));
node = st_new_PSnode(0, 'c', 'int', 'image', 0, rq, 0, 0, 0);
st = ntqu_push(st, node);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(0, 1));
rq = ntqu_push(rq, range_new_node(0, 1));
node = st_new_PSnode(0, 'a', 'int', 'image', 0, rq, 0, 0, 0);
st = ntqu_push(st, node);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(0, 1));
rq = ntqu_push(rq, range_new_node(0, 1));
node = st_new_PSnode(0, 'b', 'int', 'image', 0, rq, 0, 0, 0);
st = ntqu_push(st, node);
% End of Symbol Table Generation

% Start of MATLAB Image Algebra Code
global tempCount;
global stack;
stack = ntst_new;
tempCount = 0;
c = hashtable;
matrix = [  1  2;  3  4 ];
a = update('a', matrix);
matrix = [  5  10;  15  20 ];
b = update('b', matrix);

tmp0 = IAImgAdd(a, 'a', b, 'b', 'tmp0');
c = assign(tmp0, 'tmp0', 'c'); 

h = figure('Name', 'a + b');
  imshow(uint8(hashmatrix(c, 'c')-1));

% End of MATLAB Image Algebra Code
