function JMED_graph(img)

% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

    %img = importdata("Small3.jpg");
    %img = double(img(:,:,1));

    [length,width]  = size(img);

        x_length = [1:1:length];
        x_width = [1:1:width];

        y_length = normpdf(x_length, length/2, length/16);
        y_width = normpdf(x_width, width/2, width/16);



        %figure();
        %plot(x,y);


        matrix = zeros(length,length);

        for(i=1:length)

            for(j=1:width)

                matrix(i,j) = y_length(i) * y_width(j);

            end
        end

    matrix = matrix * (256/2/max(max(matrix)));

    output = F19JMED(img,matrix);


    % code for bar chart
    %figure(1)
    %bar(output), xlabel('Magnitude'), ylabel('Error Fractions');

    %code for histogram
    figure()
    hist(output), xlabel('Error Fractions'), ylabel('Magnitude');
    set(gcf, 'Position', [100 100 800 400]);
    title('JMED Graph');
end


        
