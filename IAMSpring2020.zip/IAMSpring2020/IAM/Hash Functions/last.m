

function thelast = last(node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

if(strcmp(node.scan, 'NormalScan') || strcmp(node.scan, 'VerticalScan'))
    thelast = node.supremum;
elseif(strcmp(node.scan, 'ReverseNormalScan') || strcmp(node.scan, 'ReverseVerticalScan'))
    thelast = node.infimum;
else
    thelast = node.supremum;
end
%global supremum;
%supremum = 0;
%if(node.ptr_range ~= 0)
%    element = node.ptr_range.firstElement;
%    for(i = 1:node.ptr_range.noElements);
%        value = ntqu_search(st, element.end_range);
%        if(value == 0)
%            value = element.end_range;
%        else
%            value = value.value;
%        end
%        supremum(i) = value;
%        element = element.next;
%    end
%end