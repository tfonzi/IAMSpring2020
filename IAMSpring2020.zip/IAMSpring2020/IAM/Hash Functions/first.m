

function thefirst = first(node)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*


if(strcmp(node.scan, 'NormalScan') || strcmp(node.scan, 'VerticalScan'))
    thefirst = node.infimum;
elseif(strcmp(node.scan, 'ReverseNormalScan') || strcmp(node.scan, 'ReverseVerticalScan'))
    thefirst = node.supremum;
else
    thefirst = node.infimum;
end

%if(node.ptr_range ~= 0)
%    element = node.ptr_range.firstElement;
%    for(i = 1:node.ptr_range.noElements);
%        
%        value = ntqu_search(st, element.start_range);
%        if(value == 0)
%            value = element.start_range;
%        else
%            value = value.value;
%        end
%        infimum(i) = value;
%        element = element.next;
%    end
%end