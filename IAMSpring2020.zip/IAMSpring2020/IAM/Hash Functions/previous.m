

function coord = previous(X, coord)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*


if(strcmp(X.scan, 'NormalScan')0)
    supremum = last(X);
    infimum = first(X);
    i = 1;
    while(i <= length(coord))
        if(coord(i) == infimum(i))
            coord(i) = supremum(i);
        else
            break;
        end
        i = i+1;
    end
    coord(i) = coord(i) - 1;
elseif(strcmp(X.scan, 'ReverseNormalScan'))
    infimum = last(X);
    supremum = first(X);
    i = 1;
    while(i <= length(coord))
        if(coord(i) == supremum(i))
            coord(i) = infimum(i);
        else
            break;
        end
        i = i+1;
    end
    coord(i) = coord(i) + 1;
elseif(strcmp(X.scan, 'VerticalScan'))
    supremum = last(X);
    infimum = first(X);
    i = length(coord);
    while(i > 0)
        if(coord(i) == infimum(i))
            coord(i) = supremum(i);
        else
            break;
        end
        i = i-1;
    end
    coord(i) = coord(i) - 1;
elseif(strcmp(X.scan, 'ReverseVerticalScan'))
    infimum = last(X);
    supremum = first(X);
    i = length(coord);
    while(i > 0)
        if(coord(i) == supremum(i))
            coord(i) = infimum(i);
        else
            break;
        end
        i = i-1;
    end
    coord(i) = coord(i) + 1;
else
    supremum = last(X);
    infimum = first(X);
    i = 1;
    while(i <= length(coord))
        if(coord(i) == infimum(i))
            coord(i) = supremum(i);
        else
            break;
        end
        i = i+1;
    end
    coord(i) = coord(i) - 1;
end
%if(strcmp(X.scan, 'NormalScan'))
%    [M N] = size(coord);
%    if(N == 2)
%        if(infimum(1) < coord(1) && coord(1) <= supremum(1))
%            coord(1) = coord(1) - 1;
%        elseif(coord(1) == infimum(1) && coord(2) > infimum(2))
%            coord(1) = supremum(1);
%            coord(2) = coord(2) - 1;
%        end
%    end
%end
%if(scan-order = rowmajor)
%	first(X) <- infima(X)
%	last(X) <- suprema(X)
%	next(X) = (i,j+1) if p2(first(x)) <= j < p2(last(X))
%			     |__|
%			projection to 2nd coord   
%		  otherwise
%		  (i+1, p2(first(X)) if j=p2(last(X)) and i < p1(last(X))
%			assume x = (i,j)
%	previous(X) = (i,j-1) if p2(first(x)) < j <= p2(last(X))
%		  otherwise
%		  (i-1,p2(first(X)) if i > p1(first(X)) and j > p2(first(X))%
%	e.g. next(X) is defined for all x in X such that x != sub(X)%
%		     and previous(X) is defined for all x in X such that x != inf(X)
%
%		so we need to return some sentinel value or FLAG for these conditions
%	connectivitys(X) is dictated by (a) connectivity & (b) bounds