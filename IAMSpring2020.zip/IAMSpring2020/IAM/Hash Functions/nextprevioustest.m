% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

% Program:  IA_Operations_Tests
% Date Generated:  29-Jun-2009
% Developed by: Eric Hayden

% Start of Symbol Table Generation
global st;
st = ntqu_new;
node = st_new_PSnode(0, 'M', 'int', 'nil', 30, 0, 0, 0, 0);
st = ntqu_push(st, node);
node = st_new_PSnode(0, 'N', 'int', 'nil', 30, 0, 0, 0, 0);
st = ntqu_push(st, node);
node = st_new_PSnode(0, 'K', 'int', 'nil', 3, 0, 0, 0, 0);
st = ntqu_push(st, node);
node = st_new_PSnode(0, 'L', 'int', 'nil', 3, 0, 0, 0, 0);
st = ntqu_push(st, node);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(1, 'M'));
rq = ntqu_push(rq, range_new_node(1, 'N'));
node = st_new_PSnode(0, 'b', 'int', 'image', 0, rq, 0, 0, 0);
st = ntqu_push(st, node);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(1, 'M'));
rq = ntqu_push(rq, range_new_node(1, 'N'));
node = st_new_PSnode(0, 'c', 'int', 'image', 0, rq, 0, 0, 0);
st = ntqu_push(st, node);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(0, 'M'));
rq = ntqu_push(rq, range_new_node(0, 'N'));
node = st_new_PSnode(0, 'a', 'int', 'image', 0, rq, 0, 'NormalScan', 0);
st = ntqu_push(st, node);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(1, 'K'));
rq = ntqu_push(rq, range_new_node(1, 'L'));
cq = ntqu_new;
cq = ntqu_push(cq, coord_new_node(-4));
cq = ntqu_push(cq, coord_new_node(7));
node = st_new_PSnode(0, 's', 'int', 'tpl', 0, rq, cq, 0, 0);
st = ntqu_push(st, node);
rq = ntqu_new;
rq = ntqu_push(rq, range_new_node(1, 3));
rq = ntqu_push(rq, range_new_node(1, 3));
cq = ntqu_new;
cq = ntqu_push(cq, coord_new_node(8));
cq = ntqu_push(cq, coord_new_node(-2));
node = st_new_PSnode(0, 't', 'int', 'tpl', 0, rq, cq, 0, 0);
st = ntqu_push(st, node);
% End of Symbol Table Generation

% Start of MATLAB Image Algebra Code
global tempCount;
tempCount = 0;
M = 30 ; 
N = 30 ; 
K = 3 ; 
L = 3 ; 
b = 0;b(M - 1 + 1,N - 1 + 1) = 0;
c = 0;c(M - 1 + 1,N - 1 + 1) = 0;
a = 0;a(M - 0 + 1,N - 0 + 1) = 0;
s = 0;s(K - 1 + 1,L - 1 + 1) = 0;
t = [  3  5 -4;  0 -5  7; -3 -5  3 ];


node = ntqu_search(st, 'a');
coord = first(node)
for i = 1:300
    coord = next(node, coord)
end
display('No going backwards');
pause
for i = 1:300
    coord = previous(node, coord)
end

% End of MATLAB Image Algebra Code
