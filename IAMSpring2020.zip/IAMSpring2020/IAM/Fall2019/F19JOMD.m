function JOMD = F19JOMD(a,b)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
   n = numel(a);
   JOMD = zeros(n,n);
   for i= 1:size(a,2) %Row traverse
        for j= 1:size(a,1) %Col traverse
            row = a(i,j)+1;
            col = b(i,j)+1;
            JOMD(row,col) = JOMD(row,col) + 1/(numel(a));
        end
    end
end

