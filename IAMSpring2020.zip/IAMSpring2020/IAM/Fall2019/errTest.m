
%{ 
    Filename: errTest.m
    Developer: Brendan Cohen
    Purpose: Testing the error functions from Spring 2019  
    Created On: 09/30/2019
    Last Modified: 09/30/2019
    
    IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS. 
    ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%} 


%{

    FUNCTION: errTest
    Purpose: Refer above 
    
   
%}

disp('Sin error - x = 0.1, h = 0.2');

disp('Sin(0.3) = ');
disp(sin(0.3));
disp('Sin(0.1) = ');
disp(sin(0.1)); 
disp('Total = ');
disp(sin(0.3)-sin(0.1));

disp('Error function = ')
disp(sinErr(0.1,0.2));
disp('------------------------');
disp('Cos error - x = 2, h = 1');

disp('Cos(2) = ');
disp(cos(2));
disp('Cos(1) = ');
disp(cos(1)); 
disp('Total = ');
disp(cos(3)-cos(2));

disp('Error function = ')
disp(cosErr(2,1));
disp('------------------------');
disp('Div error - x = 2, y = 3, deltaX = 4, deltaY = 5');

disp('Hand calculated = ');
disp((4*3-2*5)/(9+15));

disp('Error function = ')
disp(divErr(2,3,4,5));