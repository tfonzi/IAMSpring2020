function JMED = F19JMED(a,da)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*
    d = rdivide(da,a);
    JMED = zeros(numel(unique(a)),numel(unique(d)));
    for i= 1:size(a,2) %Row traverse
        for j= 1:size(a,1) %Col traverse
            temp_a = a(j,i);
            temp_d = d(j,i);
            row = find(unique(a)==temp_a);
            col = find(unique(d)==temp_d);
            JMED(row,col) = JMED(row,col) + 1/(numel(a));
        end
    end
    
end

