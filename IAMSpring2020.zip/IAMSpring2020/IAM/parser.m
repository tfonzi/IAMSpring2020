
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: Parser
%% Inputs: name: Name of the file to be parsed.
%%         d : The option to debug or not
%% Output: None
%% Description:
%% This is the function that sets up the environment and call the function to parse the 
%% program as well as to generate the ASC machine calls.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function program = parser(name, varargin)
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

%% Set of the global variables
%% char_set: Array storing the entire files as characters.
%% len: Size of the char_set
%% pos: pos = current position of the pointer in the charset. Indicating
%% the amount of file that is scanned.
%% AST: The node pointing to the abstract syntax tree
%% stack: The stack that is used to put in the variables needed to build
%% the tree
%% st: St stands for the symbol table that is generated.

global AST;% Tree Building
global stack;% Tree Building
global st; % Symbol Table
global ts; % Token Stream

addpath(strcat(pwd, ';'));
if(isunix)
    addpath(strcat(pwd, '/Tree;'));
    addpath(strcat(pwd, '/class;'));
    addpath(strcat(pwd, '/IAOperations;'));
    addpath(strcat(pwd, '/Images;'));
    addpath(strcat(pwd, '/IApCode;'));
    addpath(strcat(pwd, '/Parser;'));
    addpath(strcat(pwd, '/Hash Functions;'));
    addpath(strcat(pwd, '/GUI;'));
    addpath(strcat(pwd, '/Complexity;'));
elseif(ispc)
    addpath(strcat(pwd, '\Tree;'));
    addpath(strcat(pwd, '\class;'));
    addpath(strcat(pwd, '\IAOperations;'));
    addpath(strcat(pwd, '\Images;'));
    addpath(strcat(pwd, '\IApCode;'));
    addpath(strcat(pwd, '\Parser;'));
    addpath(strcat(pwd, '\Hash Functions;'));
    addpath(strcat(pwd, '\GUI;'));
    addpath(strcat(pwd, '\Fall2019'));
else
    display('Cannot run on this operating system ');
    stop;
end

st = symbol_table();
ts = token_stream(name);
stack = ntst_new;
AST = nt_new;

    parse_program();
    
    if(size(varargin, 2) == 0)
        
        display_Tree(AST);
        display(st.display());
        display(' Now Generating the Matlab code');
        generateCode();
        display(' Now Generating the ASC code');
        generateASCCode();
    else
        GUIgenerateCode();
        
    end
    program = AST.value;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function Name: parse_program
%% Inputs: in: The entire file in the charater array form [char_set in
%% above function]
%% Output: None
%% Description:
%% This is the main function parses the input file
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function parse_program()
% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

global Analysis;
global ts;

%input = in;
% Parses the input stream according to the  grammar rules for the Image
% algebra described in the file 'parse.txt'. The rules that are parsed are
% illustrated as and when required. 
% At each step after a rule is identified and parsed, a node is created in
% the Abstract Syntax tree.
% This parser is a shift and reduce parser. 
% It builds the abstract syntax tree as follows: 
% Data structures used ao build tree: Stack
% As and when it identifies the tokens, it places them on to a stack.
% When it identifies a particular rule, it pops the relevant tokens needed
% from the stack, makes them as the children of the node that is the
% representation of that rule in the Abstract syntaxt tree (called ASTnode)
% and then pushes the ASTnode back in the tree.

% RULE: <program> ::= program <identifier> { <var_dec>* <command>* };

    ts.nextToken();
    if(ts.compare('program') == 0 && ts.compare('function') == 0 )
        disp_error(ts.spelling(), 'Expected program or function');
    end
    type = ts.spelling();
    
    ts.get_kind('IDEN');
    

    prog_name = ts.spelling();
    noBlocks = 0;% Used for counting the number of blocks in the tree
    if(strcmp(type,'function')== 1)
        ts.nextToken();
        if(ts.compare_kind('LPAREN') )%(strcmp(token.kind,'LPAREN')==1)  
            ts.nextToken();
            countVarDec = 0;%Counting number of variables in tree
            while(declare_type)
                evaluate_declaration();
                countVarDec = countVarDec + 1;
            end
            if(countVarDec ~= 0)
                node3 = nt_new_node('All_Params', 0);
                buildTree(node3, countVarDec);
                noBlocks =  noBlocks + 1;
            end
        end
    end
    % This is for the error and complexity analysis
    % analysis = worstcase | nonparametric | operand_size_bits |
    % dynamic_analysis
    % if it is worstcase, change deviation by adding the following code.
    % Default is 10
    % deviation = [ value ]
    ts.nextToken();
    if(ts.compare('analysis')) %strcmp(token.spelling,'analysis')==1)
        ts.get('=');
        ts.get_kind('STRLIT');

        AnalysisType = ts.spelling();

        if(strcmp(AnalysisType,'worstcase'))
            %Analysis = ptr;
            %Analysis.type = 'worstcase';
            Analysis = worstcase();
            ts.nextToken();
            if(ts.compare('deviation') )%strcmp(token.spelling,'deviation')==1)
                ts.get('=');
                ts.get_kind('NUMLIT');
                Analysis.deviation = ts.value;
                ts.nextToken();
            else
                Analysis.deviation = 10;
            end
        elseif(strcmp(AnalysisType,'classicalFD')) %checks if analysis type is classicalFD
            Analysis = classicalFD_analysis();  %initializes global analysis object 
            ts.nextToken();    %reads next token
        elseif(strcmp(AnalysisType,'nonparametric'))
            Analysis = ptr;
            Analysis.type = 'nonparametric';
            ts.nextToken();
        elseif(strcmp(AnalysisType,'operand_size_bits'))
            Analysis = operand_size_bits_analysis();
            ts.nextToken();
        elseif(strcmp(AnalysisType,'dynamic_analysis'))
            Analysis = dynamic_analysis();
            ts.nextToken();
        else
            disp_error(AnalysisType, 'Unknown Analysis Type');
            ts.nextToken();
        end
    end

    if(ts.compare('{') == 0 )
        disp_error(ts.spelling(), 'Expected: "{"');
    end
    
    %This is the main loop for declarations and commands
    ts.nextToken();
    while(1)
        if(declare_type)
            count = 0;
            while(declare_type)

                evaluate_declaration();
                count = count + 1;
            end
            node3 = nt_new_node('All_Var_Dec', 0);
            buildTree(node3, count);
            noBlocks =  noBlocks + 1;
        elseif(command_type)
            count = 0;
            while(command_type)
                evaluate_command();
                count = count + 1;
            end
            node1 = nt_new_node('Command_Sequence',0);
            buildTree(node1, count);
            noBlocks =  noBlocks + 1;
         elseif(ts.compare(';'))
             ts.nextToken();
        else
             break;
        end
    end
    buildTree(nt_new_node(type, prog_name), noBlocks);
