% IMPORTANT DISCLAIMER:  THIS SOFTWARE IS EXPERIMENTAL
% ONLY AND SHOULD NOT BE USED FOR MEDICAL DIAGNOSTIC
% OR OTHER LIFE-CRITICAL OR SAFETY-CRITICAL APPLICATIONS.
% ALL ERRORS ARE THE RESPONSIBILITY OF THE USER, AS THE
% SOFTWARE DEVELOPERS PROVIDE *NO*GUARANTEES*

function [ output ] = deindex( X, magnitude )

% dim = numel(magnitude);
% output = zeros(dim:1);
% value = mod(X-1, magnitude(dim) )+1;
% output(dim) = value;
% 
% for i = dim-1:-1:1
%     X = ceil(X/magnitude(i+1));
%     value = mod(X-1, magnitude(i) )+1;
%     output(i) = value;
% end


dim = numel(magnitude);
output = zeros(dim:1);
value = mod(X-1, magnitude(1) )+1;
output(1) = value;

for i = 2:dim
    X = ceil(X/magnitude(i-1));
    value = mod(X-1, magnitude(i) )+1;
    output(i) = value;
end